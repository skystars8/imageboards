BOARDHUB EXPERIMENTAL - PHP 8.5 + PER-BOARD SQLITE + STATIC HTML
================================================================

What this is
------------

BoardHub implements the architecture we discussed:

* Every board is one TinyIB-style directory directly in the configured web root:
  <slug>/. Its index.html, threads/, uploads/, and protected .board/ data directory travel
  together as a complete board package.
* Public home, /all, board, catalog, and thread reads are generated static HTML. Nginx
  serves board pages directly from their URL directories without starting PHP.
* Compose, post, report, login, and moderation routes use PHP.
* Reports stay in the board database, but one global moderator desk scans every
  healthy board. A broken board is listed as isolated and does not take down
  other boards.
* SQLite WAL, FULL synchronous durability, foreign keys, busy timeouts, atomic
  HTML replacement, publish revisions, and a publisher lock protect writes.
* The global SQLite database contains only moderators, sessions, login limits,
  and a global audit trail. It is not needed for public static reads.
* Moderators create and configure boards from /mod/boards. New boards are
  initialized atomically and start Closed. Each board can be Open, Approval,
  Password, or Closed. Pending submissions and their images remain private.

This is a serious experimental foundation, not a claim of unlimited scale.
Static reads are extremely cheap. Writes remain bounded by one SQLite writer
per board, image processing, and rebuilding the small global latest feed. That
is an excellent balance for a private site and a surprisingly large read-heavy
audience. If sustained write traffic eventually becomes the bottleneck, the
public URL and static-page design can remain while the write side is migrated.

Requirements
------------

PHP 8.5 with: pdo_sqlite, sqlite3, gd, fileinfo, mbstring, openssl, and OPcache.
The supplied C:\php installation already has the required extensions.

WINDOWS QUICK TEST
------------------

Recommended easy setup:

1. Double-click setup.bat.
2. Choose the first moderator username and a password of at least 12 characters.
3. Double-click start-test-server.bat. Zero boards is a valid starting state.
4. Open the moderator address printed in the window, normally:

   http://127.0.0.1:8080/mod

5. Log in, open Boards, and use Create board.
6. Review the new board settings. New boards start Closed; choose Open,
   Approval, or Password when the title, description, and page size are ready.

Keep the server window open while testing. Press Ctrl+C to stop it.

Setup now creates only the first moderator account and an empty set of static
pages. It does not create or copy a board. Every board is created from the
moderator Boards page, which initializes <slug>/ beside index.html with its .board/
identity, configuration, SQLite database, audit entry, uploads, and static pages.

Manual Windows alternative:

   $env:BOARDHUB_NEW_MOD_PASSWORD = Read-Host "New password"
   C:\php\php.exe tools\create-moderator.php admin
   Remove-Item Env:\BOARDHUB_NEW_MOD_PASSWORD -ErrorAction SilentlyContinue
   C:\php\php.exe tools\rebuild.php
   start-test-server.bat

Then log in at /mod and create the first board from Boards. Use at least 12
password characters. Passwords are hashed with Argon2id. The PHP development
server is for local testing only.

LINUX EASY TEST
---------------

From the app directory:

   sh setup.sh
   sh start-test-server.sh

Open /mod, log in, and create the first board from Boards. Set PHP_BIN if PHP is
not available as the command "php".

CREATING AND MANAGING BOARDS
----------------------------

Portable public board directories are runtime data and should normally be
created only through /mod/boards:

1. Log in at /mod.
2. Open Boards.
3. Enter the URL slug, name, and description under Create board.
4. Open the new board settings and choose its mode:

   Open       threads and replies appear immediately
   Approval   every submission waits privately in /mod/approval
   Password   every thread and reply requires the shared board password
   Closed     the readable board accepts no new submissions

New boards start empty in Closed mode with 10 threads per page. Duplicate or
reserved slugs are rejected without overwriting anything. Posting passwords
must be 8-128 characters and are stored only as Argon2id hashes in the board
SQLite database. Leave the password field blank to keep the current value; the
moderator can replace or clear it later.

Approval mode never includes pending text or images in generated pages, site-wide
activity, reports, or unauthenticated media responses. Approve publishes the
submission; Reject physically removes the never-published row and its image.
Each board accepts at most 150 pending submissions by default so an unattended
queue cannot grow forever.

Do not create a board by copying an existing live board. Existing boards carry
stable identities and databases. The moderator workflow always starts from the
blank board-template and performs the copy, identity creation, database setup,
audit, and publication under the site write lock.

DEPLOY INTO PUBLIC_HTML OR ANOTHER WEB ROOT
-------------------------------------------

This package has no outer public/ wrapper. Upload or extract the CONTENTS of this
directory directly into the web root assigned by the host, for example:

   /home/account/public_html/
       index.html
       boardhub.php    internal dynamic-action handler, not an index file
       .htaccess
       static/
       tools/
       site-data/
       chess/
       kingsgambit/

The resulting board URLs are /chess/ and /kingsgambit/. Each board directory
contains its static HTML, threads, uploads, and protected .board data. Shared CSS,
JavaScript, PHP source, maintenance tools, and site-wide data remain beside the
boards in the same permitted hosting directory.

1. Install or select PHP 8.5 with the extensions listed above.
2. On Apache/shared hosting, preserve the supplied root .htaccess and every
   private-directory .htaccess file. The package includes defense-in-depth denial
   files in .board, site-data, backups, src, database, config, tests, and tools.
3. Give PHP write access to:

   the web root itself        create new board slug directories and index.html
   <slug>/                    update that board's HTML, uploads, and .board data
   all/                       update the site-wide latest-activity page
   site-data/                 control.sqlite3 and the site-write lock
   backups/                   only when backups are stored below this web root

   Keep shared PHP, CSS, JavaScript, schemas, and configuration read-only where
   the host's permission model allows it. Board creation necessarily requires
   PHP to create a new directory directly in the web root.
4. For Nginx, use config/nginx-boardhub.conf as the starting server block. Its
   sample root is /srv/boardhub; replace that with the directory that actually
   contains boardhub.php. The only index file is index.html. Also replace the
   domain and PHP-FPM socket.
5. Merge config/php-production.ini into the FPM configuration and set:

   BOARDHUB_ENV=production
   BOARDHUB_SECURE_COOKIES=true

6. For a brand-new empty community, create the first moderator before exposing
   the site. Do not run setup when restoring a backup:

   BOARDHUB_ENV=production BOARDHUB_SECURE_COOKIES=true sh setup.sh

   Setup creates the moderator and empty root index.html and all/index.html,
   but no board.
7. Rebuild, validate the web-server configuration, and reload it:

   php tools/rebuild.php
   sudo nginx -t
   sudo systemctl reload nginx

8. Visit /mod, log in, open Boards, create the first board, review its settings,
   and enable posting when ready.

Before accepting traffic, request each of these paths and confirm the web server
returns 404 or 403, never file contents:

   /site-data/control.sqlite3
   /src/Config.php
   /tools/backup.php
   /backups/
   /<board>/.board/board.sqlite3

Repeat these checks after changing hosts or server configuration. Keeping private
data in the assigned web root is a compatibility tradeoff: the supplied Apache,
Nginx, and local-router rules are mandatory. If a host ignores .htaccess or does
not permit equivalent denial rules, do not deploy the application there.

The web root has exactly one index file: index.html. Dynamic actions are routed
internally to boardhub.php; direct requests for that handler are denied.

Normal public reads use root index.html, all/index.html, and each <slug>/ directory
directly. PHP handles writes, reports, moderation, board creation/settings,
missing-page repair, and authorized image serving.

Use HTTPS before logging in or accepting public posts. Keep /mod behind an
additional VPN, allowlist, or web-server authentication layer if practical.
APPLICATION IP PRIVACY
----------------------

The PHP application never reads REMOTE_ADDR, X-Forwarded-For, CF-Connecting-IP,
or another request address. It stores neither raw IP addresses nor identifiers
derived from them. Anonymous rate limits use random, purpose-separated browser-
session keys. Moderator login limits combine a random session key with the
submitted moderator account name.

Nginx, Cloudflare, operating-system, and hosting-provider access logs are outside
the application and must be configured under the site owner's separate log and
retention policy.

BACKUP
------

Do not copy a live SQLite file by itself. WAL may contain committed changes.
Use the included online backup command:

   php tools/backup.php

It creates backups/YYYYMMDD-HHMMSS-utc by default. Or choose a destination:

   php tools/backup.php /mnt/backup/boardhub-2026-08-03

The backup:

* obtains an exclusive site-write lock briefly;
* uses SQLite's online backup API for every board and the control database;
* first publishes a consistent index.html and threads/ snapshot for each board;
* stores each complete board at boards/<slug>/ with uploads and a hidden
  .board/ containing board.json, .board-id, and an online SQLite snapshot;
* records SHA-256 hashes in manifest.json.

Copy the finished backup directory to a different server or object-storage
account. A backup on the same VPS is not disaster recovery. Automate daily
backups, keep multiple generations, and run a restore drill periodically.

RESTORE OR MOVE TO A NEW SERVER
-------------------------------

1. Install a fresh copy of the application contents directly in the new web root.
2. Do not run setup. Shared PHP, CSS, JavaScript, empty runtime directories, and
   generated root pages may exist, but no live directory marked by .board/ may
   exist and site-data/control.sqlite3 must be absent.
3. Transfer one completed backup directory.
4. Run:

   php tools/restore.php /path/to/backup --confirm-empty

Restore verifies every manifest hash, refuses existing board destinations,
copies each complete board into <slug>/ at the web root, restores the global moderator
database, and regenerates all public HTML. Then apply permissions, configure
Nginx, and bring the site online.

A single board can also be recovered independently. Stop or pause writes, move
the damaged <slug>/ directory aside, copy backups/.../boards/<slug>/ into its
place, and run php tools/rebuild.php. Do not copy a live SQLite file directly; use
a completed online backup so its .board/board.sqlite3 is self-contained.

CRASH RECOVERY
--------------

SQLite WAL and FULL synchronous mode protect committed database work. Static
pages are written to random temporary files, flushed, then renamed into place.
The database records revision and published_revision separately. If PHP or the
server dies after the database commit but before HTML publication, the board
stays marked dirty. Repair it with:

   php tools/rebuild.php

The next dynamic missing-page repair can also regenerate pages. Nginx may keep
serving the previous complete static page during the rare database-to-publish
window; it should never receive a half-written HTML file.

MODERATION MODEL
----------------

Visit /mod. The moderator desk is split into focused views:

* Latest posts shows every recent post or edit with its thumbnail, metadata,
  thread context, and edit/delete controls. Opening-post rows show Pin/Lock;
  reply rows show Pin thread/Lock thread and safely target the parent thread.
* Approval shows private submissions in oldest-first order with their full text
  and image. Approve publishes one; Reject permanently removes it; Edit before
  approval changes it without exposing it. Queue counts appear throughout mod.
* Reports shows the report reason beside the full post and image. A moderator
  can accept the report by deleting the post, dismiss the report, edit the post,
  control the parent thread, or open the post in context.
* Boards creates new boards and shows per-board approved-post, thread, image,
  pending, and report counts. New boards start Closed. Edit controls the title,
  description, Open/Approval/Password/Closed mode, shared posting password, and
  threads per page.
* Edit post changes text and can replace or remove the image in the same form.
  Successful actions return to the queue where the moderator started.
* Rebuild pages forces a complete static-publication refresh.

A broken board is reported as isolated without taking down moderation for the
healthy boards. Destructive actions are CSRF-protected and confirmed in the UI.

SECURITY NOTES
--------------

The code includes strict types, prepared statements, output escaping, CSRF
tokens, SameSite/HttpOnly cookies, CSP headers, moderator session expiry,
Argon2id moderator and board-password hashing, board-local posting/password
rate limits using random session keys, bounded approval queues, no application
IP collection or IP-derived identifiers, raster-only image validation, pixel/
dimension limits, randomized upload names, and no executable upload formats.
Pending content is excluded at the database-query and static-publishing
boundaries, and from public reporting and media-serving routes.

Before exposing a new community to hostile traffic, add the policies your site
needs: CAPTCHA or proof-of-work, bans, deletion/retention rules, legal pages,
monitoring, log rotation, alerting, abuse contacts, and an independent security
review. Social sites achieve reliability through operations as much as code.

USEFUL COMMANDS
---------------

   setup.bat                         create first moderator on Windows
   sh setup.sh                       create first moderator on Linux
   start-test-server.bat             Windows local test server
   sh start-test-server.sh           Linux local test server
   php tools/rebuild.php
   php tools/backup.php [destination]
   php tools/restore.php BACKUP --confirm-empty
   php tools/create-moderator.php USERNAME
   php tests/integration.php

Environment options:

   BOARDHUB_ENV                  development | production | test
   BOARDHUB_SECURE_COOKIES       true in production

   BOARDHUB_MAX_UPLOAD_BYTES     default 5242880
   BOARDHUB_MAX_IMAGE_DIMENSION  default 16384
   BOARDHUB_MAX_IMAGE_PIXELS     default 100000000
   BOARDHUB_MAX_PENDING_POSTS_PER_BOARD  default 150 (1-10000)
   BOARDHUB_JAVASCRIPT           default true; false omits all JavaScript
   BOARDHUB_JS_FEATURES          default all; all, none, or a comma-separated allowlist
   BOARDHUB_SITE_DATA_PATH       optional alternate control-data directory
   BOARDHUB_CONTROL_DB           optional alternate control DB path

   BOARDHUB_WRITE_LOCK           optional alternate backup/write lock path

JavaScript feature names:

   enhancement-settings operator-approved, per-browser feature switches plus
                        validated reset/export/import
   preferences          theme, text-size, and text-weight controls
   image-expansion      click-to-expand originals and expand/collapse-all
   image-visibility     remembered hide/show-images control
   image-gallery        accessible same-origin attachment lightbox
   image-hover          delayed pointer-only original-image preview
   post-menu-position   keep open post menus inside the viewport
   moderator-helpers    destructive-action confirmations and image edit helpers
   local-time           localized relative post timestamps
   quote-links          in-page quote backlinks and target highlighting
   upload-preview       selected image name, size, dimensions, and thumbnail
   upload-dropzone      targeted drag, drop, and focused clipboard image input
   board-favorites      local favorite-board pinning and navigation ordering
   thread-watchlist     bounded local bookmarks with manual status checks
   content-hiding       local post/thread hiding and literal name/phrase mutes
   locked-thread-filter remembered hide/show control for locked threads
   thread-navigation    opt-in J/K post navigation outside form fields
   compact-board-list   denser board navigation
   drafts               per-session unfinished post drafts
   quote-selection      explicit post or selected-text quoting
   quick-reply          compact reply form using same-origin CSRF metadata
   new-post-notifier    opt-in static-manifest polling and title counts
   catalog-tools        client-side search and sorting on static catalogs
   formatting-toolbar   formatting markers inserted with native textarea APIs

The operator allowlist is always authoritative. When enhancement-settings is
allowed, visitors can independently disable allowed features in the Enhancements
dialog. Hover previews, J/K navigation, compact navigation, and update polling
start off for each visitor because they are more subjective or active behaviors.
Moderator helpers cannot be disabled by visitor preferences.

For example, to keep only reading preferences and quote context:

   BOARDHUB_JS_FEATURES=preferences,quote-links

Run tools/rebuild.php after changing these options so generated public pages receive
the new policy. Forms, links, images, timestamps, and native details menus remain
usable when JavaScript or an individual enhancement is disabled.

Each board publish also writes catalog/index.html and a small updates.json containing
only public thread IDs, counts, lock state, and activity times. Watchlist checks and
the new-post notifier read that same-origin static manifest; they do not fetch and
clone thread HTML.

Post formatting is parsed only after HTML escaping. Supported markers are:

   '''bold'''   ''italic''   **spoiler**   __underline__   ~~strike~~
   [code]literal code[/code]
   ==heading==  (on its own line)

Arbitrary browser JavaScript, imported CSS, raw regular-expression filters, poster
fingerprints, and third-party media embeds are intentionally not supported.

For the architectural reference in a browser, open:

   static/design.html
