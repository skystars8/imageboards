@echo off
setlocal

title BoardHub Experimental - Local Test Server
cd /d "%~dp0"

set "PHP_EXE=C:\php\php.exe"
set "HOST=127.0.0.1"
set "PORT=8080"
set "SITE_URL=http://%HOST%:%PORT%/"

echo.
echo ============================================================
echo   BoardHub Experimental - Local Test Server
echo ============================================================
echo.

if not exist "%PHP_EXE%" (
    echo ERROR: PHP was not found at:
    echo   %PHP_EXE%
    echo.
    echo Install PHP there or edit PHP_EXE near the top of this file.
    echo.
    pause
    exit /b 1
)

if not exist "router.php" (
    echo ERROR: router.php is missing.
    echo Put this BAT file in the main BoardHub app directory.
    echo.
    pause
    exit /b 1
)

if not exist "boardhub.php" (
    echo ERROR: The web-root app files are missing.
    echo Put this BAT file in the main BoardHub app directory.
    echo.
    pause
    exit /b 1
)

set "FOUND_BOARD="
for /d %%D in ("*") do (
    if exist "%%~fD\.board\board.sqlite3" set "FOUND_BOARD=1"
)

if not defined FOUND_BOARD (
    echo No boards exist yet. This is valid after first-moderator setup.
    echo Start the server, log in at /mod, then use Boards - Create board.
    echo.
)

echo Preparing the static pages...
"%PHP_EXE%" tools\rebuild.php
if errorlevel 1 (
    echo.
    echo ERROR: The pages could not be rebuilt.
    echo Read the error above, correct it, and try again.
    echo.
    pause
    exit /b 1
)

if /i "%~1"=="--check" (
    echo.
    echo Startup checks passed.
    exit /b 0
)

echo.
echo ============================================================
echo   SERVER READY TO START
echo ============================================================
echo.
echo Open this address in your browser:
echo.
echo   %SITE_URL%
echo.
echo Useful addresses:
echo   Home:             %SITE_URL%
echo   Latest activity:  %SITE_URL%all/
echo   Moderator login:  %SITE_URL%mod
echo   Board manager:    %SITE_URL%mod/boards
echo.
echo Configured boards:
if defined FOUND_BOARD (
    for /d %%D in ("*") do (
        if exist "%%~fD\.board\board.sqlite3" echo   %SITE_URL%%%~nxD/
    )
) else (
    echo   none yet - create the first one from the moderator Board manager
)
echo.
echo Keep this window open while testing.
echo Press Ctrl+C in this window to stop the server.
echo.
echo Starting PHP %HOST%:%PORT%...
echo ============================================================
echo.

"%PHP_EXE%" -S %HOST%:%PORT% -t . router.php
set "SERVER_EXIT=%ERRORLEVEL%"

echo.
echo The local test server has stopped.
if not "%SERVER_EXIT%"=="0" (
    echo If port %PORT% was already in use, close the other server and try again.
)
echo.
pause
exit /b %SERVER_EXIT%
