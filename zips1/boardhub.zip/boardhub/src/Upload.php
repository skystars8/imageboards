<?php

declare(strict_types=1);

namespace BoardHub;

final readonly class Upload
{
    public function __construct(
        public string $originalName,
        public string $storedName,
        public string $thumbnailName,
        public string $mimeType,
        public int $size,
        public int $width,
        public int $height,
    ) {
    }
}
