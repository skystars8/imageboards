<?php

declare(strict_types=1);

namespace BoardHub;

use RuntimeException;

final class Publisher
{
    public function __construct(
        private readonly Config $config,
        private readonly BoardRegistry $registry,
        private readonly Renderer $renderer,
    ) {
    }

    /** @return array<string,string> */
    public function publishAll(bool $force = false): array
    {
        $failures = [];
        foreach ($this->registry->all() as $board) {
            try {
                $this->publishBoard($board, $force);
            } catch (\Throwable $error) {
                $failures[$board->slug] = $error->getMessage();
            }
        }
        $this->publishShared();

        return $failures;
    }

    public function publishBoard(Board $board, bool $force = false): void
    {
        $lock = SiteLock::publisher($this->config);
        try {
            $store = new BoardStore($this->config, $board);
            $state = $store->state();
            if (!$force && $state['revision'] === $state['published_revision']) {
                return;
            }
            $directory = $board->path;
            $threadDirectory = $directory . '/threads';
            Config::ensureDirectory($threadDirectory, 0755);
            $boards = $this->registry->all();
            $threads = $store->threads();
            $catalogThreads = $store->catalogThreads();
            $this->atomicWrite($directory . '/index.html', $this->renderer->board($board, $threads, $boards));
            $catalogDirectory = $directory . '/catalog';
            Config::ensureDirectory($catalogDirectory, 0755);
            $this->atomicWrite(
                $catalogDirectory . '/index.html',
                $this->renderer->catalog($board, $catalogThreads, $boards)
            );
            $this->atomicWrite(
                $directory . '/updates.json',
                json_encode($store->updateManifest(), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES) . PHP_EOL
            );
            $active = $store->activeThreadIds();
            foreach ($active as $threadId) {
                $this->atomicWrite(
                    $threadDirectory . '/' . $threadId . '.html',
                    $this->renderer->thread($board, $store->threadPosts($threadId), $boards)
                );
            }
            foreach (glob($threadDirectory . '/*.html') ?: [] as $existing) {
                $id = filter_var(pathinfo($existing, PATHINFO_FILENAME), FILTER_VALIDATE_INT);
                if (is_int($id) && !in_array($id, $active, true)) {
                    @unlink($existing);
                }
            }
            $store->markPublished($state['revision']);
        } finally {
            $lock->release();
        }
    }

    public function publishShared(): void
    {
        $lock = SiteLock::publisher($this->config);
        try {
            $boards = $this->registry->all();
            $this->atomicWrite(
                $this->config->webRoot . '/index.html',
                $this->renderer->home($boards, $this->registry->issues())
            );
            $activity = [];
            foreach ($boards as $board) {
                try {
                    foreach ((new BoardStore($this->config, $board))->latestActivity(30) as $post) {
                        $activity[] = ['board' => $board, 'post' => $post];
                    }
                } catch (\Throwable) {
                    continue;
                }
            }
            usort($activity, static fn (array $a, array $b): int => (int) $b['post']['updated_at'] <=> (int) $a['post']['updated_at']);
            $allDirectory = $this->config->webRoot . '/all';
            Config::ensureDirectory($allDirectory);
            $this->atomicWrite(
                $allDirectory . '/index.html',
                $this->renderer->all(array_slice($activity, 0, 100), $boards)
            );
        } finally {
            $lock->release();
        }
    }

    private function atomicWrite(string $path, string $contents): void
    {
        Config::ensureDirectory(dirname($path));
        $temporary = $path . '.' . bin2hex(random_bytes(8)) . '.tmp';
        $handle = fopen($temporary, 'xb');
        if ($handle === false) {
            throw new RuntimeException('Unable to create a temporary static page.');
        }
        try {
            $remaining = $contents;
            while ($remaining !== '') {
                $written = fwrite($handle, $remaining);
                if ($written === false || $written === 0) {
                    throw new RuntimeException('Unable to write a static page.');
                }
                $remaining = substr($remaining, $written);
            }
            fflush($handle);
            if (function_exists('fsync')) {
                fsync($handle);
            }
        } finally {
            fclose($handle);
        }
        if (PHP_OS_FAMILY === 'Windows' && is_file($path)) {
            $old = $path . '.old-' . bin2hex(random_bytes(4));
            if (!rename($path, $old) || !rename($temporary, $path)) {
                @rename($old, $path);
                @unlink($temporary);
                throw new RuntimeException('Unable to publish the static page.');
            }
            @unlink($old);
        } elseif (!rename($temporary, $path)) {
            @unlink($temporary);
            throw new RuntimeException('Unable to publish the static page.');
        }
    }
}
