<?php

declare(strict_types=1);

namespace BoardHub;

use JsonException;
use RuntimeException;

final readonly class BoardConfigService
{
    public function __construct(private Config $config)
    {
    }

    public function update(
        Board $board,
        string $title,
        string $description,
        string $postingMode,
        int $threadsPerPage,
    ): void {
        $configPath = $board->configPath();
        $raw = file_get_contents($configPath);
        if (!is_string($raw)) {
            throw new RuntimeException('Unable to read the board configuration.');
        }
        try {
            $data = json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new RuntimeException('The board configuration is invalid: ' . $error->getMessage(), 0, $error);
        }
        if (!is_array($data)) {
            throw new RuntimeException('The board configuration must contain an object.');
        }

        $data['title'] = $title;
        $data['description'] = $description;
        $data['posting_mode'] = $postingMode;
        $data['posting_enabled'] = $postingMode !== 'closed';
        $data['threads_per_page'] = $threadsPerPage;
        $encoded = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR) . PHP_EOL;
        $this->atomicWrite($configPath, $encoded);
    }

    private function atomicWrite(string $path, string $contents): void
    {
        $expectedRoot = realpath($this->config->webRoot);
        $expectedBoard = realpath(dirname($path));
        if (!is_string($expectedRoot) || !is_string($expectedBoard)
            || !str_starts_with(strtolower($expectedBoard . DIRECTORY_SEPARATOR), strtolower($expectedRoot . DIRECTORY_SEPARATOR))) {
            throw new RuntimeException('Refusing to write outside the public board root.');
        }

        $temporary = $path . '.' . bin2hex(random_bytes(8)) . '.tmp';
        $handle = fopen($temporary, 'xb');
        if ($handle === false) {
            throw new RuntimeException('Unable to create a temporary board configuration.');
        }
        try {
            $remaining = $contents;
            while ($remaining !== '') {
                $written = fwrite($handle, $remaining);
                if ($written === false || $written === 0) {
                    throw new RuntimeException('Unable to write the board configuration.');
                }
                $remaining = substr($remaining, $written);
            }
            fflush($handle);
            if (function_exists('fsync')) {
                fsync($handle);
            }
        } finally {
            fclose($handle);
        }

        if (PHP_OS_FAMILY === 'Windows' && is_file($path)) {
            $old = $path . '.old-' . bin2hex(random_bytes(4));
            if (!rename($path, $old) || !rename($temporary, $path)) {
                @rename($old, $path);
                @unlink($temporary);
                throw new RuntimeException('Unable to replace the board configuration.');
            }
            @unlink($old);
        } elseif (!rename($temporary, $path)) {
            @unlink($temporary);
            throw new RuntimeException('Unable to replace the board configuration.');
        }
    }
}