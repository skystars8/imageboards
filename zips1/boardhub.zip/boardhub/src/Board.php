<?php

declare(strict_types=1);

namespace BoardHub;

final readonly class Board
{
    public bool $postingEnabled;

    public function __construct(
        public string $id,
        public string $slug,
        public string $title,
        public string $description,
        public string $postingMode,
        public int $threadsPerPage,
        public string $path,
    ) {
        $this->postingEnabled = $postingMode !== 'closed';
    }

    public function privatePath(): string
    {
        return $this->path . '/.board';
    }

    public function configPath(): string
    {
        return $this->privatePath() . '/board.json';
    }

    public function identityPath(): string
    {
        return $this->privatePath() . '/.board-id';
    }

    public function databasePath(): string
    {
        return $this->privatePath() . '/board.sqlite3';
    }

    public function uploadsPath(): string
    {
        return $this->path . '/uploads';
    }
}

