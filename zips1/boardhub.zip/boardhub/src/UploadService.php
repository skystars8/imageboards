<?php

declare(strict_types=1);

namespace BoardHub;

use GdImage;
use RuntimeException;

final class UploadService
{
    /** @param array<string, mixed>|null $file */
    public function accept(?array $file, Board $board, Config $config): ?Upload
    {
        if ($file === null || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? null) !== UPLOAD_ERR_OK) {
            throw new HttpException(400, 'The image upload did not complete.');
        }
        $temporary = $file['tmp_name'] ?? null;
        $size = $file['size'] ?? null;
        $originalName = $file['name'] ?? 'image';
        if (!is_string($temporary) || !is_file($temporary) || !is_int($size) || $size < 1 || $size > $config->maxUploadBytes) {
            throw new HttpException(400, 'The uploaded image is invalid or too large.');
        }
        if (!is_string($originalName)) {
            $originalName = 'image';
        }

        $info = @getimagesize($temporary);
        if (!is_array($info) || !isset($info[0], $info[1])) {
            throw new HttpException(400, 'Only valid raster images are accepted.');
        }
        $width = (int) $info[0];
        $height = (int) $info[1];
        if ($width < 1 || $height < 1 || $width > $config->maxImageDimension || $height > $config->maxImageDimension || $width * $height > $config->maxImagePixels) {
            throw new HttpException(400, 'The image dimensions are too large.');
        }
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($temporary);
        $extensions = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp'];
        if (!is_string($mime) || !isset($extensions[$mime])) {
            throw new HttpException(400, 'Allowed image formats: JPEG, PNG, GIF, and WebP.');
        }
        $contents = file_get_contents($temporary);
        $source = is_string($contents) ? @imagecreatefromstring($contents) : false;
        if (!$source instanceof GdImage) {
            throw new HttpException(400, 'The image could not be decoded safely.');
        }

        $originalDirectory = $board->uploadsPath() . '/originals';
        $thumbnailDirectory = $board->uploadsPath() . '/thumbs';
        Config::ensureDirectory($originalDirectory, 0755);
        Config::ensureDirectory($thumbnailDirectory, 0755);
        $stem = bin2hex(random_bytes(20));
        $storedName = $stem . '.' . $extensions[$mime];
        $thumbnailName = $stem . '.jpg';
        $originalPath = $originalDirectory . '/' . $storedName;
        $thumbnailPath = $thumbnailDirectory . '/' . $thumbnailName;
        if (!move_uploaded_file($temporary, $originalPath)) {
            imagedestroy($source);
            throw new RuntimeException('Unable to store the uploaded image.');
        }

        $scale = min(1.0, 300 / max($width, $height));
        $thumbWidth = max(1, (int) round($width * $scale));
        $thumbHeight = max(1, (int) round($height * $scale));
        $thumbnail = imagecreatetruecolor($thumbWidth, $thumbHeight);
        if (!$thumbnail instanceof GdImage) {
            @unlink($originalPath);
            imagedestroy($source);
            throw new RuntimeException('Unable to allocate the thumbnail.');
        }
        imagefill($thumbnail, 0, 0, imagecolorallocate($thumbnail, 245, 245, 245));
        imagecopyresampled($thumbnail, $source, 0, 0, 0, 0, $thumbWidth, $thumbHeight, $width, $height);
        $written = imagejpeg($thumbnail, $thumbnailPath, 86);
        imagedestroy($thumbnail);
        imagedestroy($source);
        if (!$written) {
            @unlink($originalPath);
            throw new RuntimeException('Unable to write the thumbnail.');
        }

        return new Upload(
            originalName: mb_substr(basename(str_replace('\\', '/', $originalName)), 0, 255),
            storedName: $storedName,
            thumbnailName: $thumbnailName,
            mimeType: $mime,
            size: $size,
            width: $width,
            height: $height,
        );
    }

    public function discard(?Upload $upload, Board $board): void
    {
        if ($upload === null) {
            return;
        }
        @unlink($board->uploadsPath() . '/originals/' . $upload->storedName);
        @unlink($board->uploadsPath() . '/thumbs/' . $upload->thumbnailName);
    }
}
