<?php

declare(strict_types=1);

namespace BoardHub;

use BoardHub\Support\Uuid;
use InvalidArgumentException;
use RuntimeException;
use Throwable;

final readonly class BoardCreationService
{
    private const RESERVED_SLUGS = [
        'all',
        'backups',
        'bin',
        'board-template',
        'compose',
        'config',
        'database',
        'generated',
        'healthz',
        'media',
        'mod',
        'post',
        'public',
        'report',
        'site-data',
        'src',
        'static',
        'stylesheets',
        'tests',
        'tools',
        'var',
    ];

    public function __construct(private Config $config)
    {
    }

    public function create(string $slug, string $title, string $description): Board
    {
        $slug = strtolower(trim($slug));
        $title = trim($title);
        $description = trim($description);
        $this->validate($slug, $title, $description);

        $boardsRoot = realpath($this->config->webRoot);
        $templateRoot = realpath($this->config->templatePath);
        if (!is_string($boardsRoot) || !is_dir($boardsRoot)) {
            throw new RuntimeException('The web root is unavailable.');
        }
        if (!is_string($templateRoot) || !is_dir($templateRoot)) {
            throw new RuntimeException('The board template directory is unavailable.');
        }

        $boardPath = $boardsRoot . DIRECTORY_SEPARATOR . $slug;
        if (file_exists($boardPath) || is_link($boardPath)) {
            throw new InvalidArgumentException('That board address is already in use.');
        }

        $stagingPath = $boardsRoot . DIRECTORY_SEPARATOR . '_create-' . $slug . '-' . bin2hex(random_bytes(6));
        $published = false;
        try {
            $this->copyTree($templateRoot, $stagingPath);
            $id = Uuid::v4();
            $settings = json_encode([
                'title' => $title,
                'description' => $description,
                'posting_mode' => 'closed',
                'posting_enabled' => false,
                'threads_per_page' => 10,
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
            $this->writeFile($stagingPath . DIRECTORY_SEPARATOR . '.board' . DIRECTORY_SEPARATOR . 'board.json', $settings . PHP_EOL);
            $this->writeFile($stagingPath . DIRECTORY_SEPARATOR . '.board' . DIRECTORY_SEPARATOR . '.board-id', $id . PHP_EOL);

            $candidate = new Board($id, $slug, $title, $description, 'closed', 10, $stagingPath);
            $store = new BoardStore($this->config, $candidate);
            unset($store);

            if (!rename($stagingPath, $boardPath)) {
                throw new RuntimeException('Unable to publish the new board directory.');
            }
            $published = true;

            $created = (new BoardRegistry($this->config))->get($slug);
            if ($created === null) {
                throw new RuntimeException('The new board could not be loaded after creation.');
            }

            return $created;
        } catch (Throwable $error) {
            $this->removeTree($published ? $boardPath : $stagingPath);
            throw $error;
        }
    }

    private function validate(string $slug, string $title, string $description): void
    {
        if (!preg_match('/\A[a-z0-9][a-z0-9-]{0,39}\z/', $slug)
            || in_array($slug, self::RESERVED_SLUGS, true)
            || preg_match('/\A(?:con|prn|aux|nul|com[1-9]|lpt[1-9])\z/i', $slug)) {
            throw new InvalidArgumentException(
                'Invalid URL slug. Use 1–40 lowercase letters, numbers, or hyphens; reserved routes cannot be used.'
            );
        }
        if ($title === '' || mb_strlen($title) > 80) {
            throw new InvalidArgumentException('Board name must be between 1 and 80 characters.');
        }
        if (mb_strlen($description) > 300) {
            throw new InvalidArgumentException('Board description must be at most 300 characters.');
        }
    }

    private function copyTree(string $source, string $destination): void
    {
        $mode = basename($destination) === '.board' ? 0750 : 0755;
        if (!mkdir($destination, $mode) && !is_dir($destination)) {
            throw new RuntimeException('Unable to create the temporary board directory.');
        }
        foreach (new \DirectoryIterator($source) as $entry) {
            if ($entry->isDot()) {
                continue;
            }
            if ($entry->isLink()) {
                throw new RuntimeException('The board template may not contain symbolic links.');
            }
            $target = $destination . DIRECTORY_SEPARATOR . $entry->getFilename();
            if ($entry->isDir()) {
                $this->copyTree($entry->getPathname(), $target);
            } elseif ($entry->isFile() && !copy($entry->getPathname(), $target)) {
                throw new RuntimeException('Unable to copy a board template file.');
            }
        }
    }

    private function writeFile(string $path, string $contents): void
    {
        if (file_put_contents($path, $contents, LOCK_EX) === false) {
            throw new RuntimeException('Unable to write the new board configuration.');
        }
    }

    private function removeTree(string $path): void
    {
        $boardsRoot = realpath($this->config->webRoot);
        $absolute = realpath($path);
        if ($absolute === false) {
            return;
        }
        if (!is_string($boardsRoot)
            || !str_starts_with(strtolower($absolute . DIRECTORY_SEPARATOR), strtolower($boardsRoot . DIRECTORY_SEPARATOR))) {
            throw new RuntimeException('Refusing to clean up outside the web root.');
        }
        $this->removeTreeContents($absolute);
    }

    private function removeTreeContents(string $path): void
    {
        if (is_link($path) || is_file($path)) {
            @unlink($path);
            return;
        }
        foreach (new \DirectoryIterator($path) as $entry) {
            if ($entry->isDot()) {
                continue;
            }
            $child = $entry->getPathname();
            if ($entry->isLink() || $entry->isFile()) {
                @unlink($child);
            } else {
                $this->removeTreeContents($child);
            }
        }
        @rmdir($path);
    }
}
