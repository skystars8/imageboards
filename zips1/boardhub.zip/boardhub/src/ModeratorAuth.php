<?php

declare(strict_types=1);

namespace BoardHub;

final class ModeratorAuth
{
    private const COOKIE = 'boardhub_mod';

    public function __construct(
        private readonly Config $config,
        private readonly ControlStore $store,
        private readonly Security $security,
    ) {
    }

    public function login(string $username, string $password): void
    {
        $sessionKey = $this->security->rateLimitKey('moderator-login');
        $accountKey = hash('sha256', 'moderator-account' . chr(0) . strtolower(trim($username)));
        $rateKeys = array_unique([$sessionKey, $accountKey]);
        foreach ($rateKeys as $rateKey) {
            if (!$this->store->loginAllowed($rateKey)) {
                throw new RateLimitException('Too many login attempts. Try again later.');
            }
        }
        foreach ($rateKeys as $rateKey) {
            $this->store->recordLoginAttempt($rateKey);
        }
        $moderator = $this->store->moderatorByUsername(trim($username));
        if ($moderator === null || !password_verify($password, $moderator['password_hash'])) {
            throw new HttpException(401, 'Invalid username or password.');
        }

        $token = rtrim(strtr(base64_encode(random_bytes(48)), '+/', '-_'), '=');
        $csrf = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        $this->store->createSession($moderator['id'], hash('sha256', $token), $csrf);
        setcookie(self::COOKIE, $token, [
            'expires' => time() + 43200,
            'path' => '/mod',
            'secure' => $this->config->secureCookies,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
    }

    /** @return array{username:string,csrf_token:string}|null */
    public function user(): ?array
    {
        $token = $_COOKIE[self::COOKIE] ?? null;
        if (!is_string($token) || strlen($token) < 43) {
            return null;
        }

        return $this->store->session(hash('sha256', $token));
    }

    /** @return array{username:string,csrf_token:string} */
    public function requireUser(): array
    {
        return $this->user() ?? throw new HttpException(401, 'Moderator login required.');
    }

    public function verifyCsrf(?string $token): array
    {
        $user = $this->requireUser();
        if (!is_string($token) || !hash_equals($user['csrf_token'], $token)) {
            throw new HttpException(403, 'The moderator form expired. Reload it and try again.');
        }

        return $user;
    }

    public function logout(): void
    {
        $token = $_COOKIE[self::COOKIE] ?? null;
        if (is_string($token)) {
            $this->store->deleteSession(hash('sha256', $token));
        }
        setcookie(self::COOKIE, '', [
            'expires' => 1,
            'path' => '/mod',
            'secure' => $this->config->secureCookies,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
    }
}
