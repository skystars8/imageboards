<?php

declare(strict_types=1);

namespace BoardHub;

use RuntimeException;

final class SiteLock
{
    /** @var resource */
    private $handle;

    private function __construct($handle)
    {
        $this->handle = $handle;
    }

    public static function shared(Config $config): self
    {
        return self::acquire($config->writeLockPath, LOCK_SH);
    }

    public static function exclusive(Config $config): self
    {
        return self::acquire($config->writeLockPath, LOCK_EX);
    }

    public static function publisher(Config $config): self
    {
        return self::acquire($config->siteDataPath . '/publisher.lock', LOCK_EX);
    }

    public function release(): void
    {
        if (is_resource($this->handle)) {
            flock($this->handle, LOCK_UN);
            fclose($this->handle);
        }
    }

    public function __destruct()
    {
        $this->release();
    }

    private static function acquire(string $path, int $operation): self
    {
        $handle = fopen($path, 'c+');
        if ($handle === false || !flock($handle, $operation)) {
            if (is_resource($handle)) {
                fclose($handle);
            }
            throw new RuntimeException('Unable to acquire the site write lock.');
        }

        return new self($handle);
    }
}
