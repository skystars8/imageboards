<?php

declare(strict_types=1);

namespace BoardHub;

final class Security
{
    public function __construct(private readonly Config $config)
    {
    }

    public function startPublicSession(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            return;
        }
        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');
        session_name('boardhub_form');
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => $this->config->secureCookies,
            'httponly' => true,
            'samesite' => 'Strict',
        ]);
        session_start();
    }

    public function csrfToken(): string
    {
        $this->startPublicSession();
        $token = $_SESSION['csrf_token'] ?? null;
        if (!is_string($token) || strlen($token) < 43) {
            $token = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
            $_SESSION['csrf_token'] = $token;
        }

        return $token;
    }

    public function rateLimitKey(string $purpose): string
    {
        $this->startPublicSession();
        $seed = $_SESSION['rate_limit_seed'] ?? null;
        if (!is_string($seed) || strlen($seed) < 43) {
            $seed = rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
            $_SESSION['rate_limit_seed'] = $seed;
        }

        return hash('sha256', $purpose . chr(0) . $seed);
    }

    public function verifyCsrf(?string $token): void
    {
        $expected = $this->csrfToken();
        if (!is_string($token) || !hash_equals($expected, $token)) {
            throw new HttpException(403, 'The form expired. Go back, reload it, and try again.');
        }
    }
}
