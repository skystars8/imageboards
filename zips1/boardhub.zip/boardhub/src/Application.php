<?php

declare(strict_types=1);

namespace BoardHub;

final class Application
{
    private readonly BoardRegistry $registry;
    private readonly Renderer $renderer;
    private readonly Publisher $publisher;
    private readonly Security $security;

    public function __construct(private readonly Config $config)
    {
        $this->registry = new BoardRegistry($config);
        $this->renderer = new Renderer($config->javascriptFeatures);
        $this->publisher = new Publisher($config, $this->registry, $this->renderer);
        $this->security = new Security($config);
    }

    public function handle(): never
    {
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $path = rawurldecode((string) parse_url($uri, PHP_URL_PATH));

        if ($method === 'GET' && $path === '/healthz') {
            Response::text('ok');
        }
        if ($method === 'GET' && $path === '/compose') {
            $this->compose();
        }
        if ($method === 'GET' && $path === '/quick-reply-data') {
            $this->quickReplyData();
        }
        if ($method === 'POST' && $path === '/post') {
            $this->post();
        }
        if ($path === '/report' && in_array($method, ['GET', 'POST'], true)) {
            $this->report($method);
        }
        if (str_starts_with($path, '/mod')) {
            $this->moderation($method, $path);
        }
        if ($method === 'GET' && preg_match('#\A/([a-z0-9][a-z0-9-]{0,39})/uploads/(originals|thumbs)/([a-f0-9]{40}\.(?:jpg|png|gif|webp))\z#', $path, $match)) {
            $this->media($match[1], $match[2], $match[3]);
        }
        if ($method === 'GET') {
            $this->publicPage($path);
        }
        throw new HttpException(405, 'Method not allowed.');
    }

    private function publicPage(string $path): never
    {
        $file = null;
        if ($path === '/') {
            $file = $this->config->webRoot . '/index.html';
        } elseif ($path === '/all' || $path === '/all/') {
            $file = $this->config->webRoot . '/all/index.html';
        } elseif (preg_match('#\A/([a-z0-9][a-z0-9-]{0,39})/?\z#', $path, $match)) {
            $board = $this->board($match[1]);
            $file = $board->path . '/index.html';
        } elseif (preg_match('#\A/([a-z0-9][a-z0-9-]{0,39})/catalog/?\z#', $path, $match)) {
            $board = $this->board($match[1]);
            $file = $board->path . '/catalog/index.html';
        } elseif (preg_match('#\A/([a-z0-9][a-z0-9-]{0,39})/thread/([1-9][0-9]*)/?\z#', $path, $match)) {
            $board = $this->board($match[1]);
            $file = $board->path . '/threads/' . $match[2] . '.html';
        }
        if ($file === null) {
            throw new HttpException(404, 'Page not found.');
        }
        if (!is_file($file)) {
            $this->publisher->publishAll(true);
        }
        if (!is_file($file)) {
            throw new HttpException(404, 'Page not found.');
        }
        $contents = file_get_contents($file);
        if (!is_string($contents)) {
            throw new HttpException(503, 'The static page is temporarily unavailable.');
        }
        Response::html($contents);
    }

    private function compose(): never
    {
        $board = $this->board($this->inputString($_GET, 'board', 40));
        $store = new BoardStore($this->config, $board);
        if ($store->postingPolicy()['posting_mode'] === 'closed') {
            throw new HttpException(409, 'Posting is paused on this board.');
        }
        $thread = null;
        $threadId = $this->optionalInteger($_GET, 'thread');
        if ($threadId !== null) {
            $thread = $store->post($threadId);
            if ($thread === null || (int) $thread['thread_id'] !== $threadId
                || (int) $thread['is_op'] !== 1 || (int) $thread['deleted'] === 1
                || (int) $thread['approved'] !== 1) {
                throw new HttpException(404, 'Thread not found.');
            }
            if ((int) $thread['locked'] === 1) {
                throw new HttpException(409, 'This thread is locked.');
            }
        }
        Response::html($this->renderer->compose(
            $board,
            $thread,
            $this->security->csrfToken(),
            $this->registry->all()
        ));
    }

    private function quickReplyData(): never
    {
        $board = $this->board($this->inputString($_GET, 'board', 40));
        $store = new BoardStore($this->config, $board);
        $policy = $store->postingPolicy();
        if ($policy['posting_mode'] === 'closed') {
            throw new HttpException(409, 'Posting is paused on this board.');
        }

        $threadId = $this->requiredInteger($_GET, 'thread');
        $thread = $store->post($threadId);
        if ($thread === null || (int) $thread['thread_id'] !== $threadId
            || (int) $thread['is_op'] !== 1 || (int) $thread['deleted'] === 1
            || (int) $thread['approved'] !== 1) {
            throw new HttpException(404, 'Thread not found.');
        }
        if ((int) $thread['locked'] === 1) {
            throw new HttpException(409, 'This thread is locked.');
        }

        Response::json([
            'csrf' => $this->security->csrfToken(),
            'board' => $board->slug,
            'thread' => $threadId,
            'password_required' => $policy['posting_mode'] === 'password',
            'max_upload_bytes' => $this->config->maxUploadBytes,
        ]);
    }
    private function post(): never
    {
        $this->security->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
        $board = $this->board($this->inputString($_POST, 'board', 40));
        $store = new BoardStore($this->config, $board);
        $policy = $store->postingPolicy();
        if ($policy['posting_mode'] === 'closed') {
            throw new HttpException(409, 'Posting is paused on this board.');
        }
        $threadId = $this->optionalInteger($_POST, 'thread');
        $name = $this->inputString($_POST, 'name', 80);
        $body = $this->inputString($_POST, 'body', 100000);
        $subject = $threadId === null ? $this->inputString($_POST, 'subject', 120) : '';
        $verifiedPasswordHash = null;
        if ($policy['posting_mode'] === 'password') {
            $password = $_POST['board_password'] ?? null;
            if (!is_string($password)) {
                throw new HttpException(403, 'Incorrect board posting password.');
            }
            $verifiedPasswordHash = $store->verifyPostingPassword(
                trim($password),
                $this->security->rateLimitKey('posting-password:' . $board->id)
            );
            if ($verifiedPasswordHash === null) {
                throw new HttpException(403, 'Incorrect board posting password.');
            }
        }

        $lock = SiteLock::shared($this->config);
        $upload = null;
        try {
            $uploads = new UploadService();
            $upload = $uploads->accept(
                isset($_FILES['image']) && is_array($_FILES['image']) ? $_FILES['image'] : null,
                $board,
                $this->config
            );
            try {
                $result = $store->createPost(
                    $threadId,
                    $name,
                    $subject,
                    $body,
                    $upload,
                    $this->security->rateLimitKey('post:' . $board->id),
                    $verifiedPasswordHash
                );
            } catch (\Throwable $error) {
                $uploads->discard($upload, $board);
                throw $error;
            }
        } finally {
            $lock->release();
        }

        if (!$result['approved']) {
            Response::html($this->renderer->message(
                'Submission awaiting approval',
                'Your submission was received and remains private until a moderator approves it.',
                $this->registry->all()
            ), 202);
        }
        try {
            $this->publisher->publishBoard($board);
            $this->publisher->publishShared();
        } catch (\Throwable $error) {
            error_log('Static publish deferred: ' . $error->getMessage());
        }
        Response::redirect('/' . rawurlencode($board->slug) . '/thread/' . $result['thread_id'] . '#p' . $result['id']);
    }
    private function report(string $method): never
    {
        if ($method === 'GET') {
            $board = $this->board($this->inputString($_GET, 'board', 40));
            $post = (new BoardStore($this->config, $board))->post($this->requiredInteger($_GET, 'post'));
            if ($post === null || (int) $post['deleted'] === 1 || (int) $post['approved'] !== 1) {
                throw new HttpException(404, 'Post not found.');
            }
            Response::html($this->renderer->report($board, $post, $this->security->csrfToken(), $this->registry->all()));
        }
        $this->security->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
        $board = $this->board($this->inputString($_POST, 'board', 40));
        $postId = $this->requiredInteger($_POST, 'post');
        $reason = $this->inputString($_POST, 'reason', 500);
        $lock = SiteLock::shared($this->config);
        (new BoardStore($this->config, $board))->reportPost(
            $postId,
            $this->security->rateLimitKey('report:' . $board->id),
            $reason
        );
        $lock->release();
        Response::html($this->renderer->message('Report received', 'Thank you. A moderator can now review it from the global desk.', $this->registry->all()), 201);
    }

    private function moderation(string $method, string $path): never
    {
        $control = new ControlStore($this->config);
        $auth = new ModeratorAuth($this->config, $control, $this->security);

        if ($path === '/mod/login' && $method === 'GET') {
            $user = $auth->user();
            if ($user !== null) {
                Response::redirect('/mod');
            }
            Response::html($this->renderer->moderatorLogin(
                $this->registry->all(),
                $this->security->csrfToken()
            ));
        }
        if ($path === '/mod/login' && $method === 'POST') {
            $this->security->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
            $auth->login($this->inputString($_POST, 'username', 40), $this->inputString($_POST, 'password', 1000));
            Response::redirect('/mod');
        }
        if ($path === '/mod/logout' && $method === 'POST') {
            $auth->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
            $auth->logout();
            Response::redirect('/mod');
        }

        if (($path === '/mod' || $path === '/mod/') && $method === 'GET') {
            $user = $auth->requireUser();
            $feed = $this->moderatorFeed();
            Response::html($this->renderer->moderatorDashboard(
                $feed['activity'],
                $this->registry->all(),
                $user,
                $feed['issues'],
                $feed['open_report_count'],
                $feed['pending_count']
            ));
        }
        if (($path === '/mod/approval' || $path === '/mod/approval/') && $method === 'GET') {
            $user = $auth->requireUser();
            $feed = $this->moderatorFeed();
            Response::html($this->renderer->moderatorApproval(
                $feed['pending'],
                $this->registry->all(),
                $user,
                $feed['issues'],
                $feed['open_report_count'],
                $feed['pending_count']
            ));
        }        if (($path === '/mod/reports' || $path === '/mod/reports/') && $method === 'GET') {
            $user = $auth->requireUser();
            $feed = $this->moderatorFeed();
            Response::html($this->renderer->moderatorReports(
                $feed['reports'],
                $this->registry->all(),
                $user,
                $feed['issues'],
                $feed['open_report_count'],
                $feed['pending_count']
            ));
        }
        if (($path === '/mod/boards' || $path === '/mod/boards/') && $method === 'GET') {
            $user = $auth->requireUser();
            $this->renderModeratorBoards($user);
        }
        if (($path === '/mod/boards' || $path === '/mod/boards/') && $method === 'POST') {
            $user = $auth->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
            $this->moderatorBoardCreate($control, $user);
        }
        if ($path === '/mod/boards/edit' && $method === 'GET') {
            $user = $auth->requireUser();
            $board = $this->board($this->inputString($_GET, 'board', 40));
            $boardFeed = $this->moderatorBoardsFeed();
            $store = new BoardStore($this->config, $board);
            $stats = $store->moderationStats();
            $policy = $store->postingPolicy();
            Response::html($this->renderer->moderatorBoardEdit(
                $board,
                $stats,
                $this->registry->all(),
                $user,
                $boardFeed['open_report_count'],
                $boardFeed['pending_count'],
                $policy['posting_password_hash'] !== null
            ));
        }
        if ($path === '/mod/boards/edit' && $method === 'POST') {
            $user = $auth->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
            $this->moderatorBoardSave($control, $user['username']);
        }
        if ($path === '/mod/edit' && $method === 'GET') {
            $user = $auth->requireUser();
            $board = $this->board($this->inputString($_GET, 'board', 40));
            $post = (new BoardStore($this->config, $board))->post($this->requiredInteger($_GET, 'post'));
            $returnTo = $this->moderatorReturnTo($_GET['return_to'] ?? null);
            if ($post === null || (int) $post['deleted'] === 1) {
                Response::redirect($returnTo);
            }
            $feed = $this->moderatorFeed();
            Response::html($this->renderer->moderatorEdit(
                $board,
                $post,
                $user,
                $this->registry->all(),
                $returnTo,
                $feed['open_report_count'],
                $feed['pending_count']
            ));
        }
        if ($path === '/mod/rebuild' && $method === 'POST') {
            $user = $auth->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
            $returnTo = $this->moderatorReturnTo($_POST['return_to'] ?? null);
            $lock = SiteLock::exclusive($this->config);
            try {
                $failures = $this->publisher->publishAll(true);
                $control->audit($user['username'], 'rebuild_static_pages', null, ['failures' => $failures]);
                if ($failures !== []) {
                    throw new \RuntimeException('Some boards could not be rebuilt: ' . implode(', ', array_keys($failures)));
                }
            } finally {
                $lock->release();
            }
            Response::redirect($returnTo);
        }
        if ($path === '/mod/action' && $method === 'POST') {
            $user = $auth->verifyCsrf($this->nullableString($_POST['csrf'] ?? null));
            $this->moderatorAction($control, $user['username']);
        }
        throw new HttpException(404, 'Moderator page not found.');
    }

    private function moderatorAction(ControlStore $control, string $moderator): never
    {
        $returnTo = $this->moderatorReturnTo($_POST['return_to'] ?? null);
        $board = $this->board($this->inputString($_POST, 'board', 40));
        $action = $this->inputString($_POST, 'action', 20);
        $store = new BoardStore($this->config, $board);
        $lock = SiteLock::exclusive($this->config);
        $publicChanged = false;
        $details = [];
        try {
            if ($action === 'resolve') {
                $reportId = $this->requiredInteger($_POST, 'report');
                $store->resolveReport($reportId, $moderator);
                $details = ['report_id' => $reportId];
            } else {
                $postId = $this->requiredInteger($_POST, 'post');
                $details = ['post_id' => $postId];
                if ($action === 'delete') {
                    $store->softDelete($postId, $moderator);
                    $publicChanged = true;
                } elseif ($action === 'sticky' || $action === 'locked') {
                    $enabled = $store->toggleThread($postId, $action, $moderator);
                    $details['enabled'] = $enabled;
                    $publicChanged = true;
                } elseif ($action === 'approve') {
                    $approved = $store->approvePost($postId, $moderator);
                    $details['thread_id'] = $approved['thread_id'];
                    $publicChanged = true;
                } elseif ($action === 'reject_pending') {
                    $files = $store->rejectPending($postId, $moderator);
                    foreach ($files['originals'] as $filename) {
                        @unlink($board->uploadsPath() . '/originals/' . $filename);
                    }
                    foreach ($files['thumbs'] as $filename) {
                        @unlink($board->uploadsPath() . '/thumbs/' . $filename);
                    }
                    $details['removed_images'] = count($files['originals']) + count($files['thumbs']);
                } elseif ($action === 'edit') {
                    $removeImage = ($_POST['remove_image'] ?? null) === '1';
                    $uploads = new UploadService();
                    $upload = $uploads->accept(
                        isset($_FILES['image']) && is_array($_FILES['image']) ? $_FILES['image'] : null,
                        $board,
                        $this->config
                    );
                    if ($removeImage && $upload !== null) {
                        $uploads->discard($upload, $board);
                        throw new HttpException(400, 'Choose either remove image or upload a replacement, not both.');
                    }
                    try {
                        $result = $store->editPost(
                            $postId,
                            $this->inputString($_POST, 'name', 80),
                            trim((string) ($_POST['subject'] ?? '')),
                            $this->inputString($_POST, 'body', 100000),
                            $moderator,
                            $upload,
                            $removeImage
                        );
                    } catch (\Throwable $error) {
                        $uploads->discard($upload, $board);
                        throw $error;
                    }
                    if ($result['image_changed']) {
                        if ($result['old_original'] !== null && $result['old_original'] !== $upload?->storedName) {
                            @unlink($board->uploadsPath() . '/originals/' . $result['old_original']);
                        }
                        if ($result['old_thumbnail'] !== null && $result['old_thumbnail'] !== $upload?->thumbnailName) {
                            @unlink($board->uploadsPath() . '/thumbs/' . $result['old_thumbnail']);
                        }
                    }
                    $details['image_changed'] = $result['image_changed'];
                    $publicChanged = $result['public_changed'];
                } else {
                    throw new HttpException(400, 'Invalid moderation action.');
                }
            }

            $control->audit($moderator, $action, $board->slug, $details);
            if ($publicChanged) {
                try {
                    $this->publisher->publishBoard($board);
                    $this->publisher->publishShared();
                } catch (\Throwable $error) {
                    error_log('Static publish deferred: ' . $error->getMessage());
                }
            }
        } finally {
            $lock->release();
        }
        Response::redirect($returnTo);
    }
    /** @param array{username:string,csrf_token:string} $user */
    private function moderatorBoardCreate(ControlStore $control, array $user): never
    {
        foreach (['slug', 'name', 'description'] as $field) {
            if (!isset($_POST[$field]) || !is_string($_POST[$field])) {
                throw new HttpException(400, 'Missing field: ' . $field . '.');
            }
        }
        $slug = strtolower(trim($_POST['slug']));
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);

        try {
            $lock = SiteLock::exclusive($this->config);
            try {
                $created = (new BoardCreationService($this->config))->create($slug, $name, $description);
                $control->audit($user['username'], 'create_board', $created->slug, [
                    'title' => $created->title,
                    'posting_mode' => 'closed',
                    'posting_enabled' => false,
                    'threads_per_page' => $created->threadsPerPage,
                ]);
                $freshRegistry = new BoardRegistry($this->config);
                $freshPublisher = new Publisher($this->config, $freshRegistry, $this->renderer);
                $freshPublisher->publishBoard($created, true);
                $freshPublisher->publishShared();
            } finally {
                $lock->release();
            }
        } catch (\InvalidArgumentException $error) {
            $this->renderModeratorBoards($user, $error->getMessage(), $slug, $name, $description);
        }

        Response::redirect('/mod/boards/edit?board=' . rawurlencode($created->slug));
    }

    /** @param array{username:string,csrf_token:string} $user */
    private function renderModeratorBoards(
        array $user,
        ?string $createError = null,
        string $newSlug = '',
        string $newName = '',
        string $newDescription = '',
    ): never {
        $boardFeed = $this->moderatorBoardsFeed();
        Response::html($this->renderer->moderatorBoards(
            $boardFeed['boards'],
            $this->registry->all(),
            $user,
            $boardFeed['issues'],
            $boardFeed['open_report_count'],
            $boardFeed['pending_count'],
            $createError,
            $newSlug,
            $newName,
            $newDescription,
        ));
    }

    private function moderatorBoardSave(ControlStore $control, string $moderator): never
    {
        $board = $this->board($this->inputString($_POST, 'board', 40));
        $title = $this->inputString($_POST, 'title', 80);
        $descriptionValue = $_POST['description'] ?? null;
        if (!is_string($descriptionValue)) {
            throw new HttpException(400, 'Missing field: description.');
        }
        $description = trim($descriptionValue);
        if (mb_strlen($description) > 300) {
            throw new HttpException(400, 'Board description must be at most 300 characters.');
        }
        $threadsPerPage = $this->requiredInteger($_POST, 'threads_per_page');
        if ($threadsPerPage > 50) {
            throw new HttpException(400, 'Threads per page must be between 1 and 50.');
        }
        $postingMode = $this->inputString($_POST, 'posting_mode', 20);
        if (!in_array($postingMode, ['open', 'approval', 'password', 'closed'], true)) {
            throw new HttpException(400, 'Invalid board posting mode.');
        }
        $passwordValue = $_POST['posting_password'] ?? '';
        if (!is_string($passwordValue)) {
            throw new HttpException(400, 'Invalid posting password.');
        }
        $passwordValue = trim($passwordValue);
        $clearPassword = ($_POST['clear_posting_password'] ?? null) === '1';
        if ($clearPassword && $passwordValue !== '') {
            throw new HttpException(400, 'Choose either replace password or clear password, not both.');
        }

        $store = new BoardStore($this->config, $board);
        $oldPolicy = $store->postingPolicy();
        $newPasswordHash = $oldPolicy['posting_password_hash'];
        if ($passwordValue !== '') {
            $newPasswordHash = BoardStore::hashPostingPassword($passwordValue);
        } elseif ($clearPassword) {
            $newPasswordHash = null;
        }
        if ($postingMode === 'password' && $newPasswordHash === null) {
            throw new HttpException(400, 'Set a posting password before enabling password mode.');
        }

        $lock = SiteLock::exclusive($this->config);
        try {
            $store->updatePostingPolicy($postingMode, $newPasswordHash);
            try {
                (new BoardConfigService($this->config))->update(
                    $board,
                    $title,
                    $description,
                    $postingMode,
                    $threadsPerPage
                );
            } catch (\Throwable $error) {
                $store->updatePostingPolicy(
                    $oldPolicy['posting_mode'],
                    $oldPolicy['posting_password_hash']
                );
                throw $error;
            }
            $control->audit($moderator, 'update_board_settings', $board->slug, [
                'title' => $title,
                'posting_mode' => $postingMode,
                'posting_password_changed' => $passwordValue !== '' || $clearPassword,
                'threads_per_page' => $threadsPerPage,
            ]);

            $freshRegistry = new BoardRegistry($this->config);
            $freshBoard = $freshRegistry->get($board->slug);
            if ($freshBoard === null) {
                throw new \RuntimeException('The updated board could not be reloaded.');
            }
            $freshPublisher = new Publisher($this->config, $freshRegistry, $this->renderer);
            $freshPublisher->publishBoard($freshBoard, true);
            $freshPublisher->publishShared();
        } finally {
            $lock->release();
        }
        Response::redirect('/mod/boards');
    }
    /** @return array{
     *     reports:list<array{board:Board,report:array<string,mixed>,post:array<string,mixed>}>,
     *     activity:list<array{board:Board,post:array<string,mixed>}>,
     *     pending:list<array{board:Board,post:array<string,mixed>}>,
     *     pending_count:int,
     *     open_report_count:int,
     *     issues:array<string,string>
     * } */
    private function moderatorFeed(): array
    {
        $reports = [];
        $activity = [];
        $pending = [];
        $pendingCount = 0;
        $issues = $this->registry->issues();
        foreach ($this->registry->all() as $board) {
            try {
                $store = new BoardStore($this->config, $board);
                foreach ($store->openReports() as $report) {
                    $post = $store->post((int) $report['post_id']);
                    if ($post !== null) {
                        $reports[] = ['board' => $board, 'report' => $report, 'post' => $post];
                    }
                }
                foreach ($store->latestActivity(30) as $post) {
                    $activity[] = ['board' => $board, 'post' => $post];
                }
                $pendingCount += $store->pendingCount();
                foreach ($store->pendingPosts(100) as $post) {
                    $pending[] = ['board' => $board, 'post' => $post];
                }
            } catch (\Throwable $error) {
                $issues[$board->slug] = $error->getMessage();
            }
        }
        usort($reports, static fn (array $a, array $b): int => (int) $b['report']['created_at'] <=> (int) $a['report']['created_at']);
        usort($activity, static fn (array $a, array $b): int => (int) $b['post']['updated_at'] <=> (int) $a['post']['updated_at']);
        usort($pending, static fn (array $a, array $b): int => [(int) $a['post']['created_at'], (int) $a['post']['id']]
            <=> [(int) $b['post']['created_at'], (int) $b['post']['id']]);

        return [
            'reports' => array_slice($reports, 0, 100),
            'activity' => array_slice($activity, 0, 100),
            'pending' => array_slice($pending, 0, 100),
            'pending_count' => $pendingCount,
            'open_report_count' => count($reports),
            'issues' => $issues,
        ];
    }

    /** @return array{
     *     boards:list<array{board:Board,stats:array{posts:int,threads:int,images:int,pending:int,open_reports:int}}>,
     *     issues:array<string,string>,
     *     open_report_count:int,
     *     pending_count:int
     * } */
    private function moderatorBoardsFeed(): array
    {
        $boards = [];
        $issues = $this->registry->issues();
        $openReportCount = 0;
        $pendingCount = 0;
        foreach ($this->registry->all() as $board) {
            try {
                $stats = (new BoardStore($this->config, $board))->moderationStats();
                $boards[] = ['board' => $board, 'stats' => $stats];
                $openReportCount += $stats['open_reports'];
                $pendingCount += $stats['pending'];
            } catch (\Throwable $error) {
                $issues[$board->slug] = $error->getMessage();
            }
        }

        return [
            'boards' => $boards,
            'issues' => $issues,
            'open_report_count' => $openReportCount,
            'pending_count' => $pendingCount,
        ];
    }
    private function moderatorReturnTo(mixed $value, string $fallback = '/mod'): string
    {
        if (!is_string($value) || !str_starts_with($value, '/') || str_starts_with($value, '//')
            || str_contains($value, '\\') || str_contains($value, "\r") || str_contains($value, "\n")) {
            return $fallback;
        }

        return $value;
    }
    private function media(string $slug, string $type, string $filename): never
    {
        $board = $this->board($slug);
        $control = new ControlStore($this->config);
        $moderator = (new ModeratorAuth($this->config, $control, $this->security))->user() !== null;
        $store = new BoardStore($this->config, $board);
        if (!$store->imageIsAccessible($type, $filename, $moderator)) {
            throw new HttpException(404, 'Image not found.');
        }
        $path = $board->uploadsPath() . '/' . $type . '/' . $filename;
        if (!is_file($path)) {
            throw new HttpException(404, 'Image not found.');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($path);
        header('Content-Type: ' . (is_string($mime) ? $mime : 'application/octet-stream'));
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: ' . ($moderator ? 'private, no-store' : 'public, max-age=31536000, immutable'));
        readfile($path);
        exit;
    }
    private function board(string $slug): Board
    {
        return $this->registry->get($slug) ?? throw new HttpException(404, 'Board not found.');
    }

    /** @param array<string,mixed> $source */
    private function inputString(array $source, string $key, int $maximum): string
    {
        $value = $source[$key] ?? null;
        if (!is_string($value)) {
            throw new HttpException(400, 'Missing field: ' . $key . '.');
        }
        $value = trim($value);
        if ($value === '' || mb_strlen($value) > $maximum) {
            throw new HttpException(400, 'Invalid field: ' . $key . '.');
        }

        return $value;
    }

    private function nullableString(mixed $value): ?string
    {
        return is_string($value) ? $value : null;
    }

    /** @param array<string,mixed> $source */
    private function requiredInteger(array $source, string $key): int
    {
        return $this->optionalInteger($source, $key) ?? throw new HttpException(400, 'Missing field: ' . $key . '.');
    }

    /** @param array<string,mixed> $source */
    private function optionalInteger(array $source, string $key): ?int
    {
        if (!isset($source[$key]) || $source[$key] === '') {
            return null;
        }
        $value = filter_var($source[$key], FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        if (!is_int($value)) {
            throw new HttpException(400, 'Invalid field: ' . $key . '.');
        }

        return $value;
    }
}
