<?php

declare(strict_types=1);

namespace BoardHub\Support;

final class Html
{
    public static function escape(mixed $value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
    }

    public static function body(string $value, string $boardSlug, int $threadId): string
    {
        $segments = preg_split('/(\[code\][\s\S]*?\[\/code\])/i', $value, -1, PREG_SPLIT_DELIM_CAPTURE);
        if (!is_array($segments)) {
            return self::escape($value);
        }

        $result = '';
        foreach ($segments as $segment) {
            if (preg_match('/\A\[code\]([\s\S]*?)\[\/code\]\z/i', $segment, $code) === 1) {
                $result .= '<code class="post__code">' . self::escape($code[1]) . '</code>';
                continue;
            }
            $result .= self::inlineMarkup($segment, $boardSlug, $threadId);
        }

        return $result;
    }

    private static function inlineMarkup(string $value, string $boardSlug, int $threadId): string
    {
        $formatted = self::escape($value);
        $replacements = [
            ['/(?:&apos;){3}([^\r\n]+?)(?:&apos;){3}/', '<strong>$1</strong>'],
            ['/(?:&apos;){2}([^\r\n]+?)(?:&apos;){2}/', '<em>$1</em>'],
            ['/\*\*([^\r\n*]+)\*\*/', '<span class="spoiler" tabindex="0">$1</span>'],
            ['/__([^\r\n_]+)__/', '<u>$1</u>'],
            ['/~~([^\r\n~]+)~~/', '<s>$1</s>'],
            ['/^==([^=\r\n]+)==[ \t]*$/m', '<strong class="markup-heading">$1</strong>'],
        ];
        foreach ($replacements as [$pattern, $replacement]) {
            $next = preg_replace($pattern, $replacement, $formatted);
            if (is_string($next)) {
                $formatted = $next;
            }
        }

        $linked = preg_replace_callback(
            '/&gt;&gt;(\d{1,18})/',
            static function (array $matches) use ($boardSlug, $threadId): string {
                $id = (int) $matches[1];
                return '<a class="quote-link" href="/' . rawurlencode($boardSlug) . '/thread/' . $threadId
                    . '#p' . $id . '">&gt;&gt;' . $id . ($id === $threadId ? ' (OP)' : '') . '</a>';
            },
            $formatted
        );

        return $linked ?? $formatted;
    }

    public static function date(int $timestamp): string
    {
        return gmdate('m/d/y(D) H:i:s', $timestamp) . ' UTC';
    }
}
