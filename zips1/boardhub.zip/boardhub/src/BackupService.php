<?php

declare(strict_types=1);

namespace BoardHub;

use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RuntimeException;
use SQLite3;

final class BackupService
{
    public function __construct(private readonly Config $config)
    {
    }

    public function create(string $destination): string
    {
        if (file_exists($destination)) {
            throw new RuntimeException('Backup destination already exists.');
        }
        Config::ensureDirectory($destination);
        $lock = SiteLock::exclusive($this->config);
        try {
            $registry = new BoardRegistry($this->config);
            if ($registry->issues() !== []) {
                throw new RuntimeException('Fix isolated board configuration issues before backing up.');
            }
            new ControlStore($this->config);
            $failures = (new Publisher($this->config, $registry, new Renderer($this->config->javascriptFeatures)))->publishAll(true);
            if ($failures !== []) {
                throw new RuntimeException('Unable to publish every board before creating its portable backup.');
            }
            Config::ensureDirectory($destination . '/boards');
            $this->snapshotSqlite($this->config->controlDatabasePath, $destination . '/control.sqlite3');
            foreach ($registry->all() as $board) {
                $target = $destination . '/boards/' . $board->slug;
                Config::ensureDirectory($target . '/.board');
                foreach (['board.json', '.board-id', '.htaccess'] as $file) {
                    if (!copy($board->privatePath() . '/' . $file, $target . '/.board/' . $file)) {
                        throw new RuntimeException('Unable to back up ' . $board->slug . '/.board/' . $file . '.');
                    }
                }
                new BoardStore($this->config, $board);
                $this->snapshotSqlite($board->databasePath(), $target . '/.board/board.sqlite3');
                if (is_dir($board->uploadsPath())) {
                    $this->copyTree($board->uploadsPath(), $target . '/uploads');
                }
                if (!copy($board->path . '/index.html', $target . '/index.html')) {
                    throw new RuntimeException('Unable to back up ' . $board->slug . '/index.html.');
                }
                if (is_dir($board->path . '/threads')) {
                    $this->copyTree($board->path . '/threads', $target . '/threads');
                }
            }
            $manifest = [
                'format' => 2,
                'created_at_utc' => gmdate('c'),
                'php_version' => PHP_VERSION,
                'files' => $this->hashes($destination),
            ];
            $json = json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
            if (file_put_contents($destination . '/manifest.json', $json . PHP_EOL, LOCK_EX) === false) {
                throw new RuntimeException('Unable to write the backup manifest.');
            }
        } finally {
            $lock->release();
        }

        return $destination;
    }

    public function restore(string $source): void
    {
        $manifestPath = $source . '/manifest.json';
        $json = file_get_contents($manifestPath);
        $manifest = is_string($json) ? json_decode($json, true, 16, JSON_THROW_ON_ERROR) : null;
        if (!is_array($manifest) || ($manifest['format'] ?? null) !== 2 || !is_array($manifest['files'] ?? null)) {
            throw new RuntimeException('Invalid backup manifest.');
        }
        $expectedFiles = $manifest['files'];
        ksort($expectedFiles);
        if ($expectedFiles !== $this->hashes($source)) {
            throw new RuntimeException('Backup integrity check failed: files are missing, changed, or unexpected.');
        }
        $this->verifySqlite($source . '/control.sqlite3');
        foreach (glob($source . '/boards/*/.board/board.sqlite3') ?: [] as $database) {
            $this->verifySqlite($database);
        }
        if (is_file($this->config->controlDatabasePath)) {
            throw new RuntimeException('Restore requires a clean install with no control database.');
        }
        $boardSourceRoot = $source . '/boards';
        if (!is_dir($boardSourceRoot)) {
            throw new RuntimeException('Backup contains no portable boards directory.');
        }
        $slugs = [];
        foreach (scandir($boardSourceRoot) ?: [] as $slug) {
            if ($slug === '.' || $slug === '..') {
                continue;
            }
            if (!preg_match('/\A[a-z0-9][a-z0-9-]{0,39}\z/', $slug) || !is_dir($boardSourceRoot . '/' . $slug)) {
                throw new RuntimeException('Invalid board directory in backup.');
            }
            $target = $this->config->webRoot . '/' . $slug;
            if (file_exists($target) || is_link($target)) {
                throw new RuntimeException('Restore requires no existing public board directories.');
            }
            $slugs[] = $slug;
        }

        $lock = SiteLock::exclusive($this->config);
        try {
            if (!copy($source . '/control.sqlite3', $this->config->controlDatabasePath)) {
                throw new RuntimeException('Unable to restore the global control database.');
            }
            new ControlStore($this->config, false);
            foreach ($slugs as $slug) {
                $this->copyTree($boardSourceRoot . '/' . $slug, $this->config->webRoot . '/' . $slug);
            }
            $registry = new BoardRegistry($this->config);
            $failures = (new Publisher($this->config, $registry, new Renderer($this->config->javascriptFeatures)))->publishAll(true);
            if ($registry->issues() !== [] || $failures !== []) {
                throw new RuntimeException('Data restored, but one or more static pages require repair. Run tools/rebuild.php.');
            }
        } finally {
            $lock->release();
        }
    }

    private function snapshotSqlite(string $source, string $destination): void
    {
        $sourceDb = new SQLite3($source, SQLITE3_OPEN_READONLY);
        $destinationDb = new SQLite3($destination, SQLITE3_OPEN_READWRITE | SQLITE3_OPEN_CREATE);
        try {
            if (!$sourceDb->backup($destinationDb)) {
                throw new RuntimeException('SQLite online backup failed.');
            }
            $result = $destinationDb->querySingle('PRAGMA integrity_check');
            if ($result !== 'ok') {
                throw new RuntimeException('SQLite backup integrity check failed: ' . (string) $result);
            }
        } finally {
            $destinationDb->close();
            $sourceDb->close();
        }
    }

    private function copyTree(string $source, string $destination): void
    {
        Config::ensureDirectory($destination);
        foreach (new \DirectoryIterator($source) as $entry) {
            if ($entry->isDot()) {
                continue;
            }
            if ($entry->isLink()) {
                throw new RuntimeException('Symbolic links are not allowed in portable backup data.');
            }
            $target = $destination . '/' . $entry->getFilename();
            if ($entry->isDir()) {
                $this->copyTree($entry->getPathname(), $target);
            } elseif ($entry->isFile() && !copy($entry->getPathname(), $target)) {
                throw new RuntimeException('Unable to copy: ' . $entry->getPathname());
            }
        }
    }

    /** @return array<string,string> */
    private function hashes(string $directory): array
    {
        $hashes = [];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($directory, RecursiveDirectoryIterator::SKIP_DOTS)
        );
        foreach ($iterator as $file) {
            if ($file->isLink()) {
                throw new RuntimeException('Symbolic links are not allowed in backup data.');
            }
            if (!$file->isFile() || $file->getFilename() === 'manifest.json') {
                continue;
            }
            $relative = str_replace('\\', '/', substr($file->getPathname(), strlen($directory) + 1));
            $hashes[$relative] = hash_file('sha256', $file->getPathname()) ?: throw new RuntimeException('Unable to hash backup file.');
        }
        ksort($hashes);

        return $hashes;
    }

    private function verifySqlite(string $path): void
    {
        if (!is_file($path)) {
            throw new RuntimeException('Expected SQLite database is missing: ' . $path);
        }

        // A database whose persistent journal mode is WAL may create -wal/-shm
        // sidecars even when SQLite opens it read-only. Verify an isolated copy
        // so a restore never mutates its source backup after manifest validation.
        $temporary = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR)
            . DIRECTORY_SEPARATOR . 'boardhub-sqlite-verify-' . bin2hex(random_bytes(8)) . '.sqlite3';
        if (!copy($path, $temporary)) {
            throw new RuntimeException('Unable to create a temporary SQLite integrity-check copy.');
        }

        try {
            $database = new SQLite3($temporary, SQLITE3_OPEN_READONLY);
            try {
                $result = $database->querySingle('PRAGMA integrity_check');
                if ($result !== 'ok') {
                    throw new RuntimeException('SQLite integrity check failed: ' . (string) $result);
                }
            } finally {
                $database->close();
            }
        } finally {
            foreach ([$temporary, $temporary . '-wal', $temporary . '-shm'] as $temporaryFile) {
                if (is_file($temporaryFile)) {
                    @unlink($temporaryFile);
                }
            }
        }
    }
}
