<?php

declare(strict_types=1);

namespace BoardHub;

use BoardHub\Support\Html;

final class Renderer
{
    /** @var list<string> */
    private array $javascriptFeatures;

    /** @param list<string> $javascriptFeatures */
    public function __construct(array $javascriptFeatures = Config::DEFAULT_JAVASCRIPT_FEATURES)
    {
        $unknown = array_values(array_diff($javascriptFeatures, Config::DEFAULT_JAVASCRIPT_FEATURES));
        if ($unknown !== []) {
            throw new \InvalidArgumentException('Unknown JavaScript feature(s): ' . implode(', ', $unknown));
        }

        $lookup = array_fill_keys($javascriptFeatures, true);
        $this->javascriptFeatures = array_values(array_filter(
            Config::DEFAULT_JAVASCRIPT_FEATURES,
            static fn (string $feature): bool => isset($lookup[$feature]),
        ));
    }

    /** @param list<Board> $boards @param array<string,string> $issues */
    public function home(array $boards, array $issues): string
    {
        $cards = '';
        foreach ($boards as $board) {
            $cards .= '<a class="board-card" data-board-card="' . Html::escape($board->slug) . '" href="/'
                . rawurlencode($board->slug) . '/"><span class="board-card__address">/'
                . Html::escape($board->slug) . '/</span><h2>' . Html::escape($board->title) . '</h2><p>'
                . Html::escape($board->description) . '</p></a>';
        }
        if ($cards === '') {
            $cards = '<div class="empty-state"><h2>No boards yet</h2><p>A moderator can create the first board from '
                . '<a href="/mod/boards">Boards</a>.</p></div>';
        }
        $notice = $issues === [] ? '' : '<div class="flash-stack"><p class="flash">' . count($issues)
            . ' board issue(s) are isolated; healthy boards remain online.</p></div>';

        return $this->layout('BoardHub', '<header class="board-heading board-heading--home"><h1>BoardHub</h1>'
            . '<div class="board-subtitle">Independent chess discussion</div></header>' . $notice
            . '<section class="admin-section" aria-labelledby="board-directory-heading"><h2 id="board-directory-heading">Boards</h2>'
            . '<div class="board-grid">' . $cards . '</div></section>', $boards);
    }

    private function postingModeNotice(Board $board): string
    {
        return match ($board->postingMode) {
            'approval' => '<div class="board-subtitle">Submissions appear after moderator approval.</div>',
            'password' => '<div class="board-subtitle">This club board requires its posting password.</div>',
            'closed' => '<span class="post__status">Posting paused</span>',
            default => '',
        };
    }
    /** @param list<array{op:array<string,mixed>,replies:list<array<string,mixed>>,reply_count:int}> $threads @param list<Board> $boards */
    public function board(Board $board, array $threads, array $boards): string
    {
        $newThread = $board->postingEnabled
            ? '<section class="new-post" aria-label="Start a new thread"><form method="get" action="/compose">'
                . '<input type="hidden" name="board" value="' . Html::escape($board->slug)
                . '"><button class="new-post__toggle" type="submit">New</button></form></section>'
            : '';
        $content = '<header class="board-heading"><h1>/' . Html::escape($board->slug) . '/ - '
            . Html::escape($board->title) . '</h1><div class="board-subtitle">' . Html::escape($board->description) . '</div>'
            . $this->postingModeNotice($board)
            . '</header><nav class="board-tools" aria-label="Board tools" data-board-tools data-board="'
            . Html::escape($board->slug) . '"><span>[ <a href="/' . rawurlencode($board->slug)
            . '/">Refresh</a> / <a href="/' . rawurlencode($board->slug)
            . '/catalog/">Catalog</a> / <a href="#bottom">Bottom</a> ]</span>' . $this->imageControls() . '</nav>'
            . $newThread . '<hr class="board-rule">';
        if ($threads === []) {
            $content .= '<div class="empty-state"><h2>No threads yet</h2><p>Start the first discussion on this board.</p></div>';
        } else {
            $content .= '<div class="thread-list">';
        }
        foreach ($threads as $thread) {
            $op = $thread['op'];
            $threadId = (int) $op['thread_id'];
            $content .= '<section class="thread-preview" id="thread-' . $threadId . '">'
                . $this->post($board, $op, $threadId, (int) $thread['reply_count'], 1_800);
            $omitted = max(0, (int) $thread['reply_count'] - count($thread['replies']));
            if ($omitted > 0) {
                $content .= '<p class="omitted">' . $omitted . ' repl' . ($omitted === 1 ? 'y' : 'ies')
                    . ' omitted. Open the thread to view all.</p>';
            }
            if ($thread['replies'] !== []) {
                $content .= '<div class="thread-preview__replies" aria-label="Latest replies">';
                foreach ($thread['replies'] as $reply) {
                    $content .= $this->post($board, $reply, $threadId, null, 900);
                }
                $content .= '</div>';
            }
            $content .= '</section>';
        }
        if ($threads !== []) {
            $content .= '</div>';
        }
        $content .= '<div id="bottom" class="thread-return">[ <a href="#top">Top</a> / <a href="/">home</a> ]</div>';

        return $this->layout('/' . $board->slug . '/ - ' . $board->title, $content, $boards);
    }

    /** @param list<array<string,mixed>> $threads @param list<Board> $boards */
    public function catalog(Board $board, array $threads, array $boards): string
    {
        $controls = '';
        if ($this->javascriptFeatureEnabled('catalog-tools')) {
            $controls = '<form class="catalog-tools" data-catalog-tools hidden>'
                . '<label>Search <input type="search" data-catalog-search maxlength="120" autocomplete="off"></label>'
                . '<label>Sort <select data-catalog-sort><option value="bump">Bump order</option>'
                . '<option value="newest">Newest thread</option><option value="replies">Most replies</option>'
                . '<option value="images">Most images</option></select></label>'
                . '<button type="button" class="text-button" data-catalog-clear>Clear</button>'
                . '<span class="catalog-tools__status" data-catalog-status aria-live="polite"></span></form>';
        }

        $cards = '';
        foreach ($threads as $thread) {
            $threadId = (int) $thread['id'];
            $body = $this->previewBody((string) $thread['body'], 300)['body'];
            $thumbnail = '';
            if (is_string($thread['thumbnail_stored_name'])) {
                $thumbnail = '<img class="catalog-card__image" src="/' . rawurlencode($board->slug)
                    . '/uploads/thumbs/' . rawurlencode($thread['thumbnail_stored_name'])
                    . '" alt="" loading="lazy">';
            }
            $cards .= '<article class="catalog-card" data-catalog-card data-thread="' . $threadId
                . '" data-created="' . (int) $thread['created_at'] . '" data-bumped="' . (int) $thread['last_activity_at']
                . '" data-replies="' . (int) $thread['reply_count'] . '" data-images="' . (int) $thread['image_count']
                . '" data-sticky="' . (int) $thread['sticky'] . '">'
                . '<a class="catalog-card__link" href="/' . rawurlencode($board->slug) . '/thread/' . $threadId . '">'
                . $thumbnail . '<strong>' . Html::escape($thread['subject']) . '</strong></a><p>'
                . Html::escape($body) . '</p><footer>' . (int) $thread['reply_count'] . ' repl'
                . ((int) $thread['reply_count'] === 1 ? 'y' : 'ies') . ' · ' . (int) $thread['image_count']
                . ' image' . ((int) $thread['image_count'] === 1 ? '' : 's')
                . ((int) $thread['sticky'] === 1 ? ' · pinned' : '')
                . ((int) $thread['locked'] === 1 ? ' · locked' : '') . '</footer></article>';
        }
        if ($cards === '') {
            $cards = '<div class="empty-state"><h2>No threads yet</h2><p>The catalog is empty.</p></div>';
        }

        $content = '<header class="board-heading"><h1>/' . Html::escape($board->slug) . '/ - Catalog</h1>'
            . '<div class="board-subtitle">' . Html::escape($board->title) . '</div></header>'
            . '<nav class="board-tools" aria-label="Catalog tools"><span>[ <a href="/' . rawurlencode($board->slug)
            . '/">Board index</a> / <a href="#bottom">Bottom</a> ]</span></nav>' . $controls
            . '<div class="catalog-grid" data-catalog-grid>' . $cards . '</div>'
            . '<div id="bottom" class="thread-return">[ <a href="#top">Top</a> / <a href="/'
            . rawurlencode($board->slug) . '/">Return</a> ]</div>';

        return $this->layout('Catalog - /' . $board->slug . '/', $content, $boards);
    }

    /** @param list<array<string,mixed>> $posts @param list<Board> $boards */
    public function thread(Board $board, array $posts, array $boards): string
    {
        if ($posts === []) {
            return $this->layout('Thread not found', '<div class="error-page"><h1>Thread not found</h1></div>', $boards);
        }
        $threadId = (int) $posts[0]['thread_id'];
        $locked = (int) $posts[0]['locked'] === 1;
        $postCount = count($posts);
        $imageCount = count(array_filter(
            $posts,
            static fn (array $post): bool => is_string($post['image_stored_name']),
        ));
        $replyMode = $locked
            ? '<div class="reply-mode reply-mode--locked">This thread is locked</div>'
            : (!$board->postingEnabled
                ? '<div class="reply-mode reply-mode--locked">Posting is paused on this board</div>'
                : '<div class="reply-mode"><a href="/compose?board=' . rawurlencode($board->slug)
                    . '&amp;thread=' . $threadId . '">Reply</a></div>');
        $content = '<header class="board-heading"><h1>/' . Html::escape($board->slug) . '/ - '
            . Html::escape($board->title) . '</h1><div class="board-subtitle">' . Html::escape($board->description)
            . '</div>' . $this->postingModeNotice($board) . '</header><nav class="board-tools" aria-label="Thread tools"'
            . ' data-board-tools data-board="' . Html::escape($board->slug) . '" data-thread="' . $threadId . '"><span>[ <a href="/'
            . rawurlencode($board->slug) . '/">Board index</a> / <a href="/' . rawurlencode($board->slug)
            . '/catalog/">Catalog</a> / <a href="#bottom">Bottom</a> ]</span>'
            . '<span class="thread-stats">' . $postCount . ' post' . ($postCount === 1 ? '' : 's') . ' · '
            . $imageCount . ' image' . ($imageCount === 1 ? '' : 's') . '</span>'
            . $this->imageControls() . '</nav>' . $replyMode
            . '<hr class="board-rule"><div class="thread" id="thread-' . $threadId . '">';
        foreach ($posts as $post) {
            $content .= $this->post($board, $post, $threadId);
        }
        $content .= '</div><div id="bottom" class="thread-return">[ <a href="/' . rawurlencode($board->slug)
            . '/">Return</a> / <a href="/">home</a> ]</div>';

        return $this->layout('Thread #' . $threadId . ' - /' . $board->slug . '/', $content, $boards);
    }

    /** @param list<array{board:Board,post:array<string,mixed>}> $activity @param list<Board> $boards */
    public function all(array $activity, array $boards): string
    {
        $content = '<header class="board-heading"><h1>Latest activity</h1>'
            . '<div class="board-subtitle">New and recently edited posts from every healthy board.</div></header>';
        if ($activity === []) {
            $content .= '<div class="empty-state"><h2>No activity yet</h2><p>Nothing has been posted yet.</p></div>';
        }
        foreach ($activity as $item) {
            $board = $item['board'];
            $post = $item['post'];
            $threadId = (int) $post['thread_id'];
            $previewCharacters = (int) $post['id'] === $threadId ? 1_800 : 900;
            $content .= '<section class="thread-preview" id="activity-' . (int) $post['id']
                . '"><p class="unimportant"><a href="/' . rawurlencode($board->slug)
                . '/">/' . Html::escape($board->slug) . '/ - ' . Html::escape($board->title) . '</a></p>'
                . $this->post($board, $post, $threadId, null, $previewCharacters) . '</section>';
        }

        return $this->layout('Latest activity', $content, $boards);
    }

    private function post(
        Board $board,
        array $post,
        int $threadId,
        ?int $replyCount = null,
        ?int $previewCharacters = null,
    ): string {
        $id = (int) $post['id'];
        $isOp = $id === $threadId;
        $type = $isOp ? 'post--op' : 'post--reply';
        $threadUrl = '/' . rawurlencode($board->slug) . '/thread/' . $threadId;
        $subject = trim((string) $post['subject']) === ''
            ? ''
            : '<strong class="post__subject">' . Html::escape($post['subject']) . '</strong> ';

        $image = '';
        if (is_string($post['thumbnail_stored_name']) && is_string($post['image_stored_name'])) {
            $base = '/' . rawurlencode($board->slug) . '/uploads';
            $original = $base . '/originals/' . rawurlencode($post['image_stored_name']);
            $thumbnail = $base . '/thumbs/' . rawurlencode($post['thumbnail_stored_name']);
            $originalName = is_string($post['image_original_name']) && trim($post['image_original_name']) !== ''
                ? $post['image_original_name']
                : 'attachment';
            $metadata = [];
            if ((int) $post['image_width'] > 0 && (int) $post['image_height'] > 0) {
                $metadata[] = (int) $post['image_width'] . '×' . (int) $post['image_height'];
            }
            if ((int) $post['image_size'] > 0) {
                $metadata[] = $this->formatBytes((int) $post['image_size']);
            }
            $image = '<figure class="attachment"><figcaption><a href="' . $original . '" download="'
                . Html::escape($originalName) . '">' . Html::escape($originalName) . '</a>'
                . ($metadata === [] ? '' : ' <span>(' . Html::escape(implode(', ', $metadata)) . ')</span>')
                . '</figcaption><a class="attachment__toggle" href="' . $original
                . '" data-image-toggle aria-expanded="false"><img src="' . $thumbnail . '" alt="'
                . ($isOp ? 'Post attachment' : 'Reply attachment') . '" loading="lazy"></a>'
                . '<a class="attachment__original" href="' . $original
                . '" target="_blank" rel="noopener">open original</a></figure>';
        }

        $flags = '';
        if ((int) $post['sticky'] === 1) {
            $flags .= ' <span class="post__status-icon post__status-icon--pinned" title="Pinned thread">'
                . '<svg width="1em" height="1em" viewBox="0 0 16 16" aria-hidden="true">'
                . '<path d="M5 1.5h6l-1.35 4.1 2.35 2V9H8.75v5.25L8 15l-.75-.75V9H4V7.6l2.35-2L5 1.5Z"/>'
                . '</svg><span class="visually-hidden">Pinned thread</span></span>';
        }
        if ((int) $post['locked'] === 1) {
            $flags .= ' <span class="post__status-icon post__status-icon--locked" title="Locked thread">'
                . '<svg width="1em" height="1em" viewBox="0 0 16 16" aria-hidden="true">'
                . '<path d="M4 7V5a4 4 0 0 1 8 0v2h1v7H3V7h1Zm2 0h4V5a2 2 0 1 0-4 0v2Zm2 2a1.25 1.25 0 0 0-.65 2.32V13h1.3v-1.68A1.25 1.25 0 0 0 8 9Z"/>'
                . '</svg><span class="visually-hidden">Locked thread</span></span>';
        }

        $threadSummary = '';
        if ($isOp && $replyCount !== null) {
            if ($replyCount > 0) {
                $threadSummary .= ' <span class="post__reply-count">' . $replyCount . ' '
                    . ($replyCount === 1 ? 'reply' : 'replies') . '</span>';
            }
            $threadSummary .= ' <a class="post__reply-link" href="' . $threadUrl . '">['
                . ((int) $post['locked'] === 1 ? 'View' : 'Reply') . ']</a>';
        }

        $menu = '<details class="post-menu"><summary aria-label="Post actions">▶</summary>'
            . '<div class="post-menu__panel"><div class="post__actions"><a href="/report?board='
            . rawurlencode($board->slug) . '&amp;post=' . $id . '">Report</a></div></div></details>';

        $body = (string) $post['body'];
        $truncated = false;
        if ($previewCharacters !== null) {
            $preview = $this->previewBody($body, $previewCharacters);
            $body = $preview['body'];
            $truncated = $preview['truncated'];
        }
        $continue = $truncated
            ? '<p class="post__continue"><a href="' . $threadUrl . '">Reply to view the full post</a></p>'
            : '';

        $postCountAttribute = $isOp && $replyCount !== null
            ? ' data-post-count="' . ($replyCount + 1) . '"'
            : '';

        return '<article class="post ' . $type . '" id="p' . $id . '" data-board="'
            . Html::escape($board->slug) . '" data-thread="' . $threadId . '" data-post="' . $id
            . '" data-is-op="' . ($isOp ? 'true' : 'false') . '" data-post-name="'
            . Html::escape($post['name']) . '"' . $postCountAttribute . '>' . $image
            . '<header class="post__header">' . $subject . '<strong class="post__name">'
            . Html::escape($post['name']) . '</strong>' . ($isOp
                ? ' <span class="post__op" title="Opening post">OP</span>' : '') . ' <time datetime="'
            . gmdate('Y-m-d\TH:i:s\Z', (int) $post['created_at']) . '" title="'
            . Html::date((int) $post['created_at']) . '">' . gmdate('m/d/y', (int) $post['created_at'])
            . '</time>' . $flags . $threadSummary . $menu . '</header>'
            . '<div class="post__body">' . Html::body($body, $board->slug, $threadId) . '</div>'
            . $continue . '</article>';
    }

    /** @return array{body:string,truncated:bool} */
    private function previewBody(string $body, int $maximum): array
    {
        if (mb_strlen($body) <= $maximum) {
            return ['body' => $body, 'truncated' => false];
        }

        return ['body' => rtrim(mb_substr($body, 0, $maximum)) . '…', 'truncated' => true];
    }

    /** @param list<array{board:Board,post:array<string,mixed>}> $activity
     * @param list<Board> $boards @param array<string,string> $issues */
    public function moderatorDashboard(
        array $activity,
        array $boards,
        array $user,
        array $issues,
        int $openReportCount,
        int $pendingCount,
    ): string {
        $csrf = Html::escape($user['csrf_token']);
        $content = $this->moderatorHeader(
            'Moderation',
            'Latest posts · sticky / lock apply to threads (OP) only'
        ) . $this->moderatorNav('latest', $openReportCount, $pendingCount, $csrf)
            . $this->moderatorIssues($issues) . '<hr>';
        if ($pendingCount > 0) {
            $content .= '<p class="mod-notice"><strong>' . $pendingCount . '</strong> submission'
                . ($pendingCount === 1 ? '' : 's') . ' awaiting approval · <a href="/mod/approval">review the queue</a></p>';
        }
        if ($openReportCount > 0) {
            $content .= '<p class="mod-notice"><strong>' . $openReportCount . '</strong> open report'
                . ($openReportCount === 1 ? '' : 's') . ' · <a href="/mod/reports">review the queue</a></p>';
        }
        if ($activity === []) {
            $content .= '<p class="mod-empty">No posts yet.</p>';
        } else {
            foreach ($activity as $item) {
                $content .= $this->moderatorPost($item['board'], $item['post'], $csrf, '/mod');
            }
        }

        return $this->moderatorLayout('Mod — Latest posts', $content);
    }

    /** @param list<array{board:Board,report:array<string,mixed>,post:array<string,mixed>}> $reports
     * @param list<Board> $boards @param array<string,string> $issues */
    public function moderatorReports(
        array $reports,
        array $boards,
        array $user,
        array $issues,
        int $openReportCount,
        int $pendingCount,
    ): string
    {
        $csrf = Html::escape($user['csrf_token']);
        $content = $this->moderatorHeader('Reports', 'Open reports awaiting a decision')
            . $this->moderatorNav('reports', $openReportCount, $pendingCount, $csrf)
            . $this->moderatorIssues($issues) . '<hr>';
        if ($reports === []) {
            $content .= '<p class="mod-empty">No open reports.</p>';
        } else {
            foreach ($reports as $item) {
                $report = $item['report'];
                $post = $item['post'];
                $board = $item['board'];
                $id = (int) $post['id'];
                $threadId = (int) $post['thread_id'];
                $view = '/' . rawurlencode($board->slug) . '/thread/' . $threadId . '#p' . $id;
                $subject = trim((string) $post['subject']) === ''
                    ? ''
                    : '<div class="mod-meta">Subject: <strong>' . Html::escape($post['subject']) . '</strong></div>';
                $content .= '<div class="mod-row mod-row--report"><div class="mod-meta">Report #'
                    . (int) $report['id'] . ' · post #<a href="' . $view . '">' . $id . '</a> · /'
                    . Html::escape($board->slug) . '/ · '
                    . gmdate('d/m/y H:i', (int) $report['created_at']) . '</div>'
                    . '<div class="mod-body mod-body--reason"><strong>Reason:</strong> '
                    . Html::escape($report['reason']) . '</div>' . $subject
                    . $this->moderatorImage($board, $post)
                    . '<div class="mod-body">' . Html::body((string) $post['body'], $board->slug, $threadId)
                    . '</div>' . $this->moderatorActions(
                        $board,
                        $post,
                        $csrf,
                        '/mod/reports',
                        (int) $report['id']
                    ) . '</div>';
            }
        }

        return $this->moderatorLayout('Mod — Reports', $content);
    }

    /** @param list<array{board:Board,post:array<string,mixed>}> $pending
     * @param list<Board> $boards @param array<string,string> $issues */
    public function moderatorApproval(
        array $pending,
        array $boards,
        array $user,
        array $issues,
        int $openReportCount,
        int $pendingCount,
    ): string {
        $csrf = Html::escape($user['csrf_token']);
        $content = $this->moderatorHeader('Approval queue', 'Posts remain private until approved')
            . $this->moderatorNav('approval', $openReportCount, $pendingCount, $csrf)
            . $this->moderatorIssues($issues) . '<hr>';
        if ($pending === []) {
            $content .= '<p class="mod-empty">No posts are waiting for approval.</p>';
        } else {
            foreach ($pending as $item) {
                $content .= $this->moderatorPendingPost($item['board'], $item['post'], $csrf);
            }
        }

        return $this->moderatorLayout('Mod — Approval queue', $content);
    }
    /** @param list<array{board:Board,stats:array{posts:int,threads:int,images:int,pending:int,open_reports:int}}> $boardRows
     * @param list<Board> $boards @param array<string,string> $issues */
    public function moderatorBoards(
        array $boardRows,
        array $boards,
        array $user,
        array $issues,
        int $openReportCount,
        int $pendingCount,
        ?string $createError = null,
        string $newSlug = '',
        string $newName = '',
        string $newDescription = '',
    ): string {
        $csrf = Html::escape($user['csrf_token']);
        $error = $createError === null
            ? ''
            : '<p class="form-error" role="alert">' . Html::escape($createError) . '</p>';
        $create = '<section class="board-create"><h2>Create board</h2>'
            . '<form method="post" action="/mod/boards"><input type="hidden" name="csrf" value="' . $csrf . '">'
            . '<table><tbody><tr><th><label for="new-board-slug">URL slug</label></th>'
            . '<td><input id="new-board-slug" type="text" name="slug" maxlength="40" required value="'
            . Html::escape($newSlug) . '" placeholder="endgames"></td></tr>'
            . '<tr><th><label for="new-board-name">Name</label></th><td><input id="new-board-name" '
            . 'type="text" name="name" maxlength="80" required value="' . Html::escape($newName)
            . '" placeholder="Endgames"></td></tr>'
            . '<tr><th><label for="new-board-description">Description</label></th>'
            . '<td><input id="new-board-description" type="text" name="description" maxlength="300" value="'
            . Html::escape($newDescription) . '" placeholder="Endgame study and discussion"></td></tr>'
            . '<tr><td></td><td><input type="submit" value="Create board"></td></tr></tbody></table></form>'
            . '<p class="unimportant">New boards start Closed. After creation, review the settings and choose Open, Approval, or Password when the board is ready.</p></section>';
        $content = $this->moderatorHeader('Moderation', 'Create and manage discussion boards')
            . $this->moderatorNav('boards', $openReportCount, $pendingCount, $csrf) . '<hr>'
            . $this->moderatorIssues($issues) . $error . $create
            . '<div class="mod-boards-wrap"><table class="mod-boards"><thead><tr>'
            . '<th>URL</th><th>Name</th><th>Mode</th><th>Threads</th><th>Posts</th>'
            . '<th>Images</th><th>Pending</th><th>Reports</th><th>Description</th><th></th></tr></thead><tbody>';
        foreach ($boardRows as $item) {
            $board = $item['board'];
            $stats = $item['stats'];
            $status = match ($board->postingMode) {
                'open' => '<strong>Open</strong>',
                'approval' => '<strong>Approval</strong>',
                'password' => '<strong>Password</strong>',
                default => '<span class="unimportant">Closed</span>',
            };
            $content .= '<tr><td><a href="/' . rawurlencode($board->slug) . '/">/'
                . Html::escape($board->slug) . '/</a></td><td>' . Html::escape($board->title)
                . '</td><td>' . $status . '</td><td>' . $stats['threads'] . '</td><td>' . $stats['posts']
                . '</td><td>' . $stats['images'] . '</td><td>' . $stats['pending'] . '</td><td>'
                . $stats['open_reports'] . '</td><td class="unimportant mod-boards__description">'
                . Html::escape($board->description) . '</td><td><a href="/mod/boards/edit?board='
                . rawurlencode($board->slug) . '">[Edit]</a></td></tr>';
        }
        if ($boardRows === []) {
            $content .= '<tr><td colspan="10">No healthy boards were found.</td></tr>';
        }
        $content .= '</tbody></table></div><p class="unimportant mod-table-note">'
            . 'Open accepts posts immediately. Approval keeps submissions private until accepted. Password requires the shared board password. Closed remains readable but does not accept posts.</p>';

        return $this->moderatorLayout('Mod — Boards', $content);
    }
    /** @param array{posts:int,threads:int,images:int,pending:int,open_reports:int} $stats @param list<Board> $boards */
    public function moderatorBoardEdit(
        Board $board,
        array $stats,
        array $boards,
        array $user,
        int $openReportCount,
        int $pendingCount,
        bool $passwordSet,
        ?string $error = null,
    ): string {
        $csrf = Html::escape($user['csrf_token']);
        $option = static fn (string $value, string $label): string => '<option value="' . $value . '"'
            . ($board->postingMode === $value ? ' selected' : '') . '>' . $label . '</option>';
        $errorHtml = $error === null ? '' : '<p class="form-error" role="alert">' . Html::escape($error) . '</p>';
        $clearPassword = $passwordSet
            ? '<label><input type="checkbox" name="clear_posting_password" value="1"> Clear the stored posting password</label>'
            : '';
        $passwordState = $passwordSet ? ' A password is currently set.' : ' No password is currently set.';
        $content = $this->moderatorHeader(
            'Edit board',
            'Settings and posting policy for /' . Html::escape($board->slug) . '/ · board directory identity is retained'
        ) . $this->moderatorNav('boards', $openReportCount, $pendingCount, $csrf) . '<hr>'
            . $errorHtml
            . '<p class="mod-board-stats"><strong>' . $stats['threads'] . '</strong> threads · <strong>'
            . $stats['posts'] . '</strong> approved posts · <strong>' . $stats['pending']
            . '</strong> pending · <strong>' . $stats['images'] . '</strong> public images · <strong>'
            . $stats['open_reports'] . '</strong> open reports</p>'
            . '<form class="mod-form" method="post" action="/mod/boards/edit">'
            . '<input type="hidden" name="csrf" value="' . $csrf . '"><input type="hidden" name="board" value="'
            . Html::escape($board->slug) . '"><table class="mod-form-table"><tbody>'
            . '<tr><th><label for="board-title">Name</label></th><td><input id="board-title" type="text" '
            . 'name="title" size="40" maxlength="80" value="' . Html::escape($board->title) . '" required></td></tr>'
            . '<tr><th><label for="board-description">Description</label></th><td><input id="board-description" '
            . 'type="text" name="description" size="60" maxlength="300" value="'
            . Html::escape($board->description) . '"></td></tr>'
            . '<tr><th><label for="threads-per-page">Threads per page</label></th><td><input id="threads-per-page" '
            . 'type="number" name="threads_per_page" min="1" max="50" value="' . $board->threadsPerPage
            . '" required></td></tr>'
            . '<tr><th><label for="posting-mode">Board mode</label></th><td><select id="posting-mode" name="posting_mode">'
            . $option('open', 'Open') . $option('approval', 'All posts require approval')
            . $option('password', 'Password required to post') . $option('closed', 'Closed') . '</select>'
            . '<div class="unimportant">Closed boards remain readable but cannot receive posts. Approval boards keep every submission private until accepted. Password boards require the shared password on every thread and reply.</div></td></tr>'
            . '<tr><th><label for="posting-password">Posting password</label></th><td>'
            . '<input id="posting-password" type="password" name="posting_password" size="30" minlength="8" maxlength="128" autocomplete="new-password">'
            . '<div class="unimportant">Enter a value to set or replace the password. Leave blank to keep it.'
            . $passwordState . '</div>' . $clearPassword . '</td></tr>'
            . '<tr><td></td><td><input type="submit" value="Save board"></td></tr></tbody></table></form>'
            . '<p class="mod-backlinks"><a href="/mod/boards">[Back]</a> '
            . '<a href="/' . rawurlencode($board->slug) . '/">[View board]</a></p>';

        return $this->moderatorLayout('Edit board /' . $board->slug . '/', $content);
    }
    /** @param list<Board> $boards */
    public function moderatorEdit(
        Board $board,
        array $post,
        array $user,
        array $boards,
        string $returnTo,
        int $openReportCount,
        int $pendingCount,
    ): string {
        $csrf = Html::escape($user['csrf_token']);
        $id = (int) $post['id'];
        $threadId = (int) $post['thread_id'];
        $isOp = (int) $post['is_op'] === 1;
        $pending = (int) $post['approved'] !== 1;
        $content = $this->moderatorHeader(
            'Edit post #' . $id,
            '/' . Html::escape($board->slug) . '/ · ' . ($pending ? 'Pending · ' : '')
                . ($isOp ? 'OP thread' : 'reply in thread ' . $threadId)
        ) . $this->moderatorNav('latest', $openReportCount, $pendingCount, $csrf) . '<hr>'
            . '<form class="mod-form moderator-edit-form" method="post" action="/mod/action" enctype="multipart/form-data">'
            . '<input type="hidden" name="csrf" value="' . $csrf . '"><input type="hidden" name="action" value="edit">'
            . '<input type="hidden" name="board" value="' . Html::escape($board->slug)
            . '"><input type="hidden" name="post" value="' . $id . '"><input type="hidden" name="return_to" value="'
            . Html::escape($returnTo) . '"><table class="mod-form-table"><tbody>'
            . '<tr><th><label for="post-name">Name</label></th><td><input id="post-name" type="text" '
            . 'name="name" size="40" maxlength="80" value="' . Html::escape($post['name']) . '" required></td></tr>';
        if ($isOp) {
            $content .= '<tr><th><label for="post-subject">Subject</label></th><td><input id="post-subject" '
                . 'type="text" name="subject" size="50" maxlength="120" value="'
                . Html::escape($post['subject']) . '" required></td></tr>';
        } else {
            $content .= '<input type="hidden" name="subject" value="">';
        }
        $content .= '<tr><th><label for="post-body">Comment</label></th><td><textarea id="post-body" '
            . 'name="body" rows="12" cols="72" maxlength="100000" required>'
            . Html::escape($post['body']) . '</textarea></td></tr></tbody></table>'
            . '<hr><h2 class="mod-section-title">Image</h2><div class="mod-image-editor">';
        if (is_string($post['image_stored_name'])) {
            $content .= $this->moderatorImage($board, $post, true);
        } else {
            $content .= '<p class="unimportant">No image</p>';
        }
        $content .= '</div><table class="mod-form-table"><tbody><tr><th><label for="post-image">Replace</label></th>'
            . '<td><input id="post-image" type="file" name="image" accept="image/jpeg,image/png,image/gif,image/webp"></td></tr>';
        if (is_string($post['image_stored_name'])) {
            $content .= '<tr><th>Remove</th><td><label><input type="checkbox" name="remove_image" value="1"> '
                . 'Remove current image</label></td></tr>';
        }
        $content .= '<tr><td></td><td><span class="unimportant">Choose either a replacement or removal; '
            . 'leave both blank to keep the current image.</span></td></tr>'
            . '<tr><td></td><td><input type="submit" value="Save post"></td></tr></tbody></table></form>'
            . '<p class="mod-backlinks"><a href="' . Html::escape($returnTo) . '">[Back]</a> '
            . ($pending ? '' : '<a href="/' . rawurlencode($board->slug) . '/thread/' . $threadId . '#p' . $id
                . '">[View post]</a>') . '</p>';

        return $this->moderatorLayout('Edit post #' . $id, $content);
    }

    private function moderatorHeader(string $title, string $subtitle): string
    {
        return '<header><h1>' . Html::escape($title) . '</h1><div class="subtitle">'
            . $subtitle . '</div></header>';
    }

    private function moderatorNav(string $active, int $openReportCount, int $pendingCount, string $csrf): string
    {
        $link = static fn (string $key, string $href, string $label): string => $active === $key
            ? '<strong>[' . $label . ']</strong>'
            : '<a href="' . $href . '">[' . $label . ']</a>';
        $returnTo = match ($active) {
            'boards' => '/mod/boards',
            'approval' => '/mod/approval',
            'reports' => '/mod/reports',
            default => '/mod',
        };

        return '<nav class="mod-nav" aria-label="Moderator tools">'
            . $link('latest', '/mod', 'Latest posts') . ' ' . $link('boards', '/mod/boards', 'Boards')
            . ' ' . $link('approval', '/mod/approval', 'Approval') . ' <span class="queue-count">('
            . $pendingCount . ')</span> ' . $link('reports', '/mod/reports', 'Reports')
            . ' <span class="queue-count">(' . $openReportCount . ')</span><form method="post" action="/mod/rebuild">'
            . '<input type="hidden" name="csrf" value="' . $csrf
            . '"><input type="hidden" name="return_to" value="' . $returnTo
            . '"><input type="submit" value="Rebuild pages"></form>'
            . '<form method="post" action="/mod/logout"><input type="hidden" name="csrf" value="' . $csrf
            . '"><input type="submit" value="Logout"></form></nav>';
    }

    /** @param array<string,string> $issues */
    private function moderatorIssues(array $issues): string
    {
        if ($issues === []) {
            return '';
        }
        $html = '<details class="form-error mod-issues"><summary>' . count($issues) . ' isolated board issue'
            . (count($issues) === 1 ? '' : 's') . '</summary><ul>';
        foreach ($issues as $slug => $message) {
            $html .= '<li><code>' . Html::escape($slug) . '</code>: ' . Html::escape($message) . '</li>';
        }

        return $html . '</ul></details>';
    }

    private function moderatorPendingPost(Board $board, array $post, string $csrf): string
    {
        $id = (int) $post['id'];
        $threadId = (int) $post['thread_id'];
        $isOp = (int) $post['is_op'] === 1;
        $subject = trim((string) $post['subject']) === ''
            ? ''
            : '<div class="mod-meta"><strong>' . Html::escape($post['subject']) . '</strong></div>';
        $hidden = '<input type="hidden" name="csrf" value="' . $csrf
            . '"><input type="hidden" name="board" value="' . Html::escape($board->slug)
            . '"><input type="hidden" name="post" value="' . $id
            . '"><input type="hidden" name="return_to" value="/mod/approval">';
        $actions = '<div class="mod-actions"><form method="post" action="/mod/action">' . $hidden
            . '<input type="hidden" name="action" value="approve"><input type="submit" value="Approve"></form>'
            . '<form method="post" action="/mod/action" data-confirm="Reject this pending post?">' . $hidden
            . '<input type="hidden" name="action" value="reject_pending"><input type="submit" value="Reject"></form>'
            . '<a href="/mod/edit?board=' . rawurlencode($board->slug) . '&amp;post=' . $id
            . '&amp;return_to=' . rawurlencode('/mod/approval') . '">[Edit before approval]</a></div>';

        return '<div class="mod-row mod-row--pending" id="pending-p' . $id . '"><div class="mod-meta">'
            . '<span class="badge badge-pending">PENDING</span> #' . $id . ' · /'
            . Html::escape($board->slug) . '/ · ' . gmdate('d/m/y H:i', (int) $post['created_at'])
            . ' · ' . ($isOp ? 'new thread' : 'reply in thread ' . $threadId) . '</div>'
            . '<div class="mod-meta"><strong>' . Html::escape($post['name']) . '</strong></div>' . $subject
            . $this->moderatorImage($board, $post)
            . '<div class="mod-body">' . Html::body((string) $post['body'], $board->slug, $threadId)
            . '</div>' . $actions . '</div>';
    }
    private function moderatorPost(
        Board $board,
        array $post,
        string $csrf,
        string $returnTo,
        ?int $reportId = null,
    ): string {
        $id = (int) $post['id'];
        $threadId = (int) $post['thread_id'];
        $isOp = (int) $post['is_op'] === 1;
        $view = '/' . rawurlencode($board->slug) . '/thread/' . $threadId . '#p' . $id;
        if ($isOp) {
            $identity = '<span class="badge badge-op">OP</span>';
            if ((int) $post['sticky'] === 1) {
                $identity .= '<span class="badge badge-sticky">STICKY</span>';
            }
            if ((int) $post['locked'] === 1) {
                $identity .= '<span class="badge badge-locked">LOCKED</span>';
            }
            $identity .= '<a href="' . $view . '">Thread #' . $id . '</a>';
        } else {
            $identity = 'Reply #' . $id . ' in <a href="' . $view . '">thread ' . $threadId . '</a>';
        }
        $subject = trim((string) $post['subject']) === ''
            ? ''
            : ' · <strong>' . Html::escape($post['subject']) . '</strong>';

        return '<div class="mod-row" id="mod-p' . $id . '"><div class="mod-meta"><span class="unimportant">/'
            . '<a href="/' . rawurlencode($board->slug) . '/">' . Html::escape($board->slug)
            . '</a>/</span> ' . $identity . ' · ' . gmdate('d/m/y H:i:s', (int) $post['created_at'])
            . ' · <strong>' . Html::escape($post['name']) . '</strong>' . $subject . '</div>'
            . $this->moderatorImage($board, $post)
            . '<div class="mod-body">' . Html::body((string) $post['body'], $board->slug, $threadId)
            . '</div>' . $this->moderatorActions($board, $post, $csrf, $returnTo, $reportId) . '</div>';
    }

    private function moderatorImage(Board $board, array $post, bool $large = false): string
    {
        if (!is_string($post['image_stored_name'])) {
            return '';
        }
        $original = '/' . rawurlencode($board->slug) . '/uploads/originals/' . rawurlencode($post['image_stored_name']);
        $thumbnail = is_string($post['thumbnail_stored_name'])
            ? '/' . rawurlencode($board->slug) . '/uploads/thumbs/' . rawurlencode($post['thumbnail_stored_name'])
            : $original;
        $details = [];
        if (is_string($post['image_original_name']) && $post['image_original_name'] !== '') {
            $details[] = Html::escape($post['image_original_name']);
        }
        if (isset($post['image_width'], $post['image_height'])) {
            $details[] = (int) $post['image_width'] . '×' . (int) $post['image_height'];
        }
        if (isset($post['image_size'])) {
            $details[] = $this->formatBytes((int) $post['image_size']);
        }

        return '<div class="mod-image' . ($large ? ' mod-image--large' : '') . '"><a href="'
            . $original . '" target="_blank" rel="noopener"><img src="' . $thumbnail . '" alt="Attachment for post #'
            . (int) $post['id'] . '" loading="lazy"></a><div class="mod-meta">File: <a href="' . $original
            . '" target="_blank" rel="noopener">' . ($details === [] ? 'original' : implode(' · ', $details))
            . '</a></div></div>';
    }

    private function moderatorActions(
        Board $board,
        array $post,
        string $csrf,
        string $returnTo,
        ?int $reportId,
    ): string {
        $id = (int) $post['id'];
        $threadId = (int) $post['thread_id'];
        $isOp = (int) $post['is_op'] === 1;
        $threadSticky = (int) ($post['thread_sticky'] ?? $post['sticky']) === 1;
        $threadLocked = (int) ($post['thread_locked'] ?? $post['locked']) === 1;
        $sharedHidden = '<input type="hidden" name="csrf" value="' . $csrf
            . '"><input type="hidden" name="board" value="' . Html::escape($board->slug) . '">';
        $returnHidden = '<input type="hidden" name="return_to" value="' . Html::escape($returnTo) . '">';
        $postHidden = $sharedHidden . '<input type="hidden" name="post" value="' . $id . '">' . $returnHidden;
        $threadHidden = $sharedHidden . '<input type="hidden" name="post" value="' . $threadId . '">' . $returnHidden;
        $view = '/' . rawurlencode($board->slug) . '/thread/' . $threadId . '#p' . $id;
        $links = '<a href="/mod/edit?board=' . rawurlencode($board->slug) . '&amp;post=' . $id
            . '&amp;return_to=' . rawurlencode($returnTo) . '">[Edit]</a><a href="' . $view . '">[View]</a>';
        $delete = '<form method="post" action="/mod/action" data-confirm="'
            . ($isOp ? 'Delete this thread and all of its replies?' : 'Delete this reply?')
            . '">' . $postHidden . '<input type="hidden" name="action" value="delete"><input type="submit" value="'
            . ($reportId === null ? 'Delete' : 'Accept (delete post)') . '"></form>';
        $actions = '<div class="mod-actions">';
        if ($reportId === null) {
            $actions .= $links . $delete;
        } else {
            $actions .= $delete . '<form method="post" action="/mod/action">' . $postHidden
                . '<input type="hidden" name="action" value="resolve"><input type="hidden" name="report" value="'
                . $reportId . '"><input type="submit" value="Reject report"></form>' . $links;
        }

        $pinLabel = ($threadSticky ? 'Unpin' : 'Pin') . ($isOp ? '' : ' thread');
        $lockLabel = ($threadLocked ? 'Unlock' : 'Lock') . ($isOp ? '' : ' thread');
        $threadTitle = 'Affects thread #' . $threadId;
        $actions .= '<form method="post" action="/mod/action" data-thread-control="sticky">' . $threadHidden
            . '<input type="hidden" name="action" value="sticky"><input type="submit" value="'
            . $pinLabel . '" title="' . $threadTitle . '"></form>'
            . '<form method="post" action="/mod/action" data-thread-control="locked">' . $threadHidden
            . '<input type="hidden" name="action" value="locked"><input type="submit" value="'
            . $lockLabel . '" title="' . $threadTitle . '"></form>';

        return $actions . '</div>';
    }
    private function moderatorLayout(string $title, string $content, bool $authenticated = true): string
    {
        $top = $authenticated
            ? '<div class="boardlist"><span class="sub">[ <a href="/">Board</a> / <a href="/mod">Mod</a> ]</span></div>'
            : '';
        $bottom = $authenticated
            ? '<div class="boardlist bottom"><span class="sub">[ <a href="/">Board</a> / <a href="/mod">Latest posts</a> ]</span></div>'
            : '<p class="mod-backlinks"><a href="/">[Return]</a></p>';

        return '<!doctype html><html lang="en"' . $this->javascriptAttributes() . '><head><meta charset="utf-8">'
            . '<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">'
            . '<title>' . Html::escape($title) . '</title><link rel="stylesheet" href="/static/assets/css/legacy-moderator.css">'
            . '<link rel="stylesheet" href="/static/assets/css/board-overrides.css">'
            . '<link rel="stylesheet" href="/static/assets/css/boardhub-moderation.css">'
            . $this->javascriptTag() . '</head><body class="8chan vichan '
            . ($authenticated ? 'is-moderator' : 'is-not-moderator') . '" data-stylesheet="default">'
            . $top . '<main id="main-content">' . $content . '</main>' . $bottom . '</body></html>';
    }
    private function formatBytes(int $bytes): string
    {
        if ($bytes >= 1_048_576) {
            return number_format($bytes / 1_048_576, 1) . ' MB';
        }
        if ($bytes >= 1024) {
            return number_format($bytes / 1024, 1) . ' KB';
        }

        return $bytes . ' B';
    }
    /** @param list<Board> $boards */
    public function compose(Board $board, ?array $thread, string $csrf, array $boards, ?string $error = null): string
    {
        $threadId = $thread === null ? null : (int) $thread['thread_id'];
        $title = $threadId === null ? 'Start a thread' : 'Reply to thread #' . $threadId;
        $subject = $threadId === null ? '<label>Subject <input type="text" name="subject" maxlength="120" required></label>' : '';
        $errorHtml = $error === null ? '' : '<p class="flash flash--error">' . Html::escape($error) . '</p>';
        $password = $board->postingMode === 'password'
            ? '<label>Board password <input type="password" name="board_password" maxlength="128" autocomplete="off" required></label>'
            : '';
        $policyNote = match ($board->postingMode) {
            'approval' => '<p class="post-form__hint">This submission remains private until a moderator approves it.</p>',
            'password' => '<p class="post-form__hint">This club board requires its posting password.</p>',
            default => '',
        };
        $content = '<section class="auth-card"><p class="eyebrow">/' . Html::escape($board->slug) . '/</p><h1>'
            . Html::escape($title) . '</h1>' . $errorHtml
            . '<form class="stack-form" method="post" action="/post" enctype="multipart/form-data" data-compose-form>'
            . '<input type="hidden" name="csrf" value="'
            . Html::escape($csrf) . '"><input type="hidden" name="board" value="' . Html::escape($board->slug) . '">'
            . ($threadId === null ? '' : '<input type="hidden" name="thread" value="' . $threadId . '">')
            . '<label>Name <input type="text" name="name" maxlength="80" value="Anonymous" required></label>' . $subject
            . '<label>Comment <textarea name="body" maxlength="100000" rows="9" required></textarea></label>'
            . $password . $policyNote
            . '<label>Image <input type="file" name="image" accept="image/jpeg,image/png,image/gif,image/webp"></label>'
            . '<p class="post-form__hint">JPEG, PNG, GIF, or WebP; server-configured size limit.</p>'
            . '<p class="post-form__status" data-draft-status aria-live="polite"></p>'
            . '<button class="button">Post</button></form></section>';

        return $this->layout($title . ' - /' . $board->slug . '/', $content, $boards, false);
    }

    /** @param list<Board> $boards */
    public function report(Board $board, array $post, string $csrf, array $boards): string
    {
        $content = '<section class="auth-card"><p class="eyebrow">/' . Html::escape($board->slug) . '/ post #'
            . (int) $post['id'] . '</p><h1>Report post</h1><form class="stack-form" method="post" action="/report">'
            . '<input type="hidden" name="csrf" value="' . Html::escape($csrf) . '"><input type="hidden" name="board" value="'
            . Html::escape($board->slug) . '"><input type="hidden" name="post" value="' . (int) $post['id'] . '">'
            . '<label>Reason <textarea name="reason" maxlength="500" rows="5" required></textarea></label>'
            . '<button class="button">Send report</button></form></section>';

        return $this->layout('Report post', $content, $boards, false);
    }

    /** @param list<Board> $boards */
    public function moderatorLogin(array $boards, string $csrf, ?string $error = null): string
    {
        $errorHtml = $error === null ? '' : '<p class="form-error">' . Html::escape($error) . '</p>';
        $content = '<header><h1>Mod login</h1></header>' . $errorHtml
            . '<form class="mod-form mod-login" method="post" action="/mod/login">'
            . '<input type="hidden" name="csrf" value="' . Html::escape($csrf)
            . '"><table class="mod-form-table"><tbody><tr><th><label for="mod-username">Username</label></th>'
            . '<td><input id="mod-username" type="text" name="username" autocomplete="username" required autofocus></td></tr>'
            . '<tr><th><label for="mod-password">Password</label></th><td><input id="mod-password" type="password" '
            . 'name="password" autocomplete="current-password" required></td></tr>'
            . '<tr><td></td><td><input type="submit" value="Login"></td></tr></tbody></table></form>';

        return $this->moderatorLayout('Mod login', $content, false);
    }

    /** @param list<Board> $boards */
    public function message(string $title, string $message, array $boards): string
    {
        return $this->layout($title, '<section class="auth-card"><h1>' . Html::escape($title) . '</h1><p>'
            . Html::escape($message) . '</p><p><a href="/">Return home</a></p></section>', $boards, false);
    }

    /** @param list<Board> $boards */
    private function layout(string $title, string $content, array $boards, bool $static = true): string
    {
        $nav = '<span class="board-list__links">[ <a href="/">home</a> / <a href="/all/">all</a>';
        foreach ($boards as $board) {
            $nav .= '<span data-board-entry="' . Html::escape($board->slug) . '"> / <a data-board-link="'
                . Html::escape($board->slug) . '" href="/' . rawurlencode($board->slug) . '/" title="'
                . Html::escape($board->title) . '">' . Html::escape($board->slug) . '</a></span>';
        }
        $preferences = '';
        if ($this->javascriptFeatureEnabled('preferences')) {
            $preferences = '<span data-feature-control="preferences"><label class="style-switcher" for="style-switcher">Theme '
                . '<select id="style-switcher" aria-label="Board theme">' . $this->themeOptions() . '</select></label>'
                . '<span class="reading-controls" role="group" aria-label="Reading controls">'
                . '<button type="button" class="reading-control" id="text-smaller" aria-label="Make site text smaller" title="Smaller text">A−</button>'
                . '<button type="button" class="reading-control" id="text-larger" aria-label="Make site text larger" title="Larger text">A+</button>'
                . '<button type="button" class="reading-control reading-control--weight" id="text-weight" aria-label="Use thicker, darker text" aria-pressed="false" title="Thicker text">A</button>'
                . '</span><span id="reading-status" class="visually-hidden" aria-live="polite"></span></span> ';
        }
        $enhancementControl = $this->javascriptFeatureEnabled('enhancement-settings')
            ? '<button type="button" class="text-button enhancements-open" data-enhancements-open hidden>Enhancements</button> '
            : '';
        $nav .= ' ]</span><span class="board-list__staff">' . $preferences . $enhancementControl
            . '[ <a href="/mod">staff</a> ]</span>';
        $enhancementDialog = $this->enhancementDialog();

        return '<!doctype html><html lang="en" data-style="checkmate" data-text-size="normal" data-text-weight="normal"'
            . $this->javascriptAttributes() . '><head>'
            . '<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            . '<meta name="color-scheme" content="light dark">' . ($static ? '' : '<meta name="robots" content="noindex">')
            . '<title>' . Html::escape($title) . '</title><link rel="stylesheet" href="/static/assets/css/app.css">'
            . '<link id="theme-stylesheet" rel="stylesheet" href="/static/assets/css/themes/checkmate.css" data-theme-base="/static/assets/css/themes">'
            . $this->javascriptTag() . '</head><body>'
            . '<a class="skip-link" href="#main-content">Skip to content</a><nav id="top" class="board-list" aria-label="Boards">'
            . $nav . '</nav><main id="main-content" class="page">' . $content
            . '</main>' . $enhancementDialog
            . '<footer class="footer">- BoardHub · Static public pages, board-local SQLite, UTC timestamps -</footer></body></html>';
    }

    private function javascriptFeatureEnabled(string $feature): bool
    {
        return in_array($feature, $this->javascriptFeatures, true);
    }

    private function javascriptAttributes(): string
    {
        return $this->javascriptFeatures === []
            ? ''
            : ' data-js-features="' . Html::escape(implode(',', $this->javascriptFeatures)) . '"';
    }

    private function javascriptTag(): string
    {
        return $this->javascriptFeatures === []
            ? ''
            : '<script type="module" src="/static/assets/js/app.js"></script>';
    }

    private function imageControls(): string
    {
        $controls = '';
        if ($this->javascriptFeatureEnabled('image-expansion')) {
            $controls .= '<button class="text-button board-tools__image-toggle" type="button" '
                . 'data-image-expansion-toggle aria-pressed="false" hidden>Expand images</button>';
        }
        if ($this->javascriptFeatureEnabled('image-visibility')) {
            $controls .= '<button class="text-button board-tools__image-toggle" type="button" '
                . 'data-image-visibility-toggle aria-pressed="false" hidden>Hide images</button>'
                . '<span class="visually-hidden" data-image-visibility-status aria-live="polite"></span>';
        }

        return $controls;
    }

    private function enhancementDialog(): string
    {
        if (!$this->javascriptFeatureEnabled('enhancement-settings')) {
            return '';
        }

        $labels = [
            'preferences' => ['Reading preferences', 'Theme, text size, and text weight controls.'],
            'image-expansion' => ['Image expansion', 'Expand attachments in place and expand or shrink all.'],
            'image-visibility' => ['Image visibility', 'Remember whether post images are shown.'],
            'image-gallery' => ['Image gallery', 'Browse attachments in a keyboard-friendly lightbox.'],
            'image-hover' => ['Hover previews', 'Preview an original image after a deliberate pointer hover.'],
            'post-menu-position' => ['Post-menu positioning', 'Keep open post menus inside the viewport.'],
            'local-time' => ['Local timestamps', 'Show relative times with local dates on hover.'],
            'quote-links' => ['Quote context', 'Add backlinks and highlight quoted posts.'],
            'upload-preview' => ['Upload preview', 'Preview a selected image and show its dimensions.'],
            'upload-dropzone' => ['Drag-and-drop upload', 'Drop or paste an image into the focused upload area.'],
            'board-favorites' => ['Favorite boards', 'Pin favorite boards to the front of the board list.'],
            'thread-watchlist' => ['Watched threads', 'Keep a local list of threads and check their status.'],
            'content-hiding' => ['Content hiding', 'Hide posts, threads, names, or plain-text phrases locally.'],
            'locked-thread-filter' => ['Locked-thread filter', 'Remember whether locked threads are collapsed.'],
            'thread-navigation' => ['J/K navigation', 'Move between posts with J and K when not typing.'],
            'compact-board-list' => ['Compact board list', 'Use a denser board navigation bar.'],
            'drafts' => ['Saved drafts', 'Keep unfinished post text in this browser session.'],
            'quote-selection' => ['Quote selection', 'Quote a post or selected passage from its action menu.'],
            'quick-reply' => ['Quick reply', 'Open a compact CSRF-protected reply form without cloning page HTML.'],
            'new-post-notifier' => ['New-post notifier', 'Poll a tiny static manifest and announce new replies.'],
            'catalog-tools' => ['Catalog tools', 'Search and sort the static thread catalog.'],
            'formatting-toolbar' => ['Formatting toolbar', 'Insert BoardHub formatting markers in comment fields.'],
        ];

        $options = '';
        foreach ($this->javascriptFeatures as $feature) {
            if (!isset($labels[$feature])) {
                continue;
            }
            [$label, $description] = $labels[$feature];
            $options .= '<label class="enhancement-option"><input type="checkbox" value="'
                . Html::escape($feature) . '" data-enhancement-feature><span><strong>' . Html::escape($label)
                . '</strong><small>' . Html::escape($description) . '</small></span></label>';
        }

        return '<dialog class="enhancements-dialog" id="enhancements-dialog" aria-labelledby="enhancements-title">'
            . '<form method="dialog" class="enhancements-form" data-enhancements-form>'
            . '<header><h2 id="enhancements-title">Enhancements</h2>'
            . '<button type="button" class="text-button enhancements-close" data-enhancements-close aria-label="Close">×</button></header>'
            . '<p>These choices stay in this browser. The site operator still controls which features are available.</p>'
            . '<fieldset><legend>Available features</legend><div class="enhancement-options">' . $options . '</div></fieldset>'
            . '<div data-enhancement-extras></div><p class="enhancements-status" data-enhancements-status aria-live="polite"></p>'
            . '<footer><button type="submit" class="button">Apply and reload</button>'
            . '<button type="button" class="button button--quiet" data-enhancements-reset>Reset</button>'
            . '<button type="button" class="button button--quiet" data-enhancements-export>Export</button>'
            . '<label class="button button--quiet enhancements-import">Import'
            . '<input type="file" accept="application/json,.json" data-enhancements-import></label></footer>'
            . '</form></dialog>';
    }

    private function themeOptions(): string
    {
        return '<optgroup label="Light themes"><option value="checkmate">Checkmate</option><option value="queen">Queen</option>'
            . '<option value="bishop">Bishop</option><option value="caro-kann">Caro-Kann</option><option value="ruy-lopez">Ruy Lopez</option>'
            . '<option value="italian-game">Italian Game</option><option value="catalan">Catalan</option><option value="london-system">London System</option>'
            . '<option value="ivory">Ivory</option><option value="endgame">Endgame</option></optgroup>'
            . '<optgroup label="Mid-tone themes"><option value="king">King</option><option value="rook">Rook</option>'
            . '<option value="knight">Knight</option><option value="pawn">Pawn</option><option value="sicilian">Sicilian</option>'
            . '<option value="french-defense">French Defense</option><option value="english-opening">English Opening</option>'
            . '<option value="nimzo-indian">Nimzo-Indian</option><option value="queens-indian">Queen\'s Indian</option>'
            . '<option value="scandinavian">Scandinavian</option></optgroup>'
            . '<optgroup label="Dark themes"><option value="kings-indian">King\'s Indian</option><option value="grunfeld">Grünfeld</option>'
            . '<option value="alekhine">Alekhine</option><option value="pirc">Pirc</option><option value="dragon">Dragon</option>'
            . '<option value="najdorf">Najdorf</option><option value="walnut">Walnut</option><option value="midnight-mate">Midnight Mate</option></optgroup>'
            . '<optgroup label="Experimental themes"><option value="kings-gambit">King\'s Gambit</option>'
            . '<option value="queens-gambit">Queen\'s Gambit</option><option value="yotsuba">Yotsuba (legacy)</option>'
            . '<option value="yotsuba-b">Yotsuba B (legacy)</option><option value="miku">Miku (legacy)</option>'
            . '<option value="tomorrow">Tomorrow (legacy)</option><option value="pink">Pink (legacy)</option>'
            . '<option value="green-dark">Green Dark (legacy)</option></optgroup>';
    }
}
