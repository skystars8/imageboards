<?php

declare(strict_types=1);

namespace BoardHub;

use RuntimeException;

final class RateLimitException extends RuntimeException
{
    public function __construct(string $message = 'Please wait before trying again.', public readonly int $retryAfter = 60)
    {
        parent::__construct($message);
    }
}
