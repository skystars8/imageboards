<?php

declare(strict_types=1);

namespace BoardHub;

use BoardHub\Support\Uuid;
use JsonException;
use RuntimeException;

final class BoardRegistry
{
    private const RESERVED_SLUGS = [
        'all',
        'backups',
        'bin',
        'board-template',
        'compose',
        'config',
        'database',
        'generated',
        'healthz',
        'media',
        'mod',
        'post',
        'public',
        'report',
        'site-data',
        'src',
        'static',
        'stylesheets',
        'tests',
        'tools',
        'var',
    ];

    /** @var array<string, Board> */
    private array $boards = [];

    /** @var array<string, string> */
    private array $issues = [];

    public function __construct(private readonly Config $config)
    {
        $this->discover();
    }

    /** @return list<Board> */
    public function all(): array
    {
        $boards = array_values($this->boards);
        usort($boards, static fn (Board $a, Board $b): int => strcasecmp($a->title, $b->title));

        return $boards;
    }

    public function get(string $slug): ?Board
    {
        return $this->boards[$slug] ?? null;
    }

    /** @return array<string, string> */
    public function issues(): array
    {
        return $this->issues;
    }

    private function discover(): void
    {
        $entries = scandir($this->config->webRoot);
        if ($entries === false) {
            throw new RuntimeException('Unable to scan the web root.');
        }

        $ids = [];
        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..' || str_starts_with($entry, '_') || str_starts_with($entry, '.')
                || in_array($entry, self::RESERVED_SLUGS, true)) {
                continue;
            }

            $path = $this->config->webRoot . DIRECTORY_SEPARATOR . $entry;
            if (!is_dir($path)) {
                continue;
            }

            $privatePath = $path . DIRECTORY_SEPARATOR . '.board';
            if (!is_dir($privatePath)) {
                continue;
            }

            try {
                $board = $this->loadBoard($entry, $path);
                if (isset($ids[$board->id])) {
                    throw new RuntimeException("Board identity is duplicated by '{$ids[$board->id]}'. Copy the template, not an existing live board.");
                }
                $ids[$board->id] = $board->slug;
                $this->boards[$board->slug] = $board;
            } catch (\Throwable $error) {
                $this->issues[$entry] = $error->getMessage();
            }
        }
    }

    private function loadBoard(string $slug, string $path): Board
    {
        if (!preg_match('/\A[a-z0-9][a-z0-9-]{0,39}\z/', $slug) || in_array($slug, self::RESERVED_SLUGS, true)) {
            throw new RuntimeException('Invalid or reserved board directory name.');
        }

        $configPath = $path . DIRECTORY_SEPARATOR . '.board' . DIRECTORY_SEPARATOR . 'board.json';
        $json = file_get_contents($configPath);
        if ($json === false) {
            throw new RuntimeException('Missing or unreadable .board/board.json.');
        }

        try {
            $data = json_decode($json, true, 16, JSON_THROW_ON_ERROR);
        } catch (JsonException $error) {
            throw new RuntimeException('Invalid board.json: ' . $error->getMessage(), 0, $error);
        }
        if (!is_array($data)) {
            throw new RuntimeException('board.json must contain an object.');
        }

        $title = trim((string) ($data['title'] ?? ''));
        $description = trim((string) ($data['description'] ?? ''));
        $postingEnabled = $data['posting_enabled'] ?? true;
        $postingMode = $data['posting_mode'] ?? ($postingEnabled ? 'open' : 'closed');
        $threadsPerPage = $data['threads_per_page'] ?? 10;
        if ($title === '' || mb_strlen($title) > 80) {
            throw new RuntimeException('Board title must be 1–80 characters.');
        }
        if (mb_strlen($description) > 300) {
            throw new RuntimeException('Board description must be at most 300 characters.');
        }
        if (!is_bool($postingEnabled)) {
            throw new RuntimeException('posting_enabled must be true or false.');
        }
        if (!is_string($postingMode) || !in_array($postingMode, ['open', 'approval', 'password', 'closed'], true)) {
            throw new RuntimeException('posting_mode must be open, approval, password, or closed.');
        }
        if (!is_int($threadsPerPage) || $threadsPerPage < 1 || $threadsPerPage > 50) {
            throw new RuntimeException('threads_per_page must be an integer from 1 to 50.');
        }

        $idPath = $path . DIRECTORY_SEPARATOR . '.board' . DIRECTORY_SEPARATOR . '.board-id';
        $handle = @fopen($idPath, 'c+');
        if ($handle === false || !flock($handle, LOCK_EX)) {
            if (is_resource($handle)) {
                fclose($handle);
            }
            throw new RuntimeException('Unable to lock .board/.board-id. Check directory permissions.');
        }
        try {
            rewind($handle);
            $id = trim((string) stream_get_contents($handle));
            if ($id === '') {
                $id = Uuid::v4();
                ftruncate($handle, 0);
                rewind($handle);
                if (fwrite($handle, $id . PHP_EOL) === false || !fflush($handle)) {
                    throw new RuntimeException('Unable to create .board/.board-id. Check directory permissions.');
                }
                if (function_exists('fsync')) {
                    fsync($handle);
                }
            }
        } finally {
            flock($handle, LOCK_UN);
            fclose($handle);
        }
        if (!Uuid::isValid($id)) {
            throw new RuntimeException('Invalid .board/.board-id. Restore the original ID or remove it only for a brand-new empty board.');
        }

        return new Board($id, $slug, $title, $description, $postingMode, $threadsPerPage, $path);
    }
}
