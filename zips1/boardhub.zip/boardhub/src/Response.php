<?php

declare(strict_types=1);

namespace BoardHub;

final class Response
{
    public static function html(string $body, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        header("Content-Security-Policy: default-src 'self'; img-src 'self' blob:; style-src 'self'; form-action 'self'; base-uri 'none'; frame-ancestors 'none'");
        echo $body;
        exit;
    }

    public static function text(string $body, int $status = 200): never
    {
        http_response_code($status);
        header('Content-Type: text/plain; charset=utf-8');
        header('X-Content-Type-Options: nosniff');
        echo $body;
        exit;
    }

    /** @param array<string,mixed>|list<mixed> $body */
    public static function json(array $body, int $status = 200): never
    {
        $encoded = json_encode($body, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES);
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Content-Type-Options: nosniff');
        echo $encoded;
        exit;
    }

    public static function redirect(string $location, int $status = 303): never
    {
        if (!str_starts_with($location, '/')) {
            throw new \InvalidArgumentException('Redirects must remain on this site.');
        }
        header('Location: ' . $location, true, $status);
        exit;
    }
}
