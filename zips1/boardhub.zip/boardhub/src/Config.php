<?php

declare(strict_types=1);

namespace BoardHub;

use RuntimeException;

final readonly class Config
{
    public const DEFAULT_JAVASCRIPT_FEATURES = [
        'enhancement-settings',
        'preferences',
        'image-expansion',
        'image-visibility',
        'image-gallery',
        'image-hover',
        'post-menu-position',
        'moderator-helpers',
        'local-time',
        'quote-links',
        'upload-preview',
        'upload-dropzone',
        'board-favorites',
        'thread-watchlist',
        'content-hiding',
        'locked-thread-filter',
        'thread-navigation',
        'compact-board-list',
        'drafts',
        'quote-selection',
        'quick-reply',
        'new-post-notifier',
        'catalog-tools',
        'formatting-toolbar',
    ];

    public function __construct(
        public string $root,

        public string $templatePath,
        public string $webRoot,
        public string $siteDataPath,
        public string $controlDatabasePath,
        public string $writeLockPath,
        public string $environment,
        public bool $secureCookies,
        public int $maxUploadBytes,
        public int $maxImageDimension,
        public int $maxImagePixels,
        public int $maxPendingPostsPerBoard = 150,
        /** @var list<string> */
        public array $javascriptFeatures = self::DEFAULT_JAVASCRIPT_FEATURES,
    ) {
    }

    public static function load(string $root): self
    {
        $environment = self::env('BOARDHUB_ENV', 'development');
        if (!in_array($environment, ['development', 'production', 'test'], true)) {
            throw new RuntimeException('BOARDHUB_ENV must be development, production, or test.');
        }

        $javascriptEnabled = self::boolEnv('BOARDHUB_JAVASCRIPT', true);
        $config = new self(
            root: $root,

            templatePath: self::env('BOARDHUB_TEMPLATE_PATH', $root . '/board-template'),
            webRoot: $root,
            siteDataPath: self::env('BOARDHUB_SITE_DATA_PATH', $root . '/site-data'),
            controlDatabasePath: self::env('BOARDHUB_CONTROL_DB', $root . '/site-data/control.sqlite3'),
            writeLockPath: self::env('BOARDHUB_WRITE_LOCK', $root . '/site-data/site-write.lock'),
            environment: $environment,
            secureCookies: self::boolEnv('BOARDHUB_SECURE_COOKIES', $environment === 'production'),
            maxUploadBytes: self::intEnv('BOARDHUB_MAX_UPLOAD_BYTES', 5 * 1024 * 1024, 1, 25 * 1024 * 1024),
            maxImageDimension: self::intEnv('BOARDHUB_MAX_IMAGE_DIMENSION', 16_384, 128, 65_535),
            maxImagePixels: self::intEnv('BOARDHUB_MAX_IMAGE_PIXELS', 100_000_000, 10_000, 250_000_000),
            maxPendingPostsPerBoard: self::intEnv('BOARDHUB_MAX_PENDING_POSTS_PER_BOARD', 150, 1, 10_000),
            javascriptFeatures: self::javascriptFeatures($javascriptEnabled),
        );

        self::ensureDirectory($config->webRoot, 0755);
        self::ensureDirectory($config->siteDataPath, 0750);

        if ($environment === 'production' && !$config->secureCookies) {
            throw new RuntimeException('Production requires BOARDHUB_SECURE_COOKIES=true.');
        }

        return $config;
    }

    public function moderatorBootstrapPassword(): ?string
    {
        $value = getenv('BOARDHUB_MOD_PASSWORD');
        return is_string($value) && $value !== '' ? $value : null;
    }

    public static function ensureDirectory(string $path, int $mode = 0750): void
    {
        if (!is_dir($path) && !mkdir($path, $mode, true) && !is_dir($path)) {
            throw new RuntimeException('Could not create directory: ' . $path);
        }
    }

    private static function env(string $name, string $default): string
    {
        $value = getenv($name);
        return is_string($value) && $value !== '' ? $value : $default;
    }

    private static function boolEnv(string $name, bool $default): bool
    {
        $value = getenv($name);
        if ($value === false || $value === '') {
            return $default;
        }
        return filter_var($value, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE)
            ?? throw new RuntimeException($name . ' must be true or false.');
    }

    private static function intEnv(string $name, int $default, int $minimum, int $maximum): int
    {
        $value = getenv($name);
        if ($value === false || $value === '') {
            return $default;
        }
        $integer = filter_var($value, FILTER_VALIDATE_INT);
        if (!is_int($integer) || $integer < $minimum || $integer > $maximum) {
            throw new RuntimeException(sprintf('%s must be between %d and %d.', $name, $minimum, $maximum));
        }
        return $integer;
    }

    /** @return list<string> */
    private static function javascriptFeatures(bool $enabled): array
    {
        if (!$enabled) {
            return [];
        }

        $value = getenv('BOARDHUB_JS_FEATURES');
        if ($value === false || trim($value) === '' || strtolower(trim($value)) === 'all') {
            return self::DEFAULT_JAVASCRIPT_FEATURES;
        }
        if (strtolower(trim($value)) === 'none') {
            return [];
        }

        $requested = preg_split('/\s*,\s*/', strtolower(trim($value)), -1, PREG_SPLIT_NO_EMPTY);
        if (!is_array($requested)) {
            throw new RuntimeException('BOARDHUB_JS_FEATURES could not be parsed.');
        }
        $unknown = array_values(array_diff($requested, self::DEFAULT_JAVASCRIPT_FEATURES));
        if ($unknown !== []) {
            throw new RuntimeException(
                'Unknown BOARDHUB_JS_FEATURES value(s): ' . implode(', ', $unknown)
                . '. Allowed values: ' . implode(', ', self::DEFAULT_JAVASCRIPT_FEATURES) . ', all, none.'
            );
        }

        $requestedLookup = array_fill_keys($requested, true);
        return array_values(array_filter(
            self::DEFAULT_JAVASCRIPT_FEATURES,
            static fn (string $feature): bool => isset($requestedLookup[$feature]),
        ));
    }
}
