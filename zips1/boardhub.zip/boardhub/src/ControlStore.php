<?php

declare(strict_types=1);

namespace BoardHub;

use PDO;
use RuntimeException;
use Throwable;

final class ControlStore
{
    private PDO $pdo;

    public function __construct(private readonly Config $config, bool $bootstrapFromEnvironment = true)
    {
        $this->pdo = new PDO('sqlite:' . $config->controlDatabasePath, null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_STRINGIFY_FETCHES => false,
        ]);
        $this->pdo->exec('PRAGMA journal_mode = WAL');
        $this->pdo->exec('PRAGMA synchronous = FULL');
        $this->pdo->exec('PRAGMA foreign_keys = ON');
        $this->pdo->exec('PRAGMA busy_timeout = 5000');
        $schema = file_get_contents($config->root . '/database/control-schema.sql');
        if ($schema === false) {
            throw new RuntimeException('Control database schema is missing.');
        }
        $this->installSchema($schema);
        if ($bootstrapFromEnvironment) {
            $this->bootstrapFromEnvironment();
        }
    }

    public function createModerator(string $username, string $password): void
    {
        $username = trim($username);
        if (!preg_match('/\A[a-zA-Z0-9_-]{3,40}\z/', $username)) {
            throw new RuntimeException('Moderator username must be 3–40 letters, numbers, underscores, or hyphens.');
        }
        if (strlen($password) < 12) {
            throw new RuntimeException('Moderator password must be at least 12 characters.');
        }
        $hash = password_hash($password, PASSWORD_ARGON2ID);
        if (!is_string($hash)) {
            throw new RuntimeException('Unable to hash the moderator password.');
        }
        $statement = $this->pdo->prepare(
            'INSERT INTO moderators (username, password_hash, created_at) VALUES (:username, :password_hash, :created_at)'
        );
        $statement->execute(['username' => $username, 'password_hash' => $hash, 'created_at' => time()]);
    }

    public function hasModerators(): bool
    {
        return (int) $this->pdo->query('SELECT COUNT(*) FROM moderators')->fetchColumn() > 0;
    }

    /** @return array{id:int,username:string,password_hash:string}|null */
    public function moderatorByUsername(string $username): ?array
    {
        $statement = $this->pdo->prepare('SELECT id, username, password_hash FROM moderators WHERE username = :username');
        $statement->execute(['username' => $username]);
        $row = $statement->fetch();

        return is_array($row) ? ['id' => (int) $row['id'], 'username' => (string) $row['username'], 'password_hash' => (string) $row['password_hash']] : null;
    }

    public function loginAllowed(string $rateKey): bool
    {
        $cutoff = time() - 900;
        $this->pdo->prepare('DELETE FROM login_events WHERE occurred_at < :cutoff')->execute(['cutoff' => time() - 86400]);
        $statement = $this->pdo->prepare('SELECT COUNT(*) FROM login_events WHERE rate_key = :hash AND occurred_at >= :cutoff');
        $statement->execute(['hash' => $rateKey, 'cutoff' => $cutoff]);

        return (int) $statement->fetchColumn() < 10;
    }

    public function recordLoginAttempt(string $rateKey): void
    {
        $statement = $this->pdo->prepare('INSERT INTO login_events (rate_key, occurred_at) VALUES (:hash, :now)');
        $statement->execute(['hash' => $rateKey, 'now' => time()]);
    }

    public function createSession(int $moderatorId, string $tokenHash, string $csrfToken): void
    {
        $this->deleteExpiredSessions();
        $statement = $this->pdo->prepare(
            'INSERT INTO moderator_sessions (token_hash, moderator_id, csrf_token, created_at, expires_at)
             VALUES (:token_hash, :moderator_id, :csrf_token, :created_at, :expires_at)'
        );
        $now = time();
        $statement->execute([
            'token_hash' => $tokenHash,
            'moderator_id' => $moderatorId,
            'csrf_token' => $csrfToken,
            'created_at' => $now,
            'expires_at' => $now + 43200,
        ]);
    }

    /** @return array{username:string,csrf_token:string}|null */
    public function session(string $tokenHash): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT m.username, s.csrf_token
             FROM moderator_sessions s JOIN moderators m ON m.id = s.moderator_id
             WHERE s.token_hash = :token_hash AND s.expires_at > :now'
        );
        $statement->execute(['token_hash' => $tokenHash, 'now' => time()]);
        $row = $statement->fetch();

        return is_array($row) ? ['username' => (string) $row['username'], 'csrf_token' => (string) $row['csrf_token']] : null;
    }

    public function deleteSession(string $tokenHash): void
    {
        $this->pdo->prepare('DELETE FROM moderator_sessions WHERE token_hash = :token_hash')->execute(['token_hash' => $tokenHash]);
    }

    /** @param array<string, mixed> $details */
    public function audit(string $moderator, string $action, ?string $boardSlug, array $details = []): void
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO global_audit (moderator, action, board_slug, details, created_at)
             VALUES (:moderator, :action, :board_slug, :details, :created_at)'
        );
        $statement->execute([
            'moderator' => $moderator,
            'action' => $action,
            'board_slug' => $boardSlug,
            'details' => json_encode($details, JSON_THROW_ON_ERROR),
            'created_at' => time(),
        ]);
    }

    private function installSchema(string $schema): void
    {
        $this->pdo->exec($schema);
        $version = (string) $this->pdo->query(
            "SELECT value FROM app_meta WHERE key = 'schema_version'"
        )->fetchColumn();
        if ($version === '1') {
            $this->pdo->exec('BEGIN IMMEDIATE');
            try {
                $this->pdo->exec('DROP INDEX IF EXISTS idx_login_events');
                $this->pdo->exec('DELETE FROM login_events');
                $this->pdo->exec('ALTER TABLE login_events RENAME COLUMN client_hash TO rate_key');
                $this->pdo->exec(
                    "UPDATE app_meta SET value = '2' WHERE key = 'schema_version' AND value = '1'"
                );
                $this->pdo->exec('COMMIT');
            } catch (Throwable $error) {
                if ($this->pdo->inTransaction()) {
                    $this->pdo->exec('ROLLBACK');
                }
                throw $error;
            }
            $version = '2';
        }
        if ($version !== '2') {
            throw new RuntimeException('Unsupported control database schema version.');
        }
        $this->pdo->exec(
            'CREATE INDEX IF NOT EXISTS idx_login_events
             ON login_events(rate_key, occurred_at DESC)'
        );
    }

    private function deleteExpiredSessions(): void
    {
        $this->pdo->prepare('DELETE FROM moderator_sessions WHERE expires_at <= :now')->execute(['now' => time()]);
    }

    private function bootstrapFromEnvironment(): void
    {
        $count = (int) $this->pdo->query('SELECT COUNT(*) FROM moderators')->fetchColumn();
        $password = $this->config->moderatorBootstrapPassword();
        if ($count === 0 && $password !== null) {
            $this->createModerator('admin', $password);
        }
    }
}
