<?php

declare(strict_types=1);

namespace BoardHub;

use PDO;
use PDOException;
use RuntimeException;
use Throwable;

final class BoardStore
{
    private PDO $pdo;

    public function __construct(private readonly Config $config, public readonly Board $board)
    {
        $this->pdo = new PDO('sqlite:' . $board->databasePath(), null, null, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_STRINGIFY_FETCHES => false,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
        $this->pdo->exec('PRAGMA journal_mode = WAL');
        $this->pdo->exec('PRAGMA synchronous = FULL');
        $this->pdo->exec('PRAGMA foreign_keys = ON');
        $this->pdo->exec('PRAGMA busy_timeout = 5000');
        $this->installSchema();
    }

    /** @return array{revision:int,published_revision:int} */
    public function state(): array
    {
        $row = $this->pdo->query('SELECT revision, published_revision FROM board_state WHERE singleton = 1')->fetch();
        if (!is_array($row)) {
            throw new RuntimeException('Board state is missing.');
        }

        return ['revision' => (int) $row['revision'], 'published_revision' => (int) $row['published_revision']];
    }

    public function markPublished(int $revision): bool
    {
        $statement = $this->pdo->prepare(
            'UPDATE board_state SET published_revision = :revision WHERE singleton = 1 AND revision = :revision'
        );
        $statement->execute(['revision' => $revision]);

        return $statement->rowCount() === 1;
    }

    /** @return array{id:int,thread_id:int,approved:bool} */
    public function createPost(
        ?int $threadId,
        string $name,
        string $subject,
        string $body,
        ?Upload $upload,
        string $rateKey,
        ?string $verifiedPasswordHash = null,
    ): array {
        return $this->immediate(function () use (
            $threadId,
            $name,
            $subject,
            $body,
            $upload,
            $rateKey,
            $verifiedPasswordHash,
        ): array {
            $this->enforceRateLimit('post', $rateKey, 60, 8);
            $policy = $this->postingPolicy();
            $mode = $policy['posting_mode'];
            if ($mode === 'closed') {
                throw new HttpException(409, 'Posting is paused on this board.');
            }
            if ($mode === 'password') {
                $currentHash = $policy['posting_password_hash'];
                if ($currentHash === null || $verifiedPasswordHash === null
                    || !hash_equals($currentHash, $verifiedPasswordHash)) {
                    throw new HttpException(403, 'Incorrect board posting password.');
                }
            }
            $approved = $mode !== 'approval';
            if (!$approved && $this->pendingCount() >= $this->config->maxPendingPostsPerBoard) {
                throw new HttpException(503, 'This approval queue is temporarily full. Please try again after moderation catches up.');
            }

            $now = time();
            if ($threadId !== null) {
                $thread = $this->post($threadId);
                if ($thread === null || (int) $thread['thread_id'] !== (int) $thread['id']
                    || (int) $thread['deleted'] === 1 || (int) $thread['approved'] !== 1) {
                    throw new HttpException(404, 'Thread not found.');
                }
                if ((int) $thread['locked'] === 1) {
                    throw new HttpException(409, 'This thread is locked.');
                }
            }

            $statement = $this->pdo->prepare(
                'INSERT INTO posts (
                    thread_id, is_op, name, subject, body, image_original_name, image_stored_name,
                    thumbnail_stored_name, image_mime, image_size, image_width, image_height,
                    created_at, updated_at, last_activity_at, approved
                 ) VALUES (
                    :thread_id, :is_op, :name, :subject, :body, :image_original_name, :image_stored_name,
                    :thumbnail_stored_name, :image_mime, :image_size, :image_width, :image_height,
                    :created_at, :updated_at, :last_activity_at, :approved
                 )'
            );
            $statement->execute([
                'thread_id' => $threadId,
                'is_op' => $threadId === null ? 1 : 0,
                'name' => $name,
                'subject' => $subject,
                'body' => $body,
                'image_original_name' => $upload?->originalName,
                'image_stored_name' => $upload?->storedName,
                'thumbnail_stored_name' => $upload?->thumbnailName,
                'image_mime' => $upload?->mimeType,
                'image_size' => $upload?->size,
                'image_width' => $upload?->width,
                'image_height' => $upload?->height,
                'created_at' => $now,
                'updated_at' => $now,
                'last_activity_at' => $now,
                'approved' => $approved ? 1 : 0,
            ]);
            $id = (int) $this->pdo->lastInsertId();
            $actualThreadId = $threadId ?? $id;
            if ($threadId === null) {
                $update = $this->pdo->prepare('UPDATE posts SET thread_id = :id WHERE id = :id');
                $update->execute(['id' => $id]);
            } elseif ($approved) {
                $update = $this->pdo->prepare('UPDATE posts SET last_activity_at = :now WHERE id = :thread_id');
                $update->execute(['now' => $now, 'thread_id' => $threadId]);
            }
            if ($approved) {
                $this->touchRevision();
            }

            return ['id' => $id, 'thread_id' => $actualThreadId, 'approved' => $approved];
        });
    }
    /** @return list<array<string, mixed>> */
    public function threadPosts(int $threadId): array
    {
        $statement = $this->pdo->prepare(
            'SELECT * FROM posts WHERE thread_id = :thread_id AND approved = 1 AND deleted = 0 ORDER BY id ASC'
        );
        $statement->execute(['thread_id' => $threadId]);

        return $statement->fetchAll();
    }

    /** @return array<string, mixed>|null */
    public function post(int $id): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT p.*, op.sticky AS thread_sticky, op.locked AS thread_locked
             FROM posts p JOIN posts op ON op.id = p.thread_id WHERE p.id = :id'
        );
        $statement->execute(['id' => $id]);
        $row = $statement->fetch();

        return is_array($row) ? $row : null;
    }

    /** @return list<array{op:array<string,mixed>,replies:list<array<string,mixed>>,reply_count:int}> */
    public function threads(): array
    {
        $statement = $this->pdo->prepare(
            'SELECT * FROM posts
             WHERE is_op = 1 AND approved = 1 AND deleted = 0
             ORDER BY sticky DESC, last_activity_at DESC, id DESC
             LIMIT :limit'
        );
        $statement->bindValue('limit', $this->board->threadsPerPage, PDO::PARAM_INT);
        $statement->execute();
        $result = [];
        foreach ($statement->fetchAll() as $op) {
            $countStatement = $this->pdo->prepare(
                'SELECT COUNT(*) FROM posts WHERE thread_id = :thread_id AND is_op = 0 AND approved = 1 AND deleted = 0'
            );
            $countStatement->execute(['thread_id' => $op['id']]);
            $count = (int) $countStatement->fetchColumn();
            $replyStatement = $this->pdo->prepare(
                'SELECT * FROM (
                    SELECT * FROM posts
                    WHERE thread_id = :thread_id AND is_op = 0 AND approved = 1 AND deleted = 0
                    ORDER BY id DESC LIMIT 2
                 ) ORDER BY id ASC'
            );
            $replyStatement->execute(['thread_id' => $op['id']]);
            $result[] = ['op' => $op, 'replies' => $replyStatement->fetchAll(), 'reply_count' => $count];
        }

        return $result;
    }

    /** @return list<array<string,mixed>> */
    public function catalogThreads(): array
    {
        $statement = $this->pdo->query(
            'SELECT op.*,
                    (SELECT COUNT(*) FROM posts reply
                     WHERE reply.thread_id = op.id AND reply.is_op = 0
                       AND reply.approved = 1 AND reply.deleted = 0) AS reply_count,
                    (SELECT COUNT(*) FROM posts image_post
                     WHERE image_post.thread_id = op.id AND image_post.approved = 1
                       AND image_post.deleted = 0 AND image_post.image_stored_name IS NOT NULL) AS image_count,
                    (SELECT MAX(recent.id) FROM posts recent
                     WHERE recent.thread_id = op.id AND recent.approved = 1
                       AND recent.deleted = 0) AS last_post_id
             FROM posts op
             WHERE op.is_op = 1 AND op.approved = 1 AND op.deleted = 0
             ORDER BY op.sticky DESC, op.last_activity_at DESC, op.id DESC'
        );

        return $statement->fetchAll();
    }

    /** @return array{revision:int,generated_at:int,threads:list<array{id:int,last_post_id:int,post_count:int,locked:bool,last_activity_at:int}>} */
    public function updateManifest(): array
    {
        $state = $this->state();
        $threads = [];
        foreach ($this->catalogThreads() as $thread) {
            $threads[] = [
                'id' => (int) $thread['id'],
                'last_post_id' => (int) $thread['last_post_id'],
                'post_count' => (int) $thread['reply_count'] + 1,
                'locked' => (int) $thread['locked'] === 1,
                'last_activity_at' => (int) $thread['last_activity_at'],
            ];
        }

        return [
            'revision' => (int) $state['revision'],
            'generated_at' => time(),
            'threads' => $threads,
        ];
    }

    /** @return list<array<string, mixed>> */
    public function latestActivity(int $limit): array
    {
        $statement = $this->pdo->prepare(
            'SELECT p.*, op.subject AS thread_subject,
                    op.sticky AS thread_sticky, op.locked AS thread_locked
             FROM posts p JOIN posts op ON op.id = p.thread_id
             WHERE p.approved = 1 AND op.approved = 1 AND p.deleted = 0 AND op.deleted = 0
             ORDER BY p.updated_at DESC, p.id DESC LIMIT :limit'
        );
        $statement->bindValue('limit', $limit, PDO::PARAM_INT);
        $statement->execute();

        return $statement->fetchAll();
    }

    /** @return array{posts:int,threads:int,images:int,pending:int,open_reports:int} */
    public function moderationStats(): array
    {
        return [
            'posts' => (int) $this->pdo->query('SELECT COUNT(*) FROM posts WHERE approved = 1 AND deleted = 0')->fetchColumn(),
            'threads' => (int) $this->pdo->query('SELECT COUNT(*) FROM posts WHERE is_op = 1 AND approved = 1 AND deleted = 0')->fetchColumn(),
            'images' => (int) $this->pdo->query('SELECT COUNT(*) FROM posts WHERE approved = 1 AND deleted = 0 AND image_stored_name IS NOT NULL')->fetchColumn(),
            'pending' => $this->pendingCount(),
            'open_reports' => (int) $this->pdo->query("SELECT COUNT(*) FROM reports WHERE status = 'open'")->fetchColumn(),
        ];
    }

    /** @return array{posting_mode:string,posting_password_hash:?string} */
    public function postingPolicy(): array
    {
        $row = $this->pdo->query(
            'SELECT posting_mode, posting_password_hash FROM board_settings WHERE singleton = 1'
        )->fetch();
        if (!is_array($row)) {
            throw new RuntimeException('Board posting policy is missing.');
        }

        return [
            'posting_mode' => (string) $row['posting_mode'],
            'posting_password_hash' => is_string($row['posting_password_hash'])
                ? $row['posting_password_hash']
                : null,
        ];
    }

    public static function hashPostingPassword(string $password): string
    {
        $length = mb_strlen($password);
        if ($length < 8 || $length > 128) {
            throw new HttpException(400, 'Posting passwords must be between 8 and 128 characters.');
        }
        $hash = password_hash($password, PASSWORD_ARGON2ID);
        if (!is_string($hash)) {
            throw new RuntimeException('Unable to hash the board posting password.');
        }

        return $hash;
    }

    public function verifyPostingPassword(string $password, string $rateKey): ?string
    {
        $policy = $this->immediate(function () use ($rateKey): array {
            $this->enforceRateLimit('posting_password', $rateKey, 60, 12);

            return $this->postingPolicy();
        });
        $hash = $policy['posting_password_hash'];
        if ($policy['posting_mode'] !== 'password' || $hash === null || mb_strlen($password) > 128) {
            return null;
        }

        return password_verify($password, $hash) ? $hash : null;
    }

    public function updatePostingPolicy(string $mode, ?string $passwordHash): void
    {
        if (!in_array($mode, ['open', 'approval', 'password', 'closed'], true)) {
            throw new HttpException(400, 'Invalid board posting mode.');
        }
        if ($mode === 'password' && $passwordHash === null) {
            throw new HttpException(400, 'Set a posting password before enabling password mode.');
        }
        $this->immediate(function () use ($mode, $passwordHash): void {
            $statement = $this->pdo->prepare(
                'UPDATE board_settings
                 SET posting_mode = :posting_mode, posting_password_hash = :posting_password_hash
                 WHERE singleton = 1'
            );
            $statement->execute([
                'posting_mode' => $mode,
                'posting_password_hash' => $passwordHash,
            ]);
            if ($statement->rowCount() !== 1) {
                throw new RuntimeException('Unable to update the board posting policy.');
            }
        });
    }

    public function pendingCount(): int
    {
        return (int) $this->pdo->query(
            'SELECT COUNT(*) FROM posts WHERE approved = 0 AND deleted = 0'
        )->fetchColumn();
    }

    /** @return list<array<string,mixed>> */
    public function pendingPosts(int $limit = 100): array
    {
        $statement = $this->pdo->prepare(
            'SELECT p.*, op.sticky AS thread_sticky, op.locked AS thread_locked
             FROM posts p JOIN posts op ON op.id = p.thread_id
             WHERE p.approved = 0 AND p.deleted = 0
             ORDER BY p.created_at ASC, p.id ASC LIMIT :limit'
        );
        $statement->bindValue('limit', max(1, min(500, $limit)), PDO::PARAM_INT);
        $statement->execute();

        return $statement->fetchAll();
    }

    /** @return array{id:int,thread_id:int} */
    public function approvePost(int $postId, string $moderator): array
    {
        return $this->immediate(function () use ($postId, $moderator): array {
            $post = $this->post($postId);
            if ($post === null || (int) $post['deleted'] === 1 || (int) $post['approved'] === 1) {
                throw new HttpException(404, 'Pending post not found.');
            }
            $threadId = (int) $post['thread_id'];
            $isOp = (int) $post['is_op'] === 1;
            if (!$isOp) {
                $parent = $this->post($threadId);
                if ($parent === null || (int) $parent['is_op'] !== 1
                    || (int) $parent['approved'] !== 1 || (int) $parent['deleted'] === 1) {
                    throw new HttpException(409, 'Approve the parent thread before this reply.');
                }
            }

            $now = time();
            $statement = $this->pdo->prepare(
                'UPDATE posts SET approved = 1, updated_at = :now, last_activity_at = :now
                 WHERE id = :id AND approved = 0 AND deleted = 0'
            );
            $statement->execute(['now' => $now, 'id' => $postId]);
            if ($statement->rowCount() !== 1) {
                throw new HttpException(404, 'Pending post not found.');
            }
            if (!$isOp) {
                $activity = $this->pdo->prepare('UPDATE posts SET last_activity_at = :now WHERE id = :thread_id');
                $activity->execute(['now' => $now, 'thread_id' => $threadId]);
            }
            $this->audit($moderator, 'approve_post', $postId, ['thread_id' => $threadId]);
            $this->touchRevision();

            return ['id' => $postId, 'thread_id' => $threadId];
        });
    }

    /** @return array{originals:list<string>,thumbs:list<string>} */
    public function rejectPending(int $postId, string $moderator): array
    {
        return $this->immediate(function () use ($postId, $moderator): array {
            $post = $this->post($postId);
            if ($post === null || (int) $post['deleted'] === 1 || (int) $post['approved'] === 1) {
                throw new HttpException(404, 'Pending post not found.');
            }
            $threadId = (int) $post['thread_id'];
            $isOp = (int) $post['is_op'] === 1;
            if ($isOp) {
                $files = $this->pdo->prepare(
                    'SELECT image_stored_name, thumbnail_stored_name
                     FROM posts WHERE thread_id = :thread_id AND approved = 0'
                );
                $files->execute(['thread_id' => $threadId]);
            } else {
                $files = $this->pdo->prepare(
                    'SELECT image_stored_name, thumbnail_stored_name
                     FROM posts WHERE id = :id AND approved = 0'
                );
                $files->execute(['id' => $postId]);
            }
            $originals = [];
            $thumbs = [];
            foreach ($files->fetchAll() as $file) {
                if (is_string($file['image_stored_name'])) {
                    $originals[] = $file['image_stored_name'];
                }
                if (is_string($file['thumbnail_stored_name'])) {
                    $thumbs[] = $file['thumbnail_stored_name'];
                }
            }

            if ($isOp) {
                $children = $this->pdo->prepare(
                    'DELETE FROM posts WHERE thread_id = :thread_id AND id != :id AND approved = 0'
                );
                $children->execute(['thread_id' => $threadId, 'id' => $postId]);
                $detach = $this->pdo->prepare('UPDATE posts SET thread_id = NULL WHERE id = :id AND approved = 0');
                $detach->execute(['id' => $postId]);
            }
            $delete = $this->pdo->prepare('DELETE FROM posts WHERE id = :id AND approved = 0');
            $delete->execute(['id' => $postId]);
            if ($delete->rowCount() !== 1) {
                throw new HttpException(404, 'Pending post not found.');
            }
            $this->audit($moderator, 'reject_pending', $postId, [
                'thread_id' => $threadId,
                'is_op' => $isOp,
            ]);

            return ['originals' => $originals, 'thumbs' => $thumbs];
        });
    }

    public function imageIsAccessible(string $type, string $filename, bool $moderator): bool
    {
        $column = match ($type) {
            'originals' => 'image_stored_name',
            'thumbs' => 'thumbnail_stored_name',
            default => throw new HttpException(404, 'Image not found.'),
        };
        $statement = $this->pdo->prepare(
            "SELECT 1 FROM posts p JOIN posts op ON op.id = p.thread_id
             WHERE p.$column = :filename AND p.deleted = 0 AND op.deleted = 0
               AND (:moderator = 1 OR (p.approved = 1 AND op.approved = 1))
             LIMIT 1"
        );
        $statement->bindValue('filename', $filename);
        $statement->bindValue('moderator', $moderator ? 1 : 0, PDO::PARAM_INT);
        $statement->execute();

        return $statement->fetchColumn() !== false;
    }
    /** @return list<int> */
    public function activeThreadIds(): array
    {
        $rows = $this->pdo->query(
            'SELECT id FROM posts WHERE is_op = 1 AND approved = 1 AND deleted = 0 ORDER BY id'
        )->fetchAll();

        return array_map(static fn (array $row): int => (int) $row['id'], $rows);
    }

    /** @return list<array<string, mixed>> */
    public function openReports(): array
    {
        return $this->pdo->query(
            "SELECT r.*, p.thread_id, p.body, p.name, p.subject
             FROM reports r JOIN posts p ON p.id = r.post_id
             WHERE r.status = 'open' AND p.approved = 1 AND p.deleted = 0 ORDER BY r.created_at DESC"
        )->fetchAll();
    }

    public function reportPost(int $postId, string $reporterKey, string $reason): void
    {
        $this->immediate(function () use ($postId, $reporterKey, $reason): void {
            $this->enforceRateLimit('report', $reporterKey, 3600, 12);
            $post = $this->post($postId);
            if ($post === null || (int) $post['deleted'] === 1 || (int) $post['approved'] !== 1) {
                throw new HttpException(404, 'Post not found.');
            }
            try {
                $statement = $this->pdo->prepare(
                    "INSERT INTO reports (post_id, reporter_key, reason, status, created_at)
                     VALUES (:post_id, :reporter_key, :reason, 'open', :created_at)"
                );
                $statement->execute([
                    'post_id' => $postId,
                    'reporter_key' => $reporterKey,
                    'reason' => $reason,
                    'created_at' => time(),
                ]);
            } catch (PDOException $error) {
                if (str_contains($error->getMessage(), 'UNIQUE')) {
                    throw new HttpException(409, 'You already have an open report for this post.');
                }
                throw $error;
            }
        });
    }

    /** @return array{thread_id:int,old_original:?string,old_thumbnail:?string,image_changed:bool,public_changed:bool} */
    public function editPost(
        int $postId,
        string $name,
        string $subject,
        string $body,
        string $moderator,
        ?Upload $upload = null,
        bool $removeImage = false,
    ): array {
        if ($upload !== null && $removeImage) {
            throw new HttpException(400, 'Choose either remove image or upload a replacement, not both.');
        }

        return $this->immediate(function () use ($postId, $name, $subject, $body, $moderator, $upload, $removeImage): array {
            $post = $this->post($postId);
            if ($post === null || (int) $post['deleted'] === 1) {
                throw new HttpException(404, 'Post not found.');
            }
            if ((int) $post['is_op'] === 1 && (trim($subject) === '' || mb_strlen($subject) > 120)) {
                throw new HttpException(400, 'Opening posts require a subject of at most 120 characters.');
            }
            if ((int) $post['is_op'] === 0) {
                $subject = '';
            }

            $updates = ['name = :name', 'subject = :subject', 'body = :body', 'updated_at = :updated_at'];
            $parameters = [
                'name' => $name,
                'subject' => $subject,
                'body' => $body,
                'updated_at' => time(),
                'id' => $postId,
            ];
            $imageChanged = $upload !== null || $removeImage;
            if ($upload !== null) {
                $updates = array_merge($updates, [
                    'image_original_name = :image_original_name',
                    'image_stored_name = :image_stored_name',
                    'thumbnail_stored_name = :thumbnail_stored_name',
                    'image_mime = :image_mime',
                    'image_size = :image_size',
                    'image_width = :image_width',
                    'image_height = :image_height',
                ]);
                $parameters += [
                    'image_original_name' => $upload->originalName,
                    'image_stored_name' => $upload->storedName,
                    'thumbnail_stored_name' => $upload->thumbnailName,
                    'image_mime' => $upload->mimeType,
                    'image_size' => $upload->size,
                    'image_width' => $upload->width,
                    'image_height' => $upload->height,
                ];
            } elseif ($removeImage) {
                $updates = array_merge($updates, [
                    'image_original_name = NULL',
                    'image_stored_name = NULL',
                    'thumbnail_stored_name = NULL',
                    'image_mime = NULL',
                    'image_size = NULL',
                    'image_width = NULL',
                    'image_height = NULL',
                ]);
            }

            $statement = $this->pdo->prepare('UPDATE posts SET ' . implode(', ', $updates) . ' WHERE id = :id');
            $statement->execute($parameters);
            $this->audit($moderator, 'edit_post', $postId, [
                'before' => [
                    'name' => $post['name'],
                    'subject' => $post['subject'],
                    'body' => $post['body'],
                    'image_stored_name' => $post['image_stored_name'],
                    'thumbnail_stored_name' => $post['thumbnail_stored_name'],
                ],
                'image_changed' => $imageChanged,
            ]);
            $publicChanged = (int) $post['approved'] === 1;
            if ($publicChanged) {
                $this->touchRevision();
            }

            return [
                'thread_id' => (int) $post['thread_id'],
                'old_original' => is_string($post['image_stored_name']) ? $post['image_stored_name'] : null,
                'old_thumbnail' => is_string($post['thumbnail_stored_name']) ? $post['thumbnail_stored_name'] : null,
                'image_changed' => $imageChanged,
                'public_changed' => $publicChanged,
            ];
        });
    }

    /** @return array{thread_id:int,original:?string,thumbnail:?string} */
    public function softDelete(int $postId, string $moderator): array
    {
        return $this->immediate(function () use ($postId, $moderator): array {
            $post = $this->post($postId);
            if ($post === null || (int) $post['deleted'] === 1 || (int) $post['approved'] !== 1) {
                throw new HttpException(404, 'Post not found.');
            }
            $threadId = (int) $post['thread_id'];
            if ((int) $post['is_op'] === 1) {
                $statement = $this->pdo->prepare('UPDATE posts SET deleted = 1, updated_at = :now WHERE thread_id = :thread_id');
                $statement->execute(['now' => time(), 'thread_id' => $threadId]);
                $report = $this->pdo->prepare("UPDATE reports SET status = 'resolved', resolved_at = :now, resolved_by = :moderator WHERE post_id IN (SELECT id FROM posts WHERE thread_id = :thread_id) AND status = 'open'");
                $report->execute(['now' => time(), 'moderator' => $moderator, 'thread_id' => $threadId]);
            } else {
                $statement = $this->pdo->prepare('UPDATE posts SET deleted = 1, updated_at = :now WHERE id = :id');
                $statement->execute(['now' => time(), 'id' => $postId]);
                $report = $this->pdo->prepare("UPDATE reports SET status = 'resolved', resolved_at = :now, resolved_by = :moderator WHERE post_id = :post_id AND status = 'open'");
                $report->execute(['now' => time(), 'moderator' => $moderator, 'post_id' => $postId]);
            }
            $this->audit($moderator, 'delete_post', $postId, ['thread_id' => $threadId]);
            $this->touchRevision();

            return [
                'thread_id' => $threadId,
                'original' => is_string($post['image_stored_name']) ? $post['image_stored_name'] : null,
                'thumbnail' => is_string($post['thumbnail_stored_name']) ? $post['thumbnail_stored_name'] : null,
            ];
        });
    }

    public function toggleThread(int $threadId, string $flag, string $moderator): bool
    {
        if (!in_array($flag, ['sticky', 'locked'], true)) {
            throw new HttpException(400, 'Invalid thread flag.');
        }

        return $this->immediate(function () use ($threadId, $flag, $moderator): bool {
            $post = $this->post($threadId);
            if ($post === null || (int) $post['is_op'] !== 1 || (int) $post['deleted'] === 1 || (int) $post['approved'] !== 1) {
                throw new HttpException(404, 'Thread not found.');
            }
            $value = (int) $post[$flag] === 1 ? 0 : 1;
            $statement = $this->pdo->prepare("UPDATE posts SET {$flag} = :value, updated_at = :now WHERE id = :id");
            $statement->execute(['value' => $value, 'now' => time(), 'id' => $threadId]);
            $this->audit($moderator, 'toggle_' . $flag, $threadId, ['value' => $value]);
            $this->touchRevision();

            return $value === 1;
        });
    }

    public function resolveReport(int $reportId, string $moderator): void
    {
        $this->immediate(function () use ($reportId, $moderator): void {
            $statement = $this->pdo->prepare(
                "UPDATE reports SET status = 'resolved', resolved_at = :now, resolved_by = :moderator
                 WHERE id = :id AND status = 'open'"
            );
            $statement->execute(['now' => time(), 'moderator' => $moderator, 'id' => $reportId]);
            if ($statement->rowCount() !== 1) {
                throw new HttpException(404, 'Open report not found.');
            }
            $this->audit($moderator, 'resolve_report', null, ['report_id' => $reportId]);
        });
    }

    private function installSchema(): void
    {
        $schema = file_get_contents($this->config->root . DIRECTORY_SEPARATOR . 'database' . DIRECTORY_SEPARATOR . 'board-schema.sql');
        if ($schema === false) {
            throw new RuntimeException('Board database schema is missing.');
        }
        $this->pdo->exec($schema);
        $version = (string) $this->pdo->query(
            "SELECT value FROM app_meta WHERE key = 'schema_version'"
        )->fetchColumn();
        if ($version === '1') {
            $columns = $this->pdo->query('PRAGMA table_info(posts)')->fetchAll();
            $hasApproved = false;
            foreach ($columns as $column) {
                if (($column['name'] ?? null) === 'approved') {
                    $hasApproved = true;
                    break;
                }
            }
            $this->pdo->exec('BEGIN IMMEDIATE');
            try {
                if (!$hasApproved) {
                    $this->pdo->exec(
                        'ALTER TABLE posts ADD COLUMN approved INTEGER NOT NULL DEFAULT 1 CHECK (approved IN (0, 1))'
                    );
                }
                $this->pdo->exec(
                    "UPDATE app_meta SET value = '2' WHERE key = 'schema_version' AND value = '1'"
                );
                $this->pdo->exec('COMMIT');
            } catch (Throwable $error) {
                if ($this->pdo->inTransaction()) {
                    $this->pdo->exec('ROLLBACK');
                }
                throw $error;
            }
            $version = '2';
        }
        if ($version === '2') {
            $this->pdo->exec('BEGIN IMMEDIATE');
            try {
                $this->pdo->exec('DROP INDEX IF EXISTS idx_rate_lookup');
                $this->pdo->exec('DROP INDEX IF EXISTS idx_reports_one_open_per_reporter');
                $this->pdo->exec('DELETE FROM rate_events');
                $this->pdo->exec('ALTER TABLE rate_events RENAME COLUMN client_hash TO rate_key');
                $this->pdo->exec('ALTER TABLE reports RENAME COLUMN reporter_hash TO reporter_key');
                $this->pdo->exec('UPDATE reports SET reporter_key = lower(hex(randomblob(32)))');
                $this->pdo->exec(
                    "UPDATE app_meta SET value = '3' WHERE key = 'schema_version' AND value = '2'"
                );
                $this->pdo->exec('COMMIT');
            } catch (Throwable $error) {
                if ($this->pdo->inTransaction()) {
                    $this->pdo->exec('ROLLBACK');
                }
                throw $error;
            }
            $version = '3';
        }
        if ($version !== '3') {
            throw new RuntimeException('Unsupported board database schema version.');
        }

        $settings = $this->pdo->prepare(
            'INSERT INTO board_settings (singleton, posting_mode, posting_password_hash)
             VALUES (1, :posting_mode, NULL) ON CONFLICT(singleton) DO NOTHING'
        );
        $settings->execute(['posting_mode' => $this->board->postingMode]);
        $this->pdo->exec(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_reports_one_open_per_reporter
             ON reports(post_id, reporter_key) WHERE status = 'open'"
        );
        $this->pdo->exec(
            'CREATE INDEX IF NOT EXISTS idx_rate_lookup
             ON rate_events(rate_key, action, created_at DESC)'
        );
        $this->pdo->exec(
            'CREATE INDEX IF NOT EXISTS idx_posts_public_threads
             ON posts(thread_id, approved, deleted, id)'
        );
        $this->pdo->exec(
            'CREATE INDEX IF NOT EXISTS idx_posts_public_thread_order
             ON posts(sticky DESC, last_activity_at DESC, id DESC)
             WHERE is_op = 1 AND approved = 1 AND deleted = 0'
        );
        $this->pdo->exec(
            'CREATE INDEX IF NOT EXISTS idx_posts_pending
             ON posts(created_at ASC, id ASC) WHERE approved = 0 AND deleted = 0'
        );
        $this->pdo->exec(
            "CREATE TRIGGER IF NOT EXISTS trg_validate_approved_reply_insert
             BEFORE INSERT ON posts
             WHEN NEW.is_op = 0
             BEGIN
                 SELECT CASE WHEN NOT EXISTS (
                     SELECT 1 FROM posts op
                     WHERE op.id = NEW.thread_id AND op.is_op = 1
                       AND op.approved = 1 AND op.deleted = 0
                 ) THEN RAISE(ABORT, 'reply parent must be an approved active opening post') END;
             END"
        );
    }
    private function enforceRateLimit(string $action, string $rateKey, int $window, int $maximum): void
    {
        $cutoff = time() - $window;
        $delete = $this->pdo->prepare('DELETE FROM rate_events WHERE created_at < :cutoff');
        $delete->execute(['cutoff' => $cutoff - 86400]);
        $count = $this->pdo->prepare(
            'SELECT COUNT(*) FROM rate_events WHERE action = :action AND rate_key = :rate_key AND created_at >= :cutoff'
        );
        $count->execute(['action' => $action, 'rate_key' => $rateKey, 'cutoff' => $cutoff]);
        if ((int) $count->fetchColumn() >= $maximum) {
            throw new RateLimitException('Please slow down and try again later.');
        }
        $insert = $this->pdo->prepare('INSERT INTO rate_events (action, rate_key, created_at) VALUES (:action, :rate_key, :created_at)');
        $insert->execute(['action' => $action, 'rate_key' => $rateKey, 'created_at' => time()]);
    }

    private function touchRevision(): void
    {
        $this->pdo->exec('UPDATE board_state SET revision = revision + 1 WHERE singleton = 1');
    }

    /** @param array<string, mixed> $details */
    private function audit(string $moderator, string $action, ?int $postId, array $details): void
    {
        $statement = $this->pdo->prepare(
            'INSERT INTO moderation_audit (moderator, action, post_id, details_json, created_at)
             VALUES (:moderator, :action, :post_id, :details_json, :created_at)'
        );
        $statement->execute([
            'moderator' => $moderator,
            'action' => $action,
            'post_id' => $postId,
            'details_json' => json_encode($details, JSON_THROW_ON_ERROR),
            'created_at' => time(),
        ]);
    }

    /** @template T @param callable():T $callback @return T */
    private function immediate(callable $callback): mixed
    {
        $this->pdo->exec('BEGIN IMMEDIATE');
        try {
            $result = $callback();
            $this->pdo->exec('COMMIT');

            return $result;
        } catch (Throwable $error) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->exec('ROLLBACK');
            }
            throw $error;
        }
    }
}
