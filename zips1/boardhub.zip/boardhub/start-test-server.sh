#!/usr/bin/env sh

set -u
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

PHP_BIN="${PHP_BIN:-php}"
HOST="${BOARDHUB_TEST_HOST:-127.0.0.1}"
PORT="${BOARDHUB_TEST_PORT:-8080}"
SITE_URL="http://$HOST:$PORT/"

printf '\n============================================================\n'
printf '  BoardHub Experimental - Local Test Server\n'
printf '============================================================\n\n'

if ! command -v "$PHP_BIN" >/dev/null 2>&1; then
    printf 'ERROR: PHP was not found. Install PHP 8.5 or set PHP_BIN.\n' >&2
    exit 1
fi
if [ ! -f "boardhub.php" ] || [ ! -f "router.php" ]; then
    printf 'ERROR: The web-root application files are missing.\n' >&2
    exit 1
fi

found_board=0
for directory in *; do
    if [ -f "$directory/.board/board.sqlite3" ]; then
        found_board=1
        break
    fi
done

if [ "$found_board" -ne 1 ]; then
    printf 'No boards exist yet. This is valid after first-moderator setup.\n'
    printf 'Log in at /mod, then use Boards -> Create board.\n\n'
fi

printf 'Preparing the static pages...\n'
"$PHP_BIN" tools/rebuild.php || exit 1

if [ "${1:-}" = "--check" ]; then
    printf '\nStartup checks passed.\n'
    exit 0
fi

printf '\nOpen this address in your browser:\n\n  %s\n\n' "$SITE_URL"
printf 'Useful addresses:\n'
printf '  Home:             %s\n' "$SITE_URL"
printf '  Latest activity:  %sall/\n' "$SITE_URL"
printf '  Moderator login:  %smod\n' "$SITE_URL"
printf '  Board manager:    %smod/boards\n' "$SITE_URL"
printf 'Configured boards:\n'
if [ "$found_board" -eq 1 ]; then
    for directory in *; do
        if [ -f "$directory/.board/board.sqlite3" ]; then
            printf '  %s%s/\n' "$SITE_URL" "$(basename "$directory")"
        fi
    done
else
    printf '  none yet - create the first one from the moderator Board manager\n'
fi

printf '\nKeep this terminal open while testing. Press Ctrl+C to stop.\n\n'
exec "$PHP_BIN" -S "$HOST:$PORT" -t . router.php
