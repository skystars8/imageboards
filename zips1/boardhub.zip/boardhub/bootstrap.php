<?php

declare(strict_types=1);

use BoardHub\Config;

define('BOARDHUB_ROOT', __DIR__);

spl_autoload_register(static function (string $class): void {
    $prefix = 'BoardHub\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $path = BOARDHUB_ROOT . '/src/' . str_replace('\\', '/', $relative) . '.php';
    if (is_file($path)) {
        require $path;
    }
});

return Config::load(BOARDHUB_ROOT);

