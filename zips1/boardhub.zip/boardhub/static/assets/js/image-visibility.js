const imagePreferenceKey = 'chessboard.images';

const readPreference = () => {
    try {
        return localStorage.getItem(imagePreferenceKey);
    } catch {
        return null;
    }
};

const storePreference = (value) => {
    try {
        localStorage.setItem(imagePreferenceKey, value);
    } catch {
        // The setting still applies to the current page.
    }
};

export const initializeImageVisibility = () => {
    const controls = Array.from(document.querySelectorAll('[data-image-visibility-toggle]'))
        .filter((control) => control instanceof HTMLButtonElement);
    if (controls.length === 0) {
        return;
    }

    const attachments = document.querySelectorAll('.attachment, .archive-card__image');
    if (attachments.length === 0) {
        return;
    }
    controls.forEach((control) => {
        control.hidden = false;
    });

    const statusRegions = document.querySelectorAll('[data-image-visibility-status]');
    let imagesHidden = readPreference() === 'hidden';

    const applyVisibility = (announce = false) => {
        document.documentElement.dataset.images = imagesHidden ? 'hidden' : 'shown';
        controls.forEach((control) => {
            control.textContent = imagesHidden ? 'Show images' : 'Hide images';
            control.setAttribute('aria-pressed', imagesHidden ? 'true' : 'false');
        });
        if (announce) {
            statusRegions.forEach((region) => {
                region.textContent = imagesHidden ? 'All post images are hidden.' : 'Post images are visible.';
            });
        }
        storePreference(imagesHidden ? 'hidden' : 'shown');
        document.dispatchEvent(new CustomEvent('boardhub:image-visibility-changed', {
            detail: { hidden: imagesHidden },
        }));
    };

    applyVisibility();
    controls.forEach((control) => {
        control.addEventListener('click', () => {
            imagesHidden = !imagesHidden;
            if (imagesHidden) {
                document.dispatchEvent(new CustomEvent('boardhub:collapse-images'));
            }
            applyVisibility(true);
        });
    });
};
