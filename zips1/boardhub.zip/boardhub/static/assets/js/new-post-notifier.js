const manifestThread = (value) => (
    value && Number.isInteger(value.id) && value.id > 0
        && Number.isInteger(value.last_post_id) && value.last_post_id >= value.id
        && Number.isInteger(value.post_count) && value.post_count > 0
);

export const initializeNewPostNotifier = () => {
    const tools = document.querySelector('[data-board-tools][data-board]');
    if (!(tools instanceof HTMLElement)) return;
    const board = tools.dataset.board ?? '';
    if (!/^[a-z0-9][a-z0-9-]{0,39}$/.test(board)) return;
    const pageThread = Number(tools.dataset.thread ?? 0);
    const visibleThreads = new Map();
    document.querySelectorAll('.post[data-thread][data-post]').forEach((post) => {
        if (!(post instanceof HTMLElement)) return;
        const thread = Number(post.dataset.thread);
        const postId = Number(post.dataset.post);
        if (Number.isInteger(thread) && Number.isInteger(postId)) {
            const current = visibleThreads.get(thread) ?? { lastPost: thread, postCount: 0 };
            current.lastPost = Math.max(current.lastPost, postId);
            current.postCount += 1;
            visibleThreads.set(thread, current);
        }
    });
    document.querySelectorAll('.post[data-is-op="true"][data-thread][data-post-count]').forEach((post) => {
        if (!(post instanceof HTMLElement)) return;
        const thread = Number(post.dataset.thread);
        const postCount = Number(post.dataset.postCount);
        const current = visibleThreads.get(thread);
        if (current && Number.isInteger(postCount) && postCount > 0) current.postCount = postCount;
    });
    if (pageThread > 0 && !visibleThreads.has(pageThread)) return;

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'text-button new-post-notice';
    button.hidden = true;
    button.addEventListener('click', () => window.location.reload());
    tools.append(button);
    const originalTitle = document.title;
    let unseen = 0;
    let checking = false;

    const check = async () => {
        if (checking || document.visibilityState === 'hidden') return;
        checking = true;
        try {
            const response = await fetch(
                '/' + encodeURIComponent(board) + '/updates.json?t=' + Date.now(),
                { cache: 'no-store', credentials: 'same-origin' },
            );
            if (!response.ok) return;
            const manifest = await response.json();
            if (!manifest || !Array.isArray(manifest.threads)) return;
            manifest.threads.filter(manifestThread).forEach((thread) => {
                if (!visibleThreads.has(thread.id)) return;
                const previous = visibleThreads.get(thread.id);
                if (previous && thread.post_count > previous.postCount) {
                    unseen += thread.post_count - previous.postCount;
                    previous.postCount = thread.post_count;
                    previous.lastPost = thread.last_post_id;
                }
            });
            if (unseen > 0) {
                button.hidden = false;
                button.textContent = unseen + ' new post' + (unseen === 1 ? '' : 's') + ' — reload';
                document.title = '(' + unseen + ') ' + originalTitle;
            }
        } catch {
            // Static pages remain fully usable while an update check is unavailable.
        } finally {
            checking = false;
        }
    };

    const interval = window.setInterval(check, 60_000);
    window.setTimeout(check, 15_000);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') check();
    });
    window.addEventListener('pagehide', () => window.clearInterval(interval), { once: true });
};
