const connection = navigator.connection;

export const initializeImageHover = () => {
    if (!window.matchMedia('(hover: hover) and (pointer: fine)').matches
        || (connection && connection.saveData === true)) {
        return;
    }
    const links = Array.from(document.querySelectorAll('.attachment__toggle[href]'))
        .filter((link) => link instanceof HTMLAnchorElement);
    if (links.length === 0) return;

    const preview = document.createElement('div');
    preview.className = 'image-hover-preview';
    preview.hidden = true;
    const image = document.createElement('img');
    image.alt = '';
    preview.append(image);
    document.body.append(preview);

    let timer = 0;
    const position = (event) => {
        const left = Math.min(event.clientX + 18, window.innerWidth - 340);
        const top = Math.min(event.clientY + 18, window.innerHeight - 340);
        preview.style.left = Math.max(8, left) + 'px';
        preview.style.top = Math.max(8, top) + 'px';
    };
    const close = () => {
        window.clearTimeout(timer);
        preview.hidden = true;
        image.removeAttribute('src');
    };

    links.forEach((link) => {
        link.addEventListener('pointerenter', (event) => {
            if (link.getAttribute('aria-expanded') === 'true') return;
            let url;
            try {
                url = new URL(link.href, document.baseURI);
            } catch {
                return;
            }
            if (url.origin !== window.location.origin) return;
            position(event);
            timer = window.setTimeout(() => {
                image.src = url.href;
                preview.hidden = false;
            }, 350);
        });
        link.addEventListener('pointermove', position);
        link.addEventListener('pointerleave', close);
        link.addEventListener('pointerdown', close);
    });
    window.addEventListener('pagehide', close, { once: true });
};
