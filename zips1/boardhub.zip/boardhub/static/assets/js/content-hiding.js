const storageKey = 'boardhub.contentHiding.v1';
const validKey = /^[a-z0-9][a-z0-9-]{0,39}:(?:post|thread):[1-9][0-9]*$/;

const cleanList = (value, maximum, length) => (
    Array.isArray(value)
        ? value.filter((item) => typeof item === 'string' && item.length > 0 && item.length <= length)
            .filter((item, index, list) => list.indexOf(item) === index)
            .slice(0, maximum)
        : []
);

const readState = () => {
    try {
        const value = JSON.parse(localStorage.getItem(storageKey) ?? '{}');
        if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new TypeError();
        return {
            posts: cleanList(value.posts, 500, 80).filter((key) => validKey.test(key)),
            threads: cleanList(value.threads, 500, 80).filter((key) => validKey.test(key)),
            names: cleanList(value.names, 50, 80).map((name) => name.toLocaleLowerCase()),
            phrases: cleanList(value.phrases, 50, 120).map((phrase) => phrase.toLocaleLowerCase()),
        };
    } catch {
        return { posts: [], threads: [], names: [], phrases: [] };
    }
};

const writeState = (state) => {
    try {
        localStorage.setItem(storageKey, JSON.stringify(state));
    } catch {
        // The current page can still be changed.
    }
};

const splitRules = (value, maximumLength) => (
    value.split(/[\r\n,]+/)
        .map((item) => item.trim().toLocaleLowerCase().slice(0, maximumLength))
        .filter(Boolean)
        .filter((item, index, list) => list.indexOf(item) === index)
        .slice(0, 50)
);

export const initializeContentHiding = () => {
    const state = readState();
    const revealed = new Set();
    const posts = Array.from(document.querySelectorAll('.post[data-board][data-thread][data-post]'))
        .filter((post) => post instanceof HTMLElement);

    const panelHost = document.querySelector('[data-enhancement-extras]');
    if (panelHost instanceof HTMLElement) {
        const section = document.createElement('section');
        section.className = 'enhancement-extra';
        const heading = document.createElement('h3');
        heading.textContent = 'Local mute rules';
        const namesLabel = document.createElement('label');
        namesLabel.textContent = 'Names (one per line)';
        const names = document.createElement('textarea');
        names.rows = 3;
        names.maxLength = 4050;
        names.value = state.names.join('\n');
        namesLabel.append(names);
        const phrasesLabel = document.createElement('label');
        phrasesLabel.textContent = 'Plain-text phrases (one per line)';
        const phrases = document.createElement('textarea');
        phrases.rows = 3;
        phrases.maxLength = 6050;
        phrases.value = state.phrases.join('\n');
        phrasesLabel.append(phrases);
        const hint = document.createElement('small');
        hint.textContent = 'Literal matching only; regular expressions and hidden identity fields are not used.';
        section.append(heading, namesLabel, phrasesLabel, hint);
        panelHost.append(section);
        const saveRules = () => {
            state.names = splitRules(names.value, 80);
            state.phrases = splitRules(phrases.value, 120);
            writeState(state);
        };
        names.addEventListener('change', saveRules);
        phrases.addEventListener('change', saveRules);
    }

    const hidePost = (post) => {
        const board = post.dataset.board ?? '';
        const thread = Number(post.dataset.thread);
        const postId = Number(post.dataset.post);
        const isOp = post.dataset.isOp === 'true';
        const threadWrapper = isOp ? post.closest('.thread-preview[id^="thread-"]') : null;
        const kind = threadWrapper instanceof HTMLElement ? 'thread' : 'post';
        const id = kind === 'thread' ? thread : postId;
        const key = board + ':' + kind + ':' + id;
        const explicit = (kind === 'thread' ? state.threads : state.posts).includes(key);
        const name = (post.dataset.postName ?? '').trim().toLocaleLowerCase();
        const text = (post.querySelector('.post__body')?.textContent ?? '').toLocaleLowerCase();
        const muted = state.names.includes(name)
            || state.phrases.some((phrase) => text.includes(phrase));
        if ((!explicit && !muted) || revealed.has(key)) return;

        const target = threadWrapper instanceof HTMLElement ? threadWrapper : post;
        if (target.dataset.contentHidden === 'true') return;
        target.dataset.contentHidden = 'true';
        target.hidden = true;

        const placeholder = document.createElement('div');
        placeholder.className = 'content-placeholder';
        const reason = document.createElement('span');
        reason.textContent = (kind === 'thread' ? 'Thread #' + id : 'Post #' + id)
            + (explicit ? ' hidden locally.' : ' hidden by a local mute rule.');
        const show = document.createElement('button');
        show.type = 'button';
        show.className = 'text-button';
        show.textContent = 'Show';
        show.addEventListener('click', () => {
            revealed.add(key);
            if (explicit) {
                const list = kind === 'thread' ? state.threads : state.posts;
                const index = list.indexOf(key);
                if (index >= 0) list.splice(index, 1);
                writeState(state);
            }
            target.hidden = false;
            delete target.dataset.contentHidden;
            placeholder.remove();
        });
        placeholder.append(reason, document.createTextNode(' '), show);
        target.insertAdjacentElement('beforebegin', placeholder);
    };

    posts.forEach((post) => {
        const board = post.dataset.board ?? '';
        const thread = Number(post.dataset.thread);
        const postId = Number(post.dataset.post);
        const threadWrapper = post.dataset.isOp === 'true'
            ? post.closest('.thread-preview[id^="thread-"]')
            : null;
        const kind = threadWrapper instanceof HTMLElement ? 'thread' : 'post';
        const id = kind === 'thread' ? thread : postId;
        const key = board + ':' + kind + ':' + id;
        const actions = post.querySelector('.post__actions');
        if (actions instanceof HTMLElement && validKey.test(key)) {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'text-button';
            button.textContent = kind === 'thread' ? 'Hide thread' : 'Hide post';
            button.addEventListener('click', () => {
                const list = kind === 'thread' ? state.threads : state.posts;
                if (!list.includes(key)) list.unshift(key);
                if (list.length > 500) list.length = 500;
                writeState(state);
                hidePost(post);
            });
            actions.append(button);
        }
        hidePost(post);
    });
};
