import { clearDraft, readDraft, writeDraft } from './draft-storage.js';

const field = (labelText, control) => {
    const label = document.createElement('label');
    const text = document.createElement('span');
    text.textContent = labelText;
    label.append(text, control);
    return label;
};

const hiddenInput = (name, value) => {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = name;
    input.value = String(value);
    return input;
};

export const initializeQuickReply = () => {
    const dialog = document.createElement('dialog');
    dialog.className = 'quick-reply';
    dialog.setAttribute('aria-labelledby', 'quick-reply-title');
    const header = document.createElement('header');
    const title = document.createElement('h2');
    title.id = 'quick-reply-title';
    title.textContent = 'Quick reply';
    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'text-button';
    close.textContent = '×';
    close.setAttribute('aria-label', 'Close quick reply');
    header.append(title, close);
    const status = document.createElement('p');
    status.className = 'quick-reply__status';
    status.setAttribute('aria-live', 'polite');
    const host = document.createElement('div');
    dialog.append(header, status, host);
    document.body.append(dialog);
    close.addEventListener('click', () => dialog.close());

    const open = async (board, thread) => {
        if (!dialog.open) dialog.showModal();
        status.textContent = 'Loading reply form…';
        host.replaceChildren();
        let data;
        try {
            const response = await fetch(
                '/quick-reply-data?board=' + encodeURIComponent(board) + '&thread=' + encodeURIComponent(thread),
                { credentials: 'same-origin', cache: 'no-store' },
            );
            if (!response.ok) throw new Error('Reply form unavailable');
            data = await response.json();
            if (!data || data.board !== board || data.thread !== thread || typeof data.csrf !== 'string') {
                throw new Error('Invalid reply form');
            }
        } catch {
            window.location.assign('/compose?board=' + encodeURIComponent(board) + '&thread=' + thread);
            return;
        }

        const form = document.createElement('form');
        form.className = 'stack-form quick-reply__form';
        form.method = 'post';
        form.action = '/post';
        form.enctype = 'multipart/form-data';
        form.dataset.quickReplyForm = 'true';
        form.append(
            hiddenInput('csrf', data.csrf),
            hiddenInput('board', board),
            hiddenInput('thread', thread),
        );
        const saved = readDraft(board, thread);
        const name = document.createElement('input');
        name.type = 'text';
        name.name = 'name';
        name.maxLength = 80;
        name.required = true;
        name.value = saved?.name || 'Anonymous';
        const body = document.createElement('textarea');
        body.name = 'body';
        body.maxLength = 100_000;
        body.rows = 7;
        body.required = true;
        body.value = saved?.body ?? '';
        form.append(field('Name', name), field('Comment', body));
        if (data.password_required === true) {
            const password = document.createElement('input');
            password.type = 'password';
            password.name = 'board_password';
            password.maxLength = 128;
            password.required = true;
            password.autocomplete = 'off';
            form.append(field('Board password', password));
        }
        const image = document.createElement('input');
        image.type = 'file';
        image.name = 'image';
        image.accept = 'image/jpeg,image/png,image/gif,image/webp';
        form.append(field('Image', image));
        const draftStatus = document.createElement('p');
        draftStatus.className = 'post-form__status';
        draftStatus.dataset.draftStatus = '';
        draftStatus.setAttribute('aria-live', 'polite');
        const submit = document.createElement('button');
        submit.type = 'submit';
        submit.className = 'button';
        submit.textContent = 'Post reply';
        form.append(draftStatus, submit);
        form.addEventListener('input', () => {
            writeDraft(board, thread, { name: name.value, subject: '', body: body.value });
        });
        form.addEventListener('submit', () => clearDraft(board, thread));
        host.append(form);
        status.textContent = '';
        document.dispatchEvent(new CustomEvent('boardhub:form-ready', { detail: { form } }));
        body.focus();
        body.setSelectionRange(body.value.length, body.value.length);
    };

    document.addEventListener('boardhub:quick-reply-request', (event) => {
        const board = event.detail?.board;
        const thread = event.detail?.thread;
        if (typeof board !== 'string' || !Number.isInteger(thread)) return;
        event.preventDefault();
        open(board, thread);
    });

    const added = new Set();
    document.querySelectorAll('.post[data-is-op="true"][data-board][data-thread]').forEach((post) => {
        if (!(post instanceof HTMLElement)
            || post.closest('.thread-preview')?.querySelector('.post__status-icon--locked')
            || document.querySelector('.reply-mode--locked')) return;
        const board = post.dataset.board ?? '';
        const thread = Number(post.dataset.thread);
        const key = board + ':' + thread;
        if (!board || !Number.isInteger(thread) || added.has(key)) return;
        const actions = post.querySelector('.post__actions');
        if (!(actions instanceof HTMLElement)) return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'text-button';
        button.textContent = 'Quick reply';
        button.addEventListener('click', () => open(board, thread));
        actions.append(button);
        added.add(key);
    });
};
