/* In-page quote context: safe backlinks and target highlighting, with no fetches. */
const activeReferenceCounts = new WeakMap();

const setReferenced = (post, active) => {
    const current = activeReferenceCounts.get(post) ?? 0;
    const next = Math.max(0, current + (active ? 1 : -1));
    activeReferenceCounts.set(post, next);
    post.classList.toggle('post--referenced', next > 0);
};

const bindHighlight = (link, target) => {
    let pointerActive = false;
    let focusActive = false;
    let active = false;
    const update = () => {
        const next = pointerActive || focusActive;
        if (next === active) {
            return;
        }
        active = next;
        setReferenced(target, active);
    };

    link.addEventListener('pointerenter', () => {
        pointerActive = true;
        update();
    });
    link.addEventListener('pointerleave', () => {
        pointerActive = false;
        update();
    });
    link.addEventListener('focus', () => {
        focusActive = true;
        update();
    });
    link.addEventListener('blur', () => {
        focusActive = false;
        update();
    });
};

const quotedPost = (link) => {
    const match = link.hash.match(/^#(p[1-9][0-9]*)$/);
    if (match === null) {
        return null;
    }
    let url;
    try {
        url = new URL(link.href, document.baseURI);
    } catch {
        return null;
    }
    const location = url.pathname.match(/^\/([a-z0-9][a-z0-9-]{0,39})\/thread\/([1-9][0-9]*)\/?$/);
    if (location === null) {
        return null;
    }

    const candidates = document.querySelectorAll('.post[id="' + match[1] + '"]');
    return Array.from(candidates).find((post) => (
        post instanceof HTMLElement
        && post.dataset.board === location[1]
        && post.dataset.thread === location[2]
    )) ?? null;
};

const backlinkContainer = (post) => {
    const existing = post.querySelector(':scope > .post__header > [data-quote-backlinks]');
    if (existing instanceof HTMLElement) {
        return existing;
    }
    const header = post.querySelector(':scope > .post__header');
    if (!(header instanceof HTMLElement)) {
        return null;
    }

    const container = document.createElement('span');
    container.className = 'post__backlinks';
    container.dataset.quoteBacklinks = '';
    container.setAttribute('aria-label', 'Replies quoting this post');
    container.append(document.createTextNode(' Replies: '));
    header.append(container);
    return container;
};

export const initializeQuoteLinks = () => {
    const links = Array.from(document.querySelectorAll('.post__body a.quote-link'))
        .filter((link) => link instanceof HTMLAnchorElement);
    const added = new Set();

    links.forEach((link) => {
        const source = link.closest('.post[id]');
        const target = quotedPost(link);
        if (!(source instanceof HTMLElement) || target === null) {
            return;
        }
        bindHighlight(link, target);

        const key = [
            target.dataset.board,
            target.dataset.thread,
            target.id,
            source.dataset.board,
            source.dataset.thread,
            source.id,
        ].join(':');
        if (source === target || added.has(key)) {
            return;
        }
        const container = backlinkContainer(target);
        if (container === null) {
            return;
        }
        if (container.querySelector('a') !== null) {
            container.append(document.createTextNode(', '));
        }
        const backlink = document.createElement('a');
        const sourceBoard = source.dataset.board;
        const sourceThread = source.dataset.thread;
        backlink.href = sourceBoard && sourceThread
            ? '/' + encodeURIComponent(sourceBoard) + '/thread/' + encodeURIComponent(sourceThread) + '#' + source.id
            : '#' + source.id;
        backlink.textContent = '>>' + source.id.replace(/^p/, '');
        backlink.setAttribute('aria-label', 'Post ' + source.id.replace(/^p/, '') + ' quotes this post');
        container.append(backlink);
        bindHighlight(backlink, source);
        added.add(key);
    });
};
