import { appendToDraft, readDraft } from './draft-storage.js';

const selectedTextInside = (post) => {
    const selection = window.getSelection();
    const body = post.querySelector('.post__body');
    if (!selection || selection.isCollapsed || !(body instanceof HTMLElement)
        || !selection.anchorNode || !selection.focusNode
        || !body.contains(selection.anchorNode) || !body.contains(selection.focusNode)) {
        return '';
    }
    return selection.toString().trim().slice(0, 5_000);
};

export const initializeQuoteSelection = () => {
    const compose = document.querySelector('form[data-compose-form]');
    if (compose instanceof HTMLFormElement) {
        const board = compose.querySelector('input[name="board"]')?.value ?? '';
        const threadValue = compose.querySelector('input[name="thread"]')?.value;
        const thread = threadValue ? Number(threadValue) : null;
        const textarea = compose.querySelector('textarea[name="body"]');
        const draft = readDraft(board, thread);
        if (textarea instanceof HTMLTextAreaElement && textarea.value === '' && draft?.body) {
            textarea.value = draft.body;
        }
    }

    document.querySelectorAll('.post[data-board][data-thread][data-post]').forEach((post) => {
        if (!(post instanceof HTMLElement)) return;
        const scope = post.closest('.thread-preview') ?? document;
        if (scope.querySelector('.post__status-icon--locked') || document.querySelector('.reply-mode--locked')) return;
        const actions = post.querySelector('.post__actions');
        if (!(actions instanceof HTMLElement)) return;
        const board = post.dataset.board ?? '';
        const thread = Number(post.dataset.thread);
        const postId = Number(post.dataset.post);
        if (!board || !Number.isInteger(thread) || !Number.isInteger(postId)) return;

        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'text-button';
        button.textContent = 'Quote';
        button.addEventListener('click', () => {
            const selected = selectedTextInside(post);
            const quotedSelection = selected
                ? selected.split(/\r?\n/).map((line) => '> ' + line).join('\n') + '\n'
                : '';
            appendToDraft(board, thread, '>>' + postId + '\n' + quotedSelection);
            const request = new CustomEvent('boardhub:quick-reply-request', {
                cancelable: true,
                detail: { board, thread },
            });
            document.dispatchEvent(request);
            if (!request.defaultPrevented) {
                window.location.assign('/compose?board=' + encodeURIComponent(board) + '&thread=' + thread);
            }
        });
        actions.append(button);
    });
};
