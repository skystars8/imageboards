const storageKey = 'boardhub.enhancements.v1';

export const defaultFeaturePreferences = Object.freeze({
    preferences: true,
    'image-expansion': true,
    'image-visibility': true,
    'image-gallery': true,
    'image-hover': false,
    'post-menu-position': true,
    'local-time': true,
    'quote-links': true,
    'upload-preview': true,
    'upload-dropzone': true,
    'board-favorites': true,
    'thread-watchlist': true,
    'content-hiding': true,
    'locked-thread-filter': true,
    'thread-navigation': false,
    'compact-board-list': false,
    drafts: true,
    'quote-selection': true,
    'quick-reply': true,
    'new-post-notifier': false,
    'catalog-tools': true,
    'formatting-toolbar': true,
});

const knownFeatures = new Set(Object.keys(defaultFeaturePreferences));

const validatedFeatures = (value) => {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) {
        return {};
    }
    const result = {};
    for (const [feature, enabled] of Object.entries(value)) {
        if (knownFeatures.has(feature) && typeof enabled === 'boolean') {
            result[feature] = enabled;
        }
    }
    return result;
};

export const readFeaturePreferences = () => {
    try {
        const stored = JSON.parse(localStorage.getItem(storageKey) ?? 'null');
        if (stored === null || typeof stored !== 'object' || stored.version !== 1) {
            return {};
        }
        return validatedFeatures(stored.features);
    } catch {
        return {};
    }
};

export const writeFeaturePreferences = (features) => {
    const validated = validatedFeatures(features);
    try {
        localStorage.setItem(storageKey, JSON.stringify({ version: 1, features: validated }));
    } catch {
        // Preferences still apply after a reload when storage becomes available.
    }
    return validated;
};

export const resetFeaturePreferences = () => {
    try {
        localStorage.removeItem(storageKey);
    } catch {
        // The caller can still restore defaults for the current page.
    }
};

export const visitorFeatureEnabled = (feature) => {
    const stored = readFeaturePreferences();
    return typeof stored[feature] === 'boolean'
        ? stored[feature]
        : (defaultFeaturePreferences[feature] ?? true);
};

export const importFeaturePreferences = (value) => {
    if (value === null || typeof value !== 'object' || Array.isArray(value) || value.version !== 1) {
        throw new TypeError('This is not a BoardHub enhancement-settings file.');
    }
    return writeFeaturePreferences(value.features);
};

export const exportFeaturePreferences = () => ({
    version: 1,
    features: readFeaturePreferences(),
});
