/* Selected-image feedback that keeps the native file input and form submission. */
const previewableTypes = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

const formatBytes = (bytes) => {
    if (bytes >= 1_048_576) {
        return (bytes / 1_048_576).toFixed(1) + ' MB';
    }
    if (bytes >= 1_024) {
        return (bytes / 1_024).toFixed(1) + ' KB';
    }
    return bytes + ' B';
};

export const initializeUploadPreviews = () => {
    const objectUrls = new Set();

    const initializeInput = (input) => {
        if (!(input instanceof HTMLInputElement) || input.dataset.uploadPreview === 'true') {
            return;
        }
        input.dataset.uploadPreview = 'true';
        const preview = document.createElement('span');
        preview.className = 'upload-preview';
        preview.hidden = true;

        const image = document.createElement('img');
        image.className = 'upload-preview__image';
        image.alt = 'Selected image preview';
        image.hidden = true;

        const description = document.createElement('span');
        description.className = 'upload-preview__description';
        description.setAttribute('aria-live', 'polite');
        preview.append(image, description);
        input.insertAdjacentElement('afterend', preview);

        let objectUrl = null;
        const releaseObjectUrl = () => {
            if (objectUrl !== null) {
                URL.revokeObjectURL(objectUrl);
                objectUrls.delete(objectUrl);
                objectUrl = null;
            }
        };

        input.addEventListener('change', () => {
            releaseObjectUrl();
            image.removeAttribute('src');
            image.hidden = true;
            preview.hidden = true;
            description.textContent = '';

            const file = input.files?.item(0);
            if (!(file instanceof File)) {
                return;
            }
            description.textContent = file.name + ' · ' + formatBytes(file.size);
            preview.hidden = false;
            if (!previewableTypes.has(file.type)) {
                return;
            }

            objectUrl = URL.createObjectURL(file);
            objectUrls.add(objectUrl);
            image.src = objectUrl;
            image.hidden = false;
            image.addEventListener('load', () => {
                description.textContent = file.name + ' · ' + image.naturalWidth + '×'
                    + image.naturalHeight + ' · ' + formatBytes(file.size);
                releaseObjectUrl();
            }, { once: true });
            image.addEventListener('error', () => {
                image.hidden = true;
                releaseObjectUrl();
            }, { once: true });
        });
    };
    document.querySelectorAll('input[type="file"][name="image"]').forEach(initializeInput);
    document.addEventListener('boardhub:form-ready', (event) => {
        event.detail?.form?.querySelectorAll('input[type="file"][name="image"]').forEach(initializeInput);
    });

    window.addEventListener('pagehide', () => {
        objectUrls.forEach((url) => URL.revokeObjectURL(url));
        objectUrls.clear();
    }, { once: true });
};
