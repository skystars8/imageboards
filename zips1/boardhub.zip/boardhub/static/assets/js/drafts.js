import { clearDraft, readDraft, writeDraft } from './draft-storage.js';

const initializeFormDraft = (form) => {
    if (!(form instanceof HTMLFormElement) || form.dataset.draftsInitialized === 'true') return;
    const boardInput = form.querySelector('input[name="board"]');
    const threadInput = form.querySelector('input[name="thread"]');
    const name = form.querySelector('input[name="name"]');
    const subject = form.querySelector('input[name="subject"]');
    const body = form.querySelector('textarea[name="body"]');
    if (!(boardInput instanceof HTMLInputElement)
        || !(name instanceof HTMLInputElement)
        || !(body instanceof HTMLTextAreaElement)) return;
    form.dataset.draftsInitialized = 'true';
    const board = boardInput.value;
    const thread = threadInput instanceof HTMLInputElement ? Number(threadInput.value) : null;
    const saved = readDraft(board, thread);
    if (saved) {
        if (name.value === '' || name.value === 'Anonymous') name.value = saved.name;
        if (subject instanceof HTMLInputElement && subject.value === '') subject.value = saved.subject;
        if (body.value === '') body.value = saved.body;
    }

    const status = form.querySelector('[data-draft-status]');
    let timer = 0;
    const save = () => {
        window.clearTimeout(timer);
        timer = window.setTimeout(() => {
            writeDraft(board, thread, {
                name: name.value,
                subject: subject instanceof HTMLInputElement ? subject.value : '',
                body: body.value,
            });
            if (status instanceof HTMLElement) status.textContent = 'Draft saved for this browser session.';
        }, 350);
    };
    form.addEventListener('input', save);
    form.addEventListener('submit', () => {
        window.clearTimeout(timer);
        clearDraft(board, thread);
    });

    const discard = document.createElement('button');
    discard.type = 'button';
    discard.className = 'text-button draft-discard';
    discard.textContent = 'Discard saved draft';
    discard.addEventListener('click', () => {
        clearDraft(board, thread);
        body.value = '';
        if (subject instanceof HTMLInputElement) subject.value = '';
        if (status instanceof HTMLElement) status.textContent = 'Saved draft discarded.';
        body.focus();
    });
    if (status instanceof HTMLElement) status.insertAdjacentElement('afterend', discard);
};

export const initializeDrafts = () => {
    document.querySelectorAll('form[data-compose-form], form[data-quick-reply-form]').forEach(initializeFormDraft);
    document.addEventListener('boardhub:form-ready', (event) => {
        if (event.detail?.form instanceof HTMLFormElement) initializeFormDraft(event.detail.form);
    });
};
