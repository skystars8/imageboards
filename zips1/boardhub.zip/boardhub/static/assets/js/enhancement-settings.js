import {
    defaultFeaturePreferences,
    exportFeaturePreferences,
    importFeaturePreferences,
    readFeaturePreferences,
    resetFeaturePreferences,
    writeFeaturePreferences,
} from './feature-preferences.js';

export const initializeEnhancementSettings = () => {
    const dialog = document.querySelector('#enhancements-dialog');
    const openButton = document.querySelector('[data-enhancements-open]');
    const form = document.querySelector('[data-enhancements-form]');
    if (!(dialog instanceof HTMLDialogElement)
        || !(openButton instanceof HTMLButtonElement)
        || !(form instanceof HTMLFormElement)) {
        return;
    }

    const checkboxes = Array.from(form.querySelectorAll('[data-enhancement-feature]'))
        .filter((input) => input instanceof HTMLInputElement);
    const status = form.querySelector('[data-enhancements-status]');
    const announce = (message) => {
        if (status instanceof HTMLElement) {
            status.textContent = message;
        }
    };
    const populate = (stored = readFeaturePreferences()) => {
        checkboxes.forEach((checkbox) => {
            const feature = checkbox.value;
            checkbox.checked = typeof stored[feature] === 'boolean'
                ? stored[feature]
                : (defaultFeaturePreferences[feature] ?? true);
        });
    };

    populate();
    openButton.hidden = false;
    openButton.addEventListener('click', () => {
        populate();
        dialog.showModal();
    });
    form.querySelector('[data-enhancements-close]')?.addEventListener('click', () => dialog.close());

    form.addEventListener('submit', (event) => {
        event.preventDefault();
        const next = {};
        checkboxes.forEach((checkbox) => {
            next[checkbox.value] = checkbox.checked;
        });
        writeFeaturePreferences(next);
        window.location.reload();
    });

    form.querySelector('[data-enhancements-reset]')?.addEventListener('click', () => {
        resetFeaturePreferences();
        populate({});
        announce('Defaults restored. Apply to reload the page.');
    });

    form.querySelector('[data-enhancements-export]')?.addEventListener('click', () => {
        const blob = new Blob(
            [JSON.stringify(exportFeaturePreferences(), null, 2) + '\n'],
            { type: 'application/json' },
        );
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = 'boardhub-enhancements.json';
        link.click();
        URL.revokeObjectURL(url);
        announce('Enhancement settings exported.');
    });

    const importInput = form.querySelector('[data-enhancements-import]');
    if (importInput instanceof HTMLInputElement) {
        importInput.addEventListener('change', async () => {
            const file = importInput.files?.item(0);
            importInput.value = '';
            if (!(file instanceof File) || file.size > 65_536) {
                announce('Choose a BoardHub settings file smaller than 64 KB.');
                return;
            }
            try {
                const imported = importFeaturePreferences(JSON.parse(await file.text()));
                populate(imported);
                announce('Settings imported. Apply to reload the page.');
            } catch {
                announce('That file does not contain valid BoardHub enhancement settings.');
            }
        });
    }
};
