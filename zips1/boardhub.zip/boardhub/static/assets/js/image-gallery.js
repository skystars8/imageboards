const sameOriginImage = (href) => {
    try {
        const url = new URL(href, document.baseURI);
        return url.origin === window.location.origin && ['http:', 'https:'].includes(url.protocol)
            ? url.href
            : null;
    } catch {
        return null;
    }
};

export const initializeImageGallery = () => {
    const attachments = Array.from(document.querySelectorAll('.attachment__toggle[href]'))
        .filter((link) => link instanceof HTMLAnchorElement && sameOriginImage(link.href) !== null);
    if (attachments.length === 0) return;

    const dialog = document.createElement('dialog');
    dialog.className = 'image-gallery';
    dialog.setAttribute('aria-label', 'Image gallery');
    const toolbar = document.createElement('div');
    toolbar.className = 'image-gallery__toolbar';
    const previous = document.createElement('button');
    previous.type = 'button';
    previous.textContent = '← Previous';
    const counter = document.createElement('span');
    counter.setAttribute('aria-live', 'polite');
    const next = document.createElement('button');
    next.type = 'button';
    next.textContent = 'Next →';
    const close = document.createElement('button');
    close.type = 'button';
    close.textContent = 'Close';
    toolbar.append(previous, counter, next, close);
    const figure = document.createElement('figure');
    const image = document.createElement('img');
    image.alt = 'Gallery attachment';
    const caption = document.createElement('figcaption');
    const original = document.createElement('a');
    original.target = '_blank';
    original.rel = 'noopener';
    caption.append(original);
    figure.append(image, caption);
    dialog.append(toolbar, figure);
    document.body.append(dialog);

    let index = 0;
    const show = (nextIndex) => {
        index = (nextIndex + attachments.length) % attachments.length;
        const attachment = attachments[index];
        const source = sameOriginImage(attachment.href);
        if (source === null) return;
        image.src = source;
        image.alt = attachment.querySelector('img')?.alt ?? 'Gallery attachment';
        const filename = attachment.closest('.attachment')?.querySelector('figcaption a')?.textContent?.trim()
            || 'Open original';
        original.href = source;
        original.textContent = filename;
        counter.textContent = (index + 1) + ' of ' + attachments.length;
    };
    const open = (nextIndex = 0) => {
        show(nextIndex);
        dialog.showModal();
    };

    previous.addEventListener('click', () => show(index - 1));
    next.addEventListener('click', () => show(index + 1));
    close.addEventListener('click', () => dialog.close());
    dialog.addEventListener('click', (event) => {
        if (event.target === dialog) dialog.close();
    });
    dialog.addEventListener('keydown', (event) => {
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            show(index - 1);
        } else if (event.key === 'ArrowRight') {
            event.preventDefault();
            show(index + 1);
        }
    });
    dialog.addEventListener('close', () => image.removeAttribute('src'));

    const controls = document.querySelectorAll('[data-board-tools]');
    controls.forEach((tools) => {
        if (!(tools instanceof HTMLElement)) return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'text-button board-tools__gallery';
        button.textContent = 'Gallery (' + attachments.length + ')';
        button.addEventListener('click', () => open());
        tools.append(button);
    });
    attachments.forEach((attachment, attachmentIndex) => {
        attachment.closest('.attachment')?.querySelector('.attachment__original')?.insertAdjacentText('afterend', ' ');
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'text-button attachment__gallery';
        button.textContent = 'gallery';
        button.addEventListener('click', () => open(attachmentIndex));
        attachment.closest('.attachment')?.append(button);
    });
};
