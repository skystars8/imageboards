const prefix = 'boardhub.draft.v1:';
const validSlug = /^[a-z0-9][a-z0-9-]{0,39}$/;

const key = (board, thread) => {
    if (!validSlug.test(board)) return null;
    return prefix + board + ':' + (Number.isInteger(thread) && thread > 0 ? thread : 'new');
};

export const readDraft = (board, thread) => {
    const storageKey = key(board, thread);
    if (storageKey === null) return null;
    try {
        const value = JSON.parse(sessionStorage.getItem(storageKey) ?? 'null');
        if (value === null || typeof value !== 'object' || Array.isArray(value)) return null;
        return {
            name: typeof value.name === 'string' ? value.name.slice(0, 80) : 'Anonymous',
            subject: typeof value.subject === 'string' ? value.subject.slice(0, 120) : '',
            body: typeof value.body === 'string' ? value.body.slice(0, 100_000) : '',
        };
    } catch {
        return null;
    }
};

export const writeDraft = (board, thread, draft) => {
    const storageKey = key(board, thread);
    if (storageKey === null) return;
    const value = {
        name: typeof draft.name === 'string' ? draft.name.slice(0, 80) : 'Anonymous',
        subject: typeof draft.subject === 'string' ? draft.subject.slice(0, 120) : '',
        body: typeof draft.body === 'string' ? draft.body.slice(0, 100_000) : '',
    };
    try {
        sessionStorage.setItem(storageKey, JSON.stringify(value));
    } catch {
        // Draft saving is a convenience; posting remains native.
    }
};

export const appendToDraft = (board, thread, text) => {
    const current = readDraft(board, thread) ?? { name: 'Anonymous', subject: '', body: '' };
    const separator = current.body && !current.body.endsWith('\n') ? '\n' : '';
    current.body = (current.body + separator + text).slice(0, 100_000);
    writeDraft(board, thread, current);
    return current;
};

export const clearDraft = (board, thread) => {
    const storageKey = key(board, thread);
    if (storageKey === null) return;
    try {
        sessionStorage.removeItem(storageKey);
    } catch {
        // Nothing else is required.
    }
};
