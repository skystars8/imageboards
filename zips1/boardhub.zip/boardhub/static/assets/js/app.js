/*
 * Browser entry point. The server emits an allowlist on <html>; only enabled
 * modules are downloaded and initialized.
 */
import { visitorFeatureEnabled } from './feature-preferences.js';

const configuredFeatures = new Set(
    (document.documentElement.dataset.jsFeatures ?? '')
        .split(',')
        .map((feature) => feature.trim())
        .filter(Boolean),
);

const initializers = new Map([
    ['enhancement-settings', () => import('./enhancement-settings.js').then(({ initializeEnhancementSettings }) => initializeEnhancementSettings())],
    ['preferences', () => import('./preferences.js').then(({ initializePreferences }) => initializePreferences())],
    ['image-expansion', () => import('./image-previews.js').then(({ initializeImagePreviews }) => initializeImagePreviews())],
    ['image-visibility', () => import('./image-visibility.js').then(({ initializeImageVisibility }) => initializeImageVisibility())],
    ['image-gallery', () => import('./image-gallery.js').then(({ initializeImageGallery }) => initializeImageGallery())],
    ['image-hover', () => import('./image-hover.js').then(({ initializeImageHover }) => initializeImageHover())],
    ['post-menu-position', () => import('./post-menus.js').then(({ initializePostMenus }) => initializePostMenus())],
    ['moderator-helpers', () => import('./moderator.js').then(({ initializeModeratorForms }) => initializeModeratorForms())],
    ['local-time', () => import('./local-time.js').then(({ initializeLocalTime }) => initializeLocalTime())],
    ['quote-links', () => import('./quote-links.js').then(({ initializeQuoteLinks }) => initializeQuoteLinks())],
    ['upload-preview', () => import('./upload-preview.js').then(({ initializeUploadPreviews }) => initializeUploadPreviews())],
    ['upload-dropzone', () => import('./upload-dropzone.js').then(({ initializeUploadDropzones }) => initializeUploadDropzones())],
    ['board-favorites', () => import('./board-favorites.js').then(({ initializeBoardFavorites }) => initializeBoardFavorites())],
    ['thread-watchlist', () => import('./thread-watchlist.js').then(({ initializeThreadWatchlist }) => initializeThreadWatchlist())],
    ['content-hiding', () => import('./content-hiding.js').then(({ initializeContentHiding }) => initializeContentHiding())],
    ['locked-thread-filter', () => import('./locked-thread-filter.js').then(({ initializeLockedThreadFilter }) => initializeLockedThreadFilter())],
    ['compact-board-list', () => import('./compact-board-list.js').then(({ initializeCompactBoardList }) => initializeCompactBoardList())],
    ['thread-navigation', () => import('./thread-navigation.js').then(({ initializeThreadNavigation }) => initializeThreadNavigation())],
    ['catalog-tools', () => import('./catalog-tools.js').then(({ initializeCatalogTools }) => initializeCatalogTools())],
    ['drafts', () => import('./drafts.js').then(({ initializeDrafts }) => initializeDrafts())],
    ['quick-reply', () => import('./quick-reply.js').then(({ initializeQuickReply }) => initializeQuickReply())],
    ['quote-selection', () => import('./quote-selection.js').then(({ initializeQuoteSelection }) => initializeQuoteSelection())],
    ['formatting-toolbar', () => import('./formatting-toolbar.js').then(({ initializeFormattingToolbar }) => initializeFormattingToolbar())],
    ['new-post-notifier', () => import('./new-post-notifier.js').then(({ initializeNewPostNotifier }) => initializeNewPostNotifier())],
]);

const visitorSettingsAvailable = configuredFeatures.has('enhancement-settings');
const alwaysEnabled = new Set(['enhancement-settings', 'moderator-helpers']);

for (const [feature, initialize] of initializers) {
    if (!configuredFeatures.has(feature)) {
        continue;
    }
    if (visitorSettingsAvailable && !alwaysEnabled.has(feature) && !visitorFeatureEnabled(feature)) {
        document.querySelectorAll('[data-feature-control="' + feature + '"]').forEach((control) => {
            if (control instanceof HTMLElement) {
                control.hidden = true;
            }
        });
        continue;
    }
    initialize().catch((error) => {
        console.error('BoardHub could not initialize ' + feature + '.', error);
    });
}
