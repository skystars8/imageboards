const acceptedTypes = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

export const initializeUploadDropzones = () => {
    const initializeInput = (input) => {
        if (!(input instanceof HTMLInputElement) || input.dataset.uploadDropzone === 'true') return;
        input.dataset.uploadDropzone = 'true';
        const zone = document.createElement('span');
        zone.className = 'upload-dropzone';
        zone.tabIndex = 0;
        zone.setAttribute('role', 'button');
        zone.textContent = 'Drop an image here, paste while focused, or choose a file';

        const accept = (file) => {
            if (!(file instanceof File) || !acceptedTypes.has(file.type)) {
                zone.dataset.state = 'error';
                zone.textContent = 'Use a JPEG, PNG, GIF, or WebP image.';
                return;
            }
            try {
                const transfer = new DataTransfer();
                transfer.items.add(file);
                input.files = transfer.files;
                input.dispatchEvent(new Event('change', { bubbles: true }));
                zone.dataset.state = 'ready';
                zone.textContent = file.name + ' ready to upload';
            } catch {
                zone.dataset.state = 'error';
                zone.textContent = 'This browser cannot attach dropped files; use the file picker.';
            }
        };

        zone.addEventListener('click', () => input.click());
        zone.addEventListener('keydown', (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                input.click();
            }
        });
        for (const eventName of ['dragenter', 'dragover']) {
            zone.addEventListener(eventName, (event) => {
                event.preventDefault();
                if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
                zone.dataset.state = 'active';
            });
        }
        zone.addEventListener('dragleave', () => delete zone.dataset.state);
        zone.addEventListener('drop', (event) => {
            event.preventDefault();
            accept(event.dataTransfer?.files.item(0));
        });
        zone.addEventListener('paste', (event) => {
            const image = Array.from(event.clipboardData?.files ?? []).find((file) => acceptedTypes.has(file.type));
            if (image) {
                event.preventDefault();
                accept(image);
            }
        });
        input.addEventListener('change', () => {
            const file = input.files?.item(0);
            if (file) {
                zone.dataset.state = 'ready';
                zone.textContent = file.name + ' ready to upload';
            } else {
                delete zone.dataset.state;
                zone.textContent = 'Drop an image here, paste while focused, or choose a file';
            }
        });
        input.insertAdjacentElement('afterend', zone);
    };
    document.querySelectorAll('input[type="file"][name="image"]').forEach(initializeInput);
    document.addEventListener('boardhub:form-ready', (event) => {
        event.detail?.form?.querySelectorAll('input[type="file"][name="image"]').forEach(initializeInput);
    });
};
