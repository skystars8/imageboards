export const initializeCatalogTools = () => {
    const form = document.querySelector('[data-catalog-tools]');
    const grid = document.querySelector('[data-catalog-grid]');
    if (!(form instanceof HTMLFormElement) || !(grid instanceof HTMLElement)) return;
    const search = form.querySelector('[data-catalog-search]');
    const sort = form.querySelector('[data-catalog-sort]');
    const clear = form.querySelector('[data-catalog-clear]');
    const status = form.querySelector('[data-catalog-status]');
    if (!(search instanceof HTMLInputElement) || !(sort instanceof HTMLSelectElement)) return;

    const cards = Array.from(grid.querySelectorAll('[data-catalog-card]'))
        .filter((card) => card instanceof HTMLElement);
    const originalOrder = new Map(cards.map((card, index) => [card, index]));
    const numeric = (card, name) => Number(card.dataset[name] ?? 0);
    const apply = () => {
        const query = search.value.trim().toLocaleLowerCase();
        let visible = 0;
        cards.forEach((card) => {
            const match = query === '' || (card.textContent ?? '').toLocaleLowerCase().includes(query);
            card.hidden = !match;
            if (match) visible += 1;
        });
        const sorted = [...cards].sort((left, right) => {
            if (sort.value === 'newest') return numeric(right, 'created') - numeric(left, 'created');
            if (sort.value === 'replies') return numeric(right, 'replies') - numeric(left, 'replies');
            if (sort.value === 'images') return numeric(right, 'images') - numeric(left, 'images');
            const stickyDifference = numeric(right, 'sticky') - numeric(left, 'sticky');
            if (stickyDifference !== 0) return stickyDifference;
            const bumpDifference = numeric(right, 'bumped') - numeric(left, 'bumped');
            return bumpDifference || (originalOrder.get(left) ?? 0) - (originalOrder.get(right) ?? 0);
        });
        sorted.forEach((card) => grid.append(card));
        if (status instanceof HTMLElement) {
            status.textContent = visible + ' of ' + cards.length + ' threads';
        }
    };
    search.addEventListener('input', apply);
    sort.addEventListener('change', apply);
    clear?.addEventListener('click', () => {
        search.value = '';
        sort.value = 'bump';
        apply();
        search.focus();
    });
    form.hidden = false;
    apply();
};
