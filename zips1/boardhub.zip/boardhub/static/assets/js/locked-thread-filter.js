const storageKey = 'boardhub.lockedThreadFilter.v1';

const readPreferences = () => {
    try {
        const value = JSON.parse(localStorage.getItem(storageKey) ?? '{}');
        if (value === null || typeof value !== 'object' || Array.isArray(value)) return {};
        return Object.fromEntries(
            Object.entries(value).filter(([slug, hidden]) => (
                /^[a-z0-9][a-z0-9-]{0,39}$/.test(slug) && typeof hidden === 'boolean'
            )),
        );
    } catch {
        return {};
    }
};

export const initializeLockedThreadFilter = () => {
    const tools = document.querySelector('[data-board-tools][data-board]:not([data-thread])');
    if (!(tools instanceof HTMLElement)) return;
    const board = tools.dataset.board ?? '';
    const locked = Array.from(document.querySelectorAll('.thread-preview'))
        .filter((thread) => thread instanceof HTMLElement && thread.querySelector('.post__status-icon--locked'));
    if (locked.length === 0) return;

    const preferences = readPreferences();
    let hidden = preferences[board] === true;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'text-button board-tools__locked-toggle';

    const apply = () => {
        locked.forEach((thread) => thread.classList.toggle('thread-preview--locked-hidden', hidden));
        button.textContent = hidden ? 'Show locked threads (' + locked.length + ')' : 'Hide locked threads';
        button.setAttribute('aria-pressed', hidden ? 'true' : 'false');
    };
    button.addEventListener('click', () => {
        hidden = !hidden;
        preferences[board] = hidden;
        try {
            localStorage.setItem(storageKey, JSON.stringify(preferences));
        } catch {
            // The choice still applies on this page.
        }
        apply();
    });
    tools.append(button);
    apply();
};
