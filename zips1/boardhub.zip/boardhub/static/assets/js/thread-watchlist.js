const storageKey = 'boardhub.watchedThreads.v1';
const validSlug = /^[a-z0-9][a-z0-9-]{0,39}$/;

const readWatchlist = () => {
    try {
        const value = JSON.parse(localStorage.getItem(storageKey) ?? '[]');
        if (!Array.isArray(value)) return [];
        const seen = new Set();
        return value.filter((item) => {
            if (item === null || typeof item !== 'object'
                || typeof item.board !== 'string' || !validSlug.test(item.board)
                || !Number.isInteger(item.thread) || item.thread < 1) {
                return false;
            }
            const key = item.board + ':' + item.thread;
            if (seen.has(key)) return false;
            seen.add(key);
            item.subject = typeof item.subject === 'string' ? item.subject.slice(0, 120) : '';
            item.lastSeen = Number.isInteger(item.lastSeen) && item.lastSeen > 0 ? item.lastSeen : item.thread;
            item.lastKnown = Number.isInteger(item.lastKnown) && item.lastKnown > 0 ? item.lastKnown : item.lastSeen;
            item.seenCount = Number.isInteger(item.seenCount) && item.seenCount > 0 ? item.seenCount : 1;
            item.knownCount = Number.isInteger(item.knownCount) && item.knownCount >= item.seenCount
                ? item.knownCount
                : item.seenCount;
            return true;
        }).slice(0, 200);
    } catch {
        return [];
    }
};

const writeWatchlist = (items) => {
    try {
        localStorage.setItem(storageKey, JSON.stringify(items.slice(0, 200)));
    } catch {
        // Keep working for the current page.
    }
};

const itemKey = (board, thread) => board + ':' + thread;

export const initializeThreadWatchlist = () => {
    let items = readWatchlist();
    const buttons = new Map();
    const posts = Array.from(document.querySelectorAll('.post[data-is-op="true"][data-board][data-thread]'))
        .filter((post) => post instanceof HTMLElement);

    const currentThread = window.location.pathname.match(/^\/([a-z0-9][a-z0-9-]{0,39})\/thread\/([1-9][0-9]*)\/?$/);
    if (currentThread !== null) {
        const board = currentThread[1];
        const thread = Number(currentThread[2]);
        const lastPost = Math.max(
            thread,
            ...Array.from(document.querySelectorAll('.post[data-post]'))
                .map((post) => Number(post instanceof HTMLElement ? post.dataset.post : 0))
                .filter(Number.isInteger),
        );
        const postCount = document.querySelectorAll('.post[data-thread="' + thread + '"][data-post]').length;
        const watched = items.find((item) => item.board === board && item.thread === thread);
        if (watched) {
            watched.lastSeen = lastPost;
            watched.lastKnown = Math.max(watched.lastKnown, lastPost);
            watched.seenCount = postCount;
            watched.knownCount = Math.max(watched.knownCount, postCount);
            writeWatchlist(items);
        }
    }

    const panelHost = document.querySelector('[data-enhancement-extras]');
    let list = null;
    let panelStatus = null;
    if (panelHost instanceof HTMLElement) {
        const section = document.createElement('section');
        section.className = 'enhancement-extra';
        const heading = document.createElement('h3');
        heading.textContent = 'Watched threads';
        list = document.createElement('ul');
        list.className = 'watchlist';
        panelStatus = document.createElement('p');
        panelStatus.className = 'enhancements-status';
        panelStatus.setAttribute('aria-live', 'polite');
        const refresh = document.createElement('button');
        refresh.type = 'button';
        refresh.className = 'text-button';
        refresh.textContent = 'Check watched threads';
        section.append(heading, list, refresh, panelStatus);
        panelHost.append(section);

        refresh.addEventListener('click', async () => {
            refresh.disabled = true;
            panelStatus.textContent = 'Checking…';
            const boards = [...new Set(items.map((item) => item.board))].slice(0, 25);
            const manifests = new Map();
            await Promise.all(boards.map(async (board) => {
                try {
                    const response = await fetch('/' + encodeURIComponent(board) + '/updates.json', {
                        cache: 'no-store',
                        credentials: 'same-origin',
                    });
                    if (!response.ok) return;
                    const manifest = await response.json();
                    if (manifest && Array.isArray(manifest.threads)) {
                        manifests.set(board, manifest.threads);
                    }
                } catch {
                    // An unavailable board stays in the list.
                }
            }));
            items.forEach((item) => {
                const thread = manifests.get(item.board)?.find((entry) => (
                    entry && entry.id === item.thread && Number.isInteger(entry.last_post_id)
                        && Number.isInteger(entry.post_count)
                ));
                if (thread) {
                    item.lastKnown = Math.max(item.lastKnown, thread.last_post_id);
                    item.knownCount = Math.max(item.knownCount, thread.post_count);
                    item.locked = thread.locked === true;
                }
            });
            writeWatchlist(items);
            render();
            panelStatus.textContent = 'Watchlist checked.';
            refresh.disabled = false;
        });
    }

    const render = () => {
        buttons.forEach((button, key) => {
            const watched = items.some((item) => itemKey(item.board, item.thread) === key);
            button.textContent = watched ? 'Unwatch thread' : 'Watch thread';
            button.setAttribute('aria-pressed', watched ? 'true' : 'false');
        });
        if (!(list instanceof HTMLElement)) return;
        list.replaceChildren();
        if (items.length === 0) {
            const empty = document.createElement('li');
            empty.textContent = 'No watched threads.';
            list.append(empty);
            return;
        }
        items.forEach((item) => {
            const row = document.createElement('li');
            const link = document.createElement('a');
            link.href = '/' + encodeURIComponent(item.board) + '/thread/' + item.thread;
            link.textContent = '/' + item.board + '/ #' + item.thread
                + (item.subject ? ' — ' + item.subject : '');
            row.append(link);
            const unread = Math.max(0, item.knownCount - item.seenCount);
            if (unread > 0 || item.locked === true) {
                const state = document.createElement('small');
                state.textContent = (unread > 0 ? ' · ' + unread + ' new' : '') + (item.locked === true ? ' · locked' : '');
                row.append(state);
            }
            list.append(row);
        });
    };

    posts.forEach((post) => {
        const board = post.dataset.board ?? '';
        const thread = Number(post.dataset.thread);
        if (!validSlug.test(board) || !Number.isInteger(thread) || thread < 1) return;
        const actions = post.querySelector('.post__actions');
        if (!(actions instanceof HTMLElement)) return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'text-button';
        const key = itemKey(board, thread);
        buttons.set(key, button);
        button.addEventListener('click', () => {
            const existing = items.findIndex((item) => itemKey(item.board, item.thread) === key);
            if (existing >= 0) {
                items.splice(existing, 1);
            } else {
                const subject = post.querySelector('.post__subject')?.textContent?.trim() ?? '';
                const lastPost = Math.max(
                    thread,
                    ...Array.from(document.querySelectorAll('.post[data-thread="' + thread + '"][data-post]'))
                        .map((candidate) => Number(candidate instanceof HTMLElement ? candidate.dataset.post : 0))
                        .filter(Number.isInteger),
                );
                const exactCount = Number(post.dataset.postCount);
                const postCount = Number.isInteger(exactCount) && exactCount > 0
                    ? exactCount
                    : document.querySelectorAll('.post[data-thread="' + thread + '"][data-post]').length;
                items.unshift({
                    board,
                    thread,
                    subject: subject.slice(0, 120),
                    lastSeen: lastPost,
                    lastKnown: lastPost,
                    seenCount: postCount,
                    knownCount: postCount,
                });
            }
            writeWatchlist(items);
            render();
        });
        actions.append(button);
    });

    render();
};
