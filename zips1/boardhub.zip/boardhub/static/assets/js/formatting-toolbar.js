const formats = [
    ['Bold', "'''", "'''"],
    ['Italic', "''", "''"],
    ['Spoiler', '**', '**'],
    ['Underline', '__', '__'],
    ['Strike', '~~', '~~'],
    ['Code', '[code]', '[/code]'],
    ['Heading', '==', '=='],
];

const addToolbar = (textarea) => {
    if (!(textarea instanceof HTMLTextAreaElement) || textarea.dataset.formattingToolbar === 'true') return;
    textarea.dataset.formattingToolbar = 'true';
    const toolbar = document.createElement('div');
    toolbar.className = 'formatting-toolbar';
    toolbar.setAttribute('role', 'toolbar');
    toolbar.setAttribute('aria-label', 'Comment formatting');

    const wrap = (prefix, suffix) => {
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const selected = textarea.value.slice(start, end);
        const replacement = prefix + selected + suffix;
        textarea.setRangeText(replacement, start, end, 'select');
        textarea.selectionStart = start + prefix.length;
        textarea.selectionEnd = start + prefix.length + selected.length;
        textarea.dispatchEvent(new Event('input', { bubbles: true }));
        textarea.focus();
    };
    formats.forEach(([label, prefix, suffix]) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'text-button';
        button.textContent = label;
        button.title = prefix + 'text' + suffix;
        button.addEventListener('click', () => wrap(prefix, suffix));
        toolbar.append(button);
    });
    textarea.insertAdjacentElement('beforebegin', toolbar);

    textarea.addEventListener('keydown', (event) => {
        if (!event.ctrlKey || event.metaKey || event.altKey) return;
        const shortcuts = {
            b: formats[0],
            i: formats[1],
            u: formats[3],
        };
        const format = shortcuts[event.key.toLocaleLowerCase()];
        if (format) {
            event.preventDefault();
            wrap(format[1], format[2]);
        }
    });
};

export const initializeFormattingToolbar = () => {
    document.querySelectorAll('textarea[name="body"]').forEach(addToolbar);
    document.addEventListener('boardhub:form-ready', (event) => {
        event.detail?.form?.querySelectorAll('textarea[name="body"]').forEach(addToolbar);
    });
};
