export const initializeCompactBoardList = () => {
    document.documentElement.dataset.compactBoardList = 'true';
};
