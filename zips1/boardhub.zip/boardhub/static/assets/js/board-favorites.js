const storageKey = 'boardhub.favoriteBoards.v1';
const validSlug = /^[a-z0-9][a-z0-9-]{0,39}$/;

const readFavorites = () => {
    try {
        const value = JSON.parse(localStorage.getItem(storageKey) ?? '[]');
        return Array.isArray(value)
            ? value.filter((slug, index) => (
                typeof slug === 'string' && validSlug.test(slug) && value.indexOf(slug) === index
            )).slice(0, 100)
            : [];
    } catch {
        return [];
    }
};

const writeFavorites = (favorites) => {
    try {
        localStorage.setItem(storageKey, JSON.stringify(favorites.slice(0, 100)));
    } catch {
        // The current-page state still works.
    }
};

export const initializeBoardFavorites = () => {
    let favorites = readFavorites();
    const entries = Array.from(document.querySelectorAll('[data-board-entry]'))
        .filter((entry) => entry instanceof HTMLElement);

    const render = () => {
        const favoriteOrder = new Map(favorites.map((slug, index) => [slug, index]));
        entries.forEach((entry) => {
            const slug = entry.dataset.boardEntry ?? '';
            const favorite = favoriteOrder.has(slug);
            entry.classList.toggle('board-list__favorite', favorite);
            const link = entry.querySelector('[data-board-link]');
            if (link instanceof HTMLAnchorElement) {
                link.setAttribute('aria-label', (favorite ? 'Favorite board ' : 'Board ') + slug);
            }
        });
        document.querySelectorAll('[data-board-card]').forEach((card) => {
            if (card instanceof HTMLElement) {
                card.classList.toggle('board-card--favorite', favoriteOrder.has(card.dataset.boardCard ?? ''));
            }
        });

        if (entries.length > 1 && entries[0].parentNode !== null) {
            const parent = entries[0].parentNode;
            const originalOrder = new Map(entries.map((entry, index) => [entry, index]));
            const sorted = [...entries].sort((left, right) => {
                const leftFavorite = favoriteOrder.get(left.dataset.boardEntry ?? '');
                const rightFavorite = favoriteOrder.get(right.dataset.boardEntry ?? '');
                if (leftFavorite !== undefined || rightFavorite !== undefined) {
                    if (leftFavorite === undefined) return 1;
                    if (rightFavorite === undefined) return -1;
                    return leftFavorite - rightFavorite;
                }
                return (originalOrder.get(left) ?? 0) - (originalOrder.get(right) ?? 0);
            });
            const marker = document.createComment('favorite-board-order');
            parent.insertBefore(marker, entries[0]);
            sorted.forEach((entry) => parent.insertBefore(entry, marker));
            marker.remove();
        }
    };

    const tools = document.querySelector('[data-board-tools][data-board]');
    if (tools instanceof HTMLElement) {
        const slug = tools.dataset.board ?? '';
        if (validSlug.test(slug)) {
            const button = document.createElement('button');
            button.type = 'button';
            button.className = 'text-button board-tools__favorite';
            const updateButton = () => {
                const favorite = favorites.includes(slug);
                button.textContent = favorite ? '★ Favorite' : '☆ Favorite';
                button.setAttribute('aria-pressed', favorite ? 'true' : 'false');
            };
            button.addEventListener('click', () => {
                favorites = favorites.includes(slug)
                    ? favorites.filter((favorite) => favorite !== slug)
                    : [...favorites, slug];
                writeFavorites(favorites);
                updateButton();
                render();
            });
            tools.append(button);
            updateButton();
        }
    }

    render();
};
