/* Full-resolution image expansion with a thumbnail-preserving fallback. */
const expandedClass = 'attachment__toggle--expanded';
const thumbnailSources = new WeakMap();

const originalSource = (link) => {
    try {
        const url = new URL(link.href, document.baseURI);
        if (!['http:', 'https:'].includes(url.protocol) || url.origin !== window.location.origin) {
            return null;
        }
        return url.href;
    } catch {
        return null;
    }
};

const setExpanded = (link, expanded) => {
    const figure = link.closest('.attachment');
    const image = link.querySelector('img');
    if (!(figure instanceof HTMLElement) || !(image instanceof HTMLImageElement)) {
        return;
    }

    if (expanded) {
        if (!thumbnailSources.has(image)) {
            thumbnailSources.set(image, image.currentSrc || image.src);
        }
        const source = originalSource(link);
        if (source !== null && image.src !== source) {
            const thumbnail = thumbnailSources.get(image);
            image.addEventListener('error', () => {
                if (link.classList.contains(expandedClass) && thumbnail) {
                    image.src = thumbnail;
                }
            }, { once: true });
            image.src = source;
        }
    } else {
        const thumbnail = thumbnailSources.get(image);
        if (thumbnail) {
            image.src = thumbnail;
        }
    }

    link.classList.toggle(expandedClass, expanded);
    figure.classList.toggle('attachment--expanded', expanded);
    link.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    image.alt = expanded
        ? 'Expanded post attachment; click to reduce'
        : 'Post attachment; click to expand';
};

export function initializeImagePreviews() {
    const links = Array.from(document.querySelectorAll('[data-image-toggle]'))
        .filter((link) => link instanceof HTMLAnchorElement);
    const controls = Array.from(document.querySelectorAll('[data-image-expansion-toggle]'))
        .filter((control) => control instanceof HTMLButtonElement);
    if (links.length === 0) {
        return;
    }

    const updateControls = () => {
        const expandedCount = links.filter((link) => link.classList.contains(expandedClass)).length;
        const state = expandedCount === 0 ? 'false' : (expandedCount === links.length ? 'true' : 'mixed');
        controls.forEach((control) => {
            control.hidden = false;
            control.textContent = expandedCount === links.length ? 'Shrink images' : 'Expand images';
            control.setAttribute('aria-pressed', state);
            control.disabled = document.documentElement.dataset.images === 'hidden';
        });
    };

    document.addEventListener('click', (event) => {
        if (!(event.target instanceof Element)) {
            return;
        }
        const link = event.target.closest('[data-image-toggle]');
        if (!(link instanceof HTMLAnchorElement) || !links.includes(link)) {
            return;
        }
        if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) {
            return;
        }
        event.preventDefault();
        setExpanded(link, !link.classList.contains(expandedClass));
        updateControls();
    });

    controls.forEach((control) => {
        control.addEventListener('click', () => {
            const expand = !links.every((link) => link.classList.contains(expandedClass));
            links.forEach((link) => setExpanded(link, expand));
            updateControls();
        });
    });

    document.addEventListener('boardhub:collapse-images', () => {
        links.forEach((link) => setExpanded(link, false));
        updateControls();
    });
    document.addEventListener('boardhub:image-visibility-changed', updateControls);
    updateControls();
}
