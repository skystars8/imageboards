export const initializeModeratorForms = () => {
    document.querySelectorAll('.moderator-edit-form').forEach((form) => {
        if (!(form instanceof HTMLFormElement)) {
            return;
        }

        const fileInput = form.querySelector('input[type="file"][name="image"]');
        const removeInput = form.querySelector('input[type="checkbox"][name="remove_image"]');
        if (!(fileInput instanceof HTMLInputElement) || !(removeInput instanceof HTMLInputElement)) {
            return;
        }

        fileInput.addEventListener('change', () => {
            if (fileInput.files && fileInput.files.length > 0) {
                removeInput.checked = false;
            }
        });

        removeInput.addEventListener('change', () => {
            if (removeInput.checked) {
                fileInput.value = '';
            }
        });
    });

    document.querySelectorAll('form[data-confirm]').forEach((form) => {
        if (!(form instanceof HTMLFormElement)) {
            return;
        }
        form.addEventListener('submit', (event) => {
            const message = form.dataset.confirm;
            if (message && !window.confirm(message)) {
                event.preventDefault();
            }
        });
    });
};
