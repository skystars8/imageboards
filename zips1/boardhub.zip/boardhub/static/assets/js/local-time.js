/* Local, relative post times without a date-formatting dependency. */
const relativeFormatter = new Intl.RelativeTimeFormat(undefined, { numeric: 'auto' });
const localFormatter = new Intl.DateTimeFormat(undefined, {
    dateStyle: 'medium',
    timeStyle: 'medium',
});

const relativeLabel = (date, now) => {
    const seconds = (date.getTime() - now) / 1000;
    const absolute = Math.abs(seconds);
    if (absolute < 45) {
        return relativeFormatter.format(0, 'second');
    }
    if (absolute < 3_600) {
        return relativeFormatter.format(Math.round(seconds / 60), 'minute');
    }
    if (absolute < 86_400) {
        return relativeFormatter.format(Math.round(seconds / 3_600), 'hour');
    }
    if (absolute < 2_592_000) {
        return relativeFormatter.format(Math.round(seconds / 86_400), 'day');
    }
    if (absolute < 31_536_000) {
        return relativeFormatter.format(Math.round(seconds / 2_592_000), 'month');
    }
    return relativeFormatter.format(Math.round(seconds / 31_536_000), 'year');
};

export const initializeLocalTime = () => {
    const records = Array.from(document.querySelectorAll('time[datetime]'))
        .filter((time) => time instanceof HTMLTimeElement)
        .map((time) => ({
            time,
            date: new Date(time.dateTime),
            utcLabel: time.title || time.textContent || 'UTC time',
        }))
        .filter(({ date }) => Number.isFinite(date.getTime()));
    if (records.length === 0) {
        return;
    }

    const update = () => {
        const now = Date.now();
        records.forEach(({ time, date, utcLabel }) => {
            time.textContent = relativeLabel(date, now);
            time.title = localFormatter.format(date) + ' local · ' + utcLabel;
            time.dataset.localTime = 'true';
        });
    };

    update();
    const interval = window.setInterval(update, 60_000);
    window.addEventListener('pagehide', () => window.clearInterval(interval), { once: true });
};
