export const initializeThreadNavigation = () => {
    const posts = Array.from(document.querySelectorAll('.post[id]'))
        .filter((post) => post instanceof HTMLElement);
    if (posts.length < 2) return;
    let currentPost = posts.find((post) => post.matches(':target')) ?? posts[0];

    const navigate = (direction) => {
        const available = posts.filter((post) => (
            !post.hidden && !post.closest('[hidden]') && !post.closest('.thread-preview--locked-hidden')
        ));
        if (available.length === 0) return;
        const current = Math.max(0, available.indexOf(currentPost));
        const next = Math.min(available.length - 1, Math.max(0, current + direction));
        const post = available[next];
        currentPost = post;
        post.tabIndex = -1;
        post.focus({ preventScroll: true });
        post.scrollIntoView({ behavior: 'smooth', block: 'center' });
        window.history.replaceState(null, '', '#' + post.id);
    };
    document.addEventListener('keydown', (event) => {
        if (event.defaultPrevented || event.ctrlKey || event.metaKey || event.altKey
            || event.target instanceof HTMLInputElement
            || event.target instanceof HTMLTextAreaElement
            || event.target instanceof HTMLSelectElement
            || (event.target instanceof HTMLElement && event.target.isContentEditable)) {
            return;
        }
        if (event.key.toLocaleLowerCase() === 'j') {
            event.preventDefault();
            navigate(1);
        } else if (event.key.toLocaleLowerCase() === 'k') {
            event.preventDefault();
            navigate(-1);
        }
    });
};
