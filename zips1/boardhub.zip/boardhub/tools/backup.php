<?php

declare(strict_types=1);

use BoardHub\BackupService;

$config = require dirname(__DIR__) . '/bootstrap.php';
$destination = $argv[1] ?? ($config->root . '/backups/' . gmdate('Ymd-His') . '-utc');
if (!is_string($destination) || $destination === '') {
    fwrite(STDERR, "Usage: php tools/backup.php [DESTINATION]\n");
    exit(2);
}
$path = (new BackupService($config))->create($destination);
fwrite(STDOUT, "Verified backup created at: $path\n");
