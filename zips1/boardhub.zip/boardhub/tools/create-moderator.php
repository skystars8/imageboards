<?php

declare(strict_types=1);

use BoardHub\ControlStore;

try {
    $config = require dirname(__DIR__) . '/bootstrap.php';
    $username = $argv[1] ?? '';
    if (!is_string($username) || $username === '') {
        fwrite(STDERR, "Usage: php tools/create-moderator.php USERNAME\n");
        exit(2);
    }
    $password = getenv('BOARDHUB_NEW_MOD_PASSWORD');
    if (!is_string($password) || $password === '') {
        fwrite(STDOUT, "No password was received from the environment.\n");
        fwrite(STDOUT, 'Password (input is visible; 12+ characters): ');
        $password = trim((string) fgets(STDIN));
    }
    (new ControlStore($config))->createModerator($username, $password);
    fwrite(STDOUT, "Moderator created.\n");
} catch (Throwable $error) {
    fwrite(STDERR, "\nModerator was not created: " . $error->getMessage() . "\n");
    fwrite(STDERR, "Correct the value and run the command again. No stack trace is needed.\n");
    exit(1);
}
