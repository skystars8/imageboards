<?php

declare(strict_types=1);

use BoardHub\BoardRegistry;
use BoardHub\Publisher;
use BoardHub\Renderer;

$config = require dirname(__DIR__) . '/bootstrap.php';
$registry = new BoardRegistry($config);
$failures = (new Publisher($config, $registry, new Renderer($config->javascriptFeatures)))->publishAll(true);
foreach ($registry->issues() as $slug => $message) {
    fwrite(STDERR, "Configuration issue [$slug]: $message\n");
}
foreach ($failures as $slug => $message) {
    fwrite(STDERR, "Publish failure [$slug]: $message\n");
}
if ($registry->issues() !== [] || $failures !== []) {
    exit(1);
}
fwrite(STDOUT, 'Published ' . count($registry->all()) . " board(s).\n");
