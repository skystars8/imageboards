<?php

declare(strict_types=1);

use BoardHub\BackupService;

$config = require dirname(__DIR__) . '/bootstrap.php';
$source = $argv[1] ?? '';
$confirmation = $argv[2] ?? '';
if (!is_string($source) || $source === '' || $confirmation !== '--confirm-empty') {
    fwrite(STDERR, "Usage: php tools/restore.php BACKUP_DIRECTORY --confirm-empty\n");
    fwrite(STDERR, "The current install must have no control database or boards.\n");
    exit(2);
}
(new BackupService($config))->restore($source);
fwrite(STDOUT, "Backup integrity verified, data restored, and static pages rebuilt.\n");
