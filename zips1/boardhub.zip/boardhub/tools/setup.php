<?php

declare(strict_types=1);

use BoardHub\BoardRegistry;
use BoardHub\Config;
use BoardHub\ControlStore;
use BoardHub\Publisher;
use BoardHub\Renderer;

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

$config = require dirname(__DIR__) . '/bootstrap.php';

/** @return never */
function setupFailure(string $message): never
{
    fwrite(STDERR, "\nSETUP STOPPED\n");
    fwrite(STDERR, $message . "\n");
    fwrite(STDERR, "Correct the problem and run setup again. Completed safe steps are not overwritten.\n");
    exit(1);
}

function readAnswer(string $question, ?string $default = null): string
{
    $suffix = $default === null ? ': ' : " [$default]: ";
    fwrite(STDOUT, $question . $suffix);
    $answer = fgets(STDIN);
    if ($answer === false) {
        setupFailure('The setup input was closed.');
    }
    $answer = trim($answer);

    return $answer === '' && $default !== null ? $default : $answer;
}

function readModeratorUsername(): string
{
    while (true) {
        $username = readAnswer('First moderator username', 'admin');
        if (preg_match('/\A[a-zA-Z0-9_-]{3,40}\z/', $username)) {
            return $username;
        }
        fwrite(STDOUT, "  Use 3-40 letters, numbers, underscores, or hyphens.\n");
    }
}

function readConfirmation(string $username): bool
{
    while (true) {
        $answer = strtolower(readAnswer("Create moderator '$username' now? (yes/no)", 'yes'));
        if (in_array($answer, ['yes', 'y'], true)) {
            return true;
        }
        if (in_array($answer, ['no', 'n'], true)) {
            return false;
        }
        fwrite(STDOUT, "  Please type yes or no.\n");
    }
}

function setupPassword(): string
{
    $encoded = getenv('BOARDHUB_SETUP_PASSWORD_B64');
    if (is_string($encoded) && $encoded !== '') {
        $password = base64_decode($encoded, true);
        putenv('BOARDHUB_SETUP_PASSWORD_B64');
        if (!is_string($password) || strlen($password) < 12) {
            setupFailure('The launcher did not provide a valid 12-character moderator password.');
        }

        return $password;
    }

    fwrite(STDOUT, "\nThe wrapper normally hides password input. Direct PHP input is visible.\n");
    while (true) {
        $first = readAnswer('Moderator password (12+ characters)');
        if (strlen($first) < 12) {
            fwrite(STDOUT, "  That password is too short; try again.\n");
            continue;
        }
        $second = readAnswer('Type the same password again');
        if (!hash_equals($first, $second)) {
            fwrite(STDOUT, "  Those passwords did not match; try again.\n");
            continue;
        }

        return $first;
    }
}

function publishSetupPages(Config $config): void
{
    $registry = new BoardRegistry($config);
    if ($registry->issues() !== []) {
        throw new RuntimeException('Existing board configuration issues must be corrected before publishing.');
    }
    $failures = (new Publisher($config, $registry, new Renderer($config->javascriptFeatures)))->publishAll(true);
    if ($failures !== []) {
        throw new RuntimeException('Static page generation failed: ' . implode('; ', $failures));
    }
}

try {
    if (PHP_VERSION_ID < 80500) {
        setupFailure('PHP 8.5 or newer is required. Found PHP ' . PHP_VERSION . '.');
    }
    foreach (['pdo_sqlite', 'sqlite3', 'gd', 'fileinfo', 'mbstring', 'openssl'] as $extension) {
        if (!extension_loaded($extension)) {
            setupFailure("Required PHP extension is missing: $extension.");
        }
    }

    fwrite(STDOUT, "\nBOARDHUB FIRST MODERATOR SETUP\n");
    fwrite(STDOUT, "This creates only the first moderator account and the empty static shell.\n");
    fwrite(STDOUT, "Boards are created after login from Mod -> Boards.\n\n");

    $control = new ControlStore($config, false);
    if ($control->hasModerators()) {
        putenv('BOARDHUB_SETUP_PASSWORD_B64');
        fwrite(STDOUT, "A moderator account already exists. Nothing was changed.\n");
        fwrite(STDOUT, "Start the server, log in at /mod, and use Boards to create or manage boards.\n");
        exit(0);
    }

    $moderatorUsername = readModeratorUsername();
    $password = setupPassword();
    fwrite(STDOUT, "\nPLEASE CHECK\n");
    fwrite(STDOUT, "  First moderator: $moderatorUsername\n");
    fwrite(STDOUT, "  Boards: create them later from /mod/boards\n\n");
    if (!readConfirmation($moderatorUsername)) {
        unset($password);
        fwrite(STDOUT, "\nSetup cancelled. No moderator was created.\n");
        exit(2);
    }

    $control->createModerator($moderatorUsername, $password);
    unset($password);
    publishSetupPages($config);

    fwrite(STDOUT, "\n============================================================\n");
    fwrite(STDOUT, "SETUP SUCCESSFUL\n");
    fwrite(STDOUT, "============================================================\n");
    fwrite(STDOUT, "Moderator: $moderatorUsername\n");
    fwrite(STDOUT, "Next: start the server, open /mod, then choose Boards -> Create board.\n");
    exit(0);
} catch (Throwable $error) {
    putenv('BOARDHUB_SETUP_PASSWORD_B64');
    setupFailure($error->getMessage());
}
