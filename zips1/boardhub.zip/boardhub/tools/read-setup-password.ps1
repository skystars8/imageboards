$ErrorActionPreference = 'Stop'

function ConvertTo-PlainText {
    param([Security.SecureString]$SecureValue)

    $pointer = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureValue)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)
    }
    finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)
    }
}

while ($true) {
    $firstSecure = Read-Host 'Choose a moderator password (12+ characters)' -AsSecureString
    $secondSecure = Read-Host 'Type the same password again' -AsSecureString
    $first = ConvertTo-PlainText $firstSecure
    $second = ConvertTo-PlainText $secondSecure

    if ($first.Length -lt 12) {
        [Console]::Error.WriteLine('That password is too short. Please use at least 12 characters.')
        continue
    }
    if ($first -cne $second) {
        [Console]::Error.WriteLine('Those passwords did not match. Please try again.')
        continue
    }

    [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($first))
    break
}
