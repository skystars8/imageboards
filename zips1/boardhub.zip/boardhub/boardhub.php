<?php

declare(strict_types=1);

use BoardHub\Application;
use BoardHub\BoardRegistry;
use BoardHub\HttpException;
use BoardHub\RateLimitException;
use BoardHub\Renderer;
use BoardHub\Response;

$config = require __DIR__ . '/bootstrap.php';

try {
    (new Application($config))->handle();
} catch (RateLimitException $error) {
    header('Retry-After: ' . $error->retryAfter);
    $registry = new BoardRegistry($config);
    Response::html((new Renderer($config->javascriptFeatures))->message('Please slow down', $error->getMessage(), $registry->all()), 429);
} catch (HttpException $error) {
    $registry = new BoardRegistry($config);
    Response::html((new Renderer($config->javascriptFeatures))->message('Request failed', $error->getMessage(), $registry->all()), $error->status);
} catch (Throwable $error) {
    error_log((string) $error);
    $message = $config->environment === 'development'
        ? 'Internal error: ' . $error->getMessage()
        : 'The request could not be completed. It has been logged.';
    try {
        $registry = new BoardRegistry($config);
        Response::html((new Renderer($config->javascriptFeatures))->message('Server error', $message, $registry->all()), 500);
    } catch (Throwable) {
        Response::text('Internal server error', 500);
    }
}
