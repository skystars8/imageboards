#!/usr/bin/env sh

set -u
cd "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

PHP_BIN="${PHP_BIN:-php}"

printf '\n============================================================\n'
printf '  BoardHub Experimental - First Moderator Setup\n'
printf '============================================================\n\n'
printf 'This creates the first moderator and empty public pages.\n'
printf 'Boards are created after login from Mod -> Boards.\n\n'

if ! command -v "$PHP_BIN" >/dev/null 2>&1; then
    printf 'ERROR: PHP was not found. Install PHP 8.5 or set PHP_BIN.\n' >&2
    exit 1
fi

restore_echo() {
    if [ "${BOARDHUB_ECHO_DISABLED:-0}" = "1" ]; then
        stty echo
        printf '\n'
    fi
    unset BOARDHUB_SETUP_PASSWORD_B64
}
trap restore_echo EXIT HUP INT TERM

while :; do
    printf 'Choose the first moderator password (12+ characters): '
    if [ -t 0 ]; then
        stty -echo
        BOARDHUB_ECHO_DISABLED=1
    fi
    IFS= read -r first_password || exit 1
    if [ "${BOARDHUB_ECHO_DISABLED:-0}" = "1" ]; then
        stty echo
        BOARDHUB_ECHO_DISABLED=0
        printf '\n'
    fi

    printf 'Type the same password again: '
    if [ -t 0 ]; then
        stty -echo
        BOARDHUB_ECHO_DISABLED=1
    fi
    IFS= read -r second_password || exit 1
    if [ "${BOARDHUB_ECHO_DISABLED:-0}" = "1" ]; then
        stty echo
        BOARDHUB_ECHO_DISABLED=0
        printf '\n'
    fi

    if [ "${#first_password}" -lt 12 ]; then
        printf 'That password is too short. Please try again.\n\n' >&2
        continue
    fi
    if [ "$first_password" != "$second_password" ]; then
        printf 'Those passwords did not match. Please try again.\n\n' >&2
        continue
    fi
    break
done

BOARDHUB_SETUP_PASSWORD_B64="$(printf '%s' "$first_password" | base64 | tr -d '\r\n')"
export BOARDHUB_SETUP_PASSWORD_B64
unset first_password second_password

"$PHP_BIN" tools/setup.php
status=$?
unset BOARDHUB_SETUP_PASSWORD_B64
trap - EXIT HUP INT TERM

if [ "$status" -eq 0 ]; then
    printf '\nSetup is complete. Run: sh start-test-server.sh\n'
    printf 'Then log in at /mod and create the first board from Boards.\n'
else
    printf '\nSetup stopped. Read the message above, correct it, and run setup.sh again.\n' >&2
fi
exit "$status"
