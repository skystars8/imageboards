PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS board_state (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    revision INTEGER NOT NULL DEFAULT 0 CHECK (revision >= 0),
    published_revision INTEGER NOT NULL DEFAULT 0 CHECK (published_revision >= 0)
) STRICT;

CREATE TABLE IF NOT EXISTS posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    thread_id INTEGER REFERENCES posts(id) ON DELETE RESTRICT,
    is_op INTEGER NOT NULL CHECK (is_op IN (0, 1)),
    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 80),
    subject TEXT NOT NULL DEFAULT '' CHECK (length(subject) <= 120),
    body TEXT NOT NULL CHECK (length(trim(body)) BETWEEN 1 AND 100000),
    image_original_name TEXT CHECK (image_original_name IS NULL OR length(image_original_name) <= 255),
    image_stored_name TEXT CHECK (image_stored_name IS NULL OR image_stored_name NOT GLOB '*[\\/]*'),
    thumbnail_stored_name TEXT CHECK (thumbnail_stored_name IS NULL OR thumbnail_stored_name NOT GLOB '*[\\/]*'),
    image_mime TEXT,
    image_size INTEGER CHECK (image_size IS NULL OR image_size > 0),
    image_width INTEGER CHECK (image_width IS NULL OR image_width > 0),
    image_height INTEGER CHECK (image_height IS NULL OR image_height > 0),
    created_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    last_activity_at INTEGER NOT NULL,
    sticky INTEGER NOT NULL DEFAULT 0 CHECK (sticky IN (0, 1)),
    locked INTEGER NOT NULL DEFAULT 0 CHECK (locked IN (0, 1)),
    deleted INTEGER NOT NULL DEFAULT 0 CHECK (deleted IN (0, 1)),
    approved INTEGER NOT NULL DEFAULT 1 CHECK (approved IN (0, 1)),
    CHECK (
        (is_op = 1 AND subject != '')
        OR (is_op = 0 AND subject = '' AND sticky = 0 AND locked = 0)
    )
) STRICT;

CREATE TABLE IF NOT EXISTS board_settings (
    singleton INTEGER PRIMARY KEY CHECK (singleton = 1),
    posting_mode TEXT NOT NULL CHECK (posting_mode IN ('open', 'approval', 'password', 'closed')),
    posting_password_hash TEXT
) STRICT;

CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
    reporter_key TEXT NOT NULL CHECK (length(reporter_key) = 64),
    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 500),
    status TEXT NOT NULL DEFAULT 'open' CHECK (status IN ('open', 'resolved')),
    created_at INTEGER NOT NULL,
    resolved_at INTEGER,
    resolved_by TEXT
) STRICT;

CREATE TABLE IF NOT EXISTS moderation_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    moderator TEXT NOT NULL,
    action TEXT NOT NULL,
    post_id INTEGER,
    details_json TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(details_json)),
    created_at INTEGER NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS rate_events (
    rate_key TEXT NOT NULL CHECK (length(rate_key) = 64),
    action TEXT NOT NULL,
    created_at INTEGER NOT NULL
) STRICT;

CREATE INDEX IF NOT EXISTS idx_posts_threads
ON posts(thread_id, deleted, id);

CREATE INDEX IF NOT EXISTS idx_posts_thread_order
ON posts(sticky DESC, last_activity_at DESC, id DESC)
WHERE is_op = 1 AND deleted = 0;

CREATE INDEX IF NOT EXISTS idx_posts_recent_activity
ON posts(updated_at DESC, id DESC)
WHERE deleted = 0;

CREATE INDEX IF NOT EXISTS idx_reports_open
ON reports(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_audit_created
ON moderation_audit(created_at DESC);

CREATE TRIGGER IF NOT EXISTS trg_validate_reply_insert
BEFORE INSERT ON posts
WHEN NEW.is_op = 0
BEGIN
    SELECT CASE WHEN NOT EXISTS (
        SELECT 1 FROM posts op
        WHERE op.id = NEW.thread_id AND op.is_op = 1 AND op.deleted = 0
    ) THEN RAISE(ABORT, 'reply parent must be an active opening post') END;
END;

INSERT INTO app_meta (key, value) VALUES ('schema_version', '3')
ON CONFLICT(key) DO NOTHING;

INSERT INTO board_state (singleton, revision, published_revision)
VALUES (1, 0, 0)
ON CONFLICT(singleton) DO NOTHING;
