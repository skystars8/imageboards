PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS app_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS moderators (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at INTEGER NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS moderator_sessions (
    token_hash TEXT PRIMARY KEY CHECK (length(token_hash) = 64),
    moderator_id INTEGER NOT NULL REFERENCES moderators(id) ON DELETE CASCADE,
    csrf_token TEXT NOT NULL CHECK (length(csrf_token) >= 43),
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL CHECK (expires_at > created_at)
) STRICT;

CREATE TABLE IF NOT EXISTS login_events (
    rate_key TEXT NOT NULL CHECK (length(rate_key) = 64),
    occurred_at INTEGER NOT NULL
) STRICT;

CREATE TABLE IF NOT EXISTS global_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    moderator TEXT NOT NULL,
    action TEXT NOT NULL,
    board_slug TEXT,
    details TEXT NOT NULL DEFAULT '{}' CHECK (json_valid(details)),
    created_at INTEGER NOT NULL
) STRICT;

CREATE INDEX IF NOT EXISTS idx_sessions_expiry
ON moderator_sessions(expires_at);

CREATE INDEX IF NOT EXISTS idx_global_audit_created
ON global_audit(created_at DESC);

INSERT INTO app_meta (key, value) VALUES ('schema_version', '2')
ON CONFLICT(key) DO NOTHING;

