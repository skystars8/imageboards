@echo off
setlocal

title BoardHub Experimental - First Moderator Setup
cd /d "%~dp0"

set "PHP_EXE=C:\php\php.exe"
set "BOARDHUB_SETUP_PASSWORD_B64="

echo.
echo ============================================================
echo   BoardHub Experimental - First Moderator Setup
echo ============================================================
echo.
echo This bootstrap will:
echo   1. Create the first secure moderator account.
echo   2. Generate the empty public pages.
echo   3. Leave all board creation to Mod - Boards after login.
echo.

if not exist "%PHP_EXE%" (
    echo ERROR: PHP was not found at %PHP_EXE%
    echo Edit PHP_EXE in this file if PHP is installed elsewhere.
    echo.
    pause
    exit /b 1
)

if not exist "tools\setup.php" (
    echo ERROR: tools\setup.php is missing.
    echo Keep setup.bat in the main app directory.
    echo.
    pause
    exit /b 1
)

echo Choose the password for the first global moderator account.
echo Nothing will appear while you type it. This is normal.
echo.

for /f "delims=" %%P in ('powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\read-setup-password.ps1"') do set "BOARDHUB_SETUP_PASSWORD_B64=%%P"

if not defined BOARDHUB_SETUP_PASSWORD_B64 (
    echo.
    echo Setup stopped because no password was received.
    echo.
    pause
    exit /b 1
)

"%PHP_EXE%" tools\setup.php
set "SETUP_EXIT=%ERRORLEVEL%"
set "BOARDHUB_SETUP_PASSWORD_B64="

echo.
if "%SETUP_EXIT%"=="0" (
    echo Setup is complete.
    echo Double-click start-test-server.bat, log in at /mod,
    echo then open Boards and create the first board.
) else (
    echo Setup stopped. Read the message above, then run setup.bat again.
)
echo.
pause
exit /b %SETUP_EXIT%
