<?php

declare(strict_types=1);

$path = rawurldecode((string) parse_url((string) ($_SERVER['REQUEST_URI'] ?? '/'), PHP_URL_PATH));
$internalRoots = ['backups', 'board-template', 'config', 'database', 'site-data', 'src', 'tests', 'tools'];
$firstSegment = explode('/', trim($path, '/'), 2)[0] ?? '';
$blockedRootFiles = ['/boardhub.php', '/bootstrap.php', '/router.php', '/setup.bat', '/setup.sh', '/start-test-server.bat', '/start-test-server.sh'];

if (in_array($firstSegment, $internalRoots, true)
    || in_array($path, $blockedRootFiles, true)
    || preg_match('#(?:^|/)\.(?!well-known(?:/|$))#', $path)
    || preg_match('#\.(?:sqlite3?|db)(?:-(?:wal|shm))?\z#i', $path)) {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Not found.';
    exit;
}

// Board images remain PHP-authorized so approval-queue uploads stay private.
$boardUpload = preg_match('#\A/[a-z0-9][a-z0-9-]{0,39}/uploads/(?:originals|thumbs)/[a-f0-9]{40}\.(?:jpg|png|gif|webp)\z#', $path) === 1;
$webRoot = realpath(__DIR__);
$candidate = __DIR__ . str_replace('/', DIRECTORY_SEPARATOR, $path);
$resolved = realpath($candidate);
if (!$boardUpload && $path !== '/' && is_string($webRoot) && is_string($resolved)
    && ($resolved === $webRoot || str_starts_with($resolved, $webRoot . DIRECTORY_SEPARATOR))
    && is_file($resolved)) {
    return false;
}

require __DIR__ . '/boardhub.php';
