<?php

declare(strict_types=1);

use BoardHub\BackupService;
use BoardHub\BoardConfigService;
use BoardHub\BoardCreationService;
use BoardHub\BoardRegistry;
use BoardHub\BoardStore;
use BoardHub\Config;
use BoardHub\HttpException;
use BoardHub\ControlStore;
use BoardHub\Publisher;
use BoardHub\Renderer;
use BoardHub\Security;
use BoardHub\Support\Html;
use BoardHub\Upload;

function expect(bool $condition, string $message): void
{
    if (!$condition) {
        throw new RuntimeException($message);
    }
}

function removeTree(string $path): void
{
    if (!is_dir($path)) {
        return;
    }
    foreach (new DirectoryIterator($path) as $entry) {
        if ($entry->isDot()) {
            continue;
        }
        if ($entry->isDir()) {
            removeTree($entry->getPathname());
        } else {
            unlink($entry->getPathname());
        }
    }
    rmdir($path);
}

$root = dirname(__DIR__);
$temporary = sys_get_temp_dir() . '/boardhub-test-' . bin2hex(random_bytes(6));
$live = $temporary . '/live';
$restore = $temporary . '/restore';
$restoreAgain = $temporary . '/restore-again';
$backup = $temporary . '/backup';
mkdir($live . '/chess/.board', 0750, true);
mkdir($restore, 0755, true);
mkdir($restoreAgain, 0755, true);
copy($root . '/board-template/.board/board.json', $live . '/chess/.board/board.json');
copy($root . '/board-template/.board/.htaccess', $live . '/chess/.board/.htaccess');

require $root . '/bootstrap.php';

function testConfig(string $root, string $data): Config
{
    return new Config(
        root: $root,

        templatePath: $root . '/board-template',
        webRoot: $data,

        siteDataPath: $data . '/site-data',
        controlDatabasePath: $data . '/site-data/control.sqlite3',
        writeLockPath: $data . '/site-data/site-write.lock',
        environment: 'test',
        secureCookies: false,
        maxUploadBytes: 5_242_880,
        maxImageDimension: 16_384,
        maxImagePixels: 100_000_000,
        maxPendingPostsPerBoard: 2,
    );
}

try {
    foreach ([$live . '/site-data', $restore . '/site-data', $restoreAgain . '/site-data'] as $directory) {
        mkdir($directory, 0750, true);
    }
    $config = testConfig($root, $live);
    try {
        putenv('BOARDHUB_JAVASCRIPT=true');
        putenv('BOARDHUB_JS_FEATURES=quote-links, preferences,quote-links');
        $selectiveJavaScriptConfig = Config::load($root);
        expect(
            $selectiveJavaScriptConfig->javascriptFeatures === ['preferences', 'quote-links'],
            'JavaScript feature allowlist was not normalized into canonical order.',
        );

        putenv('BOARDHUB_JAVASCRIPT=false');
        $noJavaScriptConfig = Config::load($root);
        expect($noJavaScriptConfig->javascriptFeatures === [], 'Global JavaScript switch did not disable every feature.');

        putenv('BOARDHUB_JAVASCRIPT=true');
        putenv('BOARDHUB_JS_FEATURES=preferences,unknown-feature');
        try {
            Config::load($root);
            expect(false, 'Unknown JavaScript feature was accepted.');
        } catch (RuntimeException $error) {
            expect(str_contains($error->getMessage(), 'unknown-feature'), 'Unknown JavaScript feature error was not specific.');
        }
    } finally {
        putenv('BOARDHUB_JAVASCRIPT');
        putenv('BOARDHUB_JS_FEATURES');
    }
    $_SERVER['REMOTE_ADDR'] = '198.51.100.10';
    $_SERVER['HTTP_X_FORWARDED_FOR'] = '203.0.113.20';
    $privacySecurity = new Security($config);
    $firstRateKey = $privacySecurity->rateLimitKey('privacy-test');
    $_SERVER['REMOTE_ADDR'] = '192.0.2.99';
    $_SERVER['HTTP_X_FORWARDED_FOR'] = '192.0.2.100';
    expect($privacySecurity->rateLimitKey('privacy-test') === $firstRateKey, 'Rate key changed with the request IP.');
    expect($privacySecurity->rateLimitKey('other-purpose') !== $firstRateKey, 'Rate keys are not purpose-separated.');
    expect(!method_exists(Config::class, 'clientAddress') && !method_exists(Config::class, 'clientHash'), 'Config still exposes IP-derived identity methods.');
    foreach (['Config.php', 'Application.php', 'ModeratorAuth.php'] as $privacySource) {
        $source = (string) file_get_contents($root . '/src/' . $privacySource);
        expect(!str_contains($source, 'REMOTE_ADDR') && !str_contains($source, 'HTTP_X_FORWARDED_FOR'), $privacySource . ' still reads request IP data.');
    }
    $registry = new BoardRegistry($config);
    expect($registry->issues() === [], 'Board discovery reported an issue: ' . json_encode($registry->issues()));
    $board = $registry->get('chess');
    expect($board !== null, 'Board was not discovered.');
    $boardRoot = str_replace('\\', '/', (string) realpath($board->path));
    expect(str_ends_with($boardRoot, '/live/chess'), 'Board is not physically rooted at its public URL directory.');
    expect($board->privatePath() === $board->path . '/.board', 'Board private path is outside the portable board folder.');
    expect($board->configPath() === $board->path . '/.board/board.json', 'Board configuration is not private and board-local.');
    expect($board->databasePath() === $board->path . '/.board/board.sqlite3', 'Board database is not private and board-local.');
    expect(!is_dir($live . '/boards'), 'The obsolete centralized boards directory still exists in a new install.');
    foreach (['public', 'bin', 'var'] as $legacyWrapper) {
        expect(!is_dir($root . '/' . $legacyWrapper), 'Legacy wrapper remains in the application root: ' . $legacyWrapper);
    }
    expect(!is_file($root . '/index.php'), 'The obsolete second index file still exists.');
    expect(!is_dir($root . '/stylesheets'), 'The obsolete separate stylesheets directory still exists.');
    foreach (['boardhub.php', 'index.html', '.htaccess', 'static', 'tools', 'site-data'] as $flatEntry) {
        expect(file_exists($root . '/' . $flatEntry), 'Flat web-root entry is missing: ' . $flatEntry);
    }
    $store = new BoardStore($config, $board);
    $boardSchemaCheck = new PDO('sqlite:' . $board->databasePath());
    expect((string) $boardSchemaCheck->query("SELECT value FROM app_meta WHERE key = 'schema_version'")->fetchColumn() === '3', 'New board schema is not v3.');
    $reportColumns = $boardSchemaCheck->query('PRAGMA table_info(reports)')->fetchAll(PDO::FETCH_COLUMN, 1);
    $rateColumns = $boardSchemaCheck->query('PRAGMA table_info(rate_events)')->fetchAll(PDO::FETCH_COLUMN, 1);
    expect(in_array('reporter_key', $reportColumns, true) && !in_array('reporter_hash', $reportColumns, true), 'Reports still use the legacy IP-derived column.');
    expect(in_array('rate_key', $rateColumns, true) && !in_array('client_hash', $rateColumns, true), 'Board rate events still use the legacy IP-derived column.');
    $openingUpload = new Upload(
        'opening.jpg',
        str_repeat('1', 40) . '.jpg',
        str_repeat('2', 40) . '.jpg',
        'image/jpeg',
        12_345,
        640,
        480,
    );
    $op = $store->createPost(null, 'Anonymous', 'First game', '1. e4 e5', $openingUpload, str_repeat('a', 64));
    expect($op['id'] === $op['thread_id'], 'Opening post did not become its thread identity.');
    $reply = $store->createPost($op['thread_id'], 'Knight', '', '2. Nf3', null, str_repeat('b', 64));
    $store->createPost($op['thread_id'], 'Bishop', '', '3. Bb5', null, str_repeat('d', 64));
    $store->createPost($op['thread_id'], 'Castle', '', '3... Nf6', null, str_repeat('e', 64));
    expect(count($store->threadPosts($op['thread_id'])) === 4, 'Replies were not stored.');
    $preview = $store->threads()[0];
    expect($preview['reply_count'] === 3, 'Board preview reply count was incorrect.');
    expect(count($preview['replies']) === 2, 'Board preview did not match the Rust two-reply limit.');
    $catalogThreads = $store->catalogThreads();
    expect(count($catalogThreads) === 1, 'Catalog query did not return the active thread.');
    expect((int) $catalogThreads[0]['reply_count'] === 3, 'Catalog reply count was incorrect.');
    expect((int) $catalogThreads[0]['image_count'] === 1, 'Catalog image count was incorrect.');
    expect((int) $catalogThreads[0]['last_post_id'] > $op['thread_id'], 'Catalog last-post identity was not calculated.');
    $initialManifest = $store->updateManifest();
    expect($initialManifest['threads'][0]['post_count'] === 4, 'Update manifest post count was incorrect.');
    $store->reportPost($reply['id'], str_repeat('c', 64), 'Integration test report');
    expect(count($store->openReports()) === 1, 'Report was not stored locally.');

    $featureRenderer = new Renderer();
    $store->updatePostingPolicy('approval', null);
    $pendingUpload = new Upload(
        'pending.jpg',
        str_repeat('5', 40) . '.jpg',
        str_repeat('6', 40) . '.jpg',
        'image/jpeg',
        4_321,
        400,
        300,
    );
    $pendingBody = 'Private pending position analysis';
    $pendingOp = $store->createPost(
        null,
        'Club guest',
        'Needs review',
        $pendingBody,
        $pendingUpload,
        str_repeat('5', 64),
    );
    expect(!$pendingOp['approved'], 'Approval mode published a new submission immediately.');
    expect((int) $store->post($pendingOp['id'])['approved'] === 0, 'Pending state was not stored.');
    expect($store->pendingCount() === 1, 'Pending queue count was incorrect.');
    expect($store->threadPosts($pendingOp['thread_id']) === [], 'Pending thread leaked into public thread queries.');
    expect(
        array_filter($store->threads(), static fn (array $thread): bool => (int) $thread['op']['id'] === $pendingOp['id']) === [],
        'Pending thread leaked into the public board query.',
    );
    expect(
        array_filter($store->latestActivity(20), static fn (array $post): bool => (int) $post['id'] === $pendingOp['id']) === [],
        'Pending post leaked into public latest activity.',
    );
    expect(!$store->imageIsAccessible('originals', $pendingUpload->storedName, false), 'Pending original is publicly accessible.');
    expect(!$store->imageIsAccessible('thumbs', $pendingUpload->thumbnailName, false), 'Pending thumbnail is publicly accessible.');
    expect($store->imageIsAccessible('originals', $pendingUpload->storedName, true), 'Moderator cannot access a pending image.');

    $featureUser = ['username' => 'tester', 'csrf_token' => 'test-csrf'];
    $approvalPage = $featureRenderer->moderatorApproval(
        [['board' => $board, 'post' => $store->post($pendingOp['id'])]],
        [$board],
        $featureUser,
        [],
        1,
        1,
    );
    expect(str_contains($approvalPage, 'Approval queue'), 'Approval page heading is missing.');
    expect(str_contains($approvalPage, 'Posts remain private until approved'), 'Approval privacy explanation is missing.');
    expect(str_contains($approvalPage, 'value="Approve"'), 'Approval action is missing.');
    expect(str_contains($approvalPage, 'value="Reject"'), 'Pending rejection action is missing.');
    expect(str_contains($approvalPage, '[Edit before approval]'), 'Pending edit action is missing.');
    expect(str_contains($approvalPage, '/chess/uploads/thumbs/' . $pendingUpload->thumbnailName), 'Pending image is missing from moderation.');
    $pendingEditPage = $featureRenderer->moderatorEdit(
        $board,
        $store->post($pendingOp['id']),
        $featureUser,
        [$board],
        '/mod/approval',
        1,
        1,
    );
    expect(str_contains($pendingEditPage, 'Pending') && str_contains($pendingEditPage, 'OP thread'), 'Pending editor does not identify the private state.');
    expect(!str_contains($pendingEditPage, '[View post]'), 'Pending editor links to a nonexistent public post.');

    $featurePublisher = new Publisher($config, $registry, $featureRenderer);
    $pendingPublishFailures = $featurePublisher->publishAll(true);
    expect(
        $pendingPublishFailures === [],
        'Publishing with a pending post failed: ' . json_encode($pendingPublishFailures),
    );
    $pendingBoardHtml = (string) file_get_contents($live . '/chess/index.html');
    expect(!str_contains($pendingBoardHtml, $pendingBody), 'Pending text leaked into generated HTML.');
    expect(!str_contains($pendingBoardHtml, $pendingUpload->storedName), 'Pending image leaked into generated HTML.');

    $store->approvePost($pendingOp['id'], 'tester');
    expect((int) $store->post($pendingOp['id'])['approved'] === 1, 'Approved post remained pending.');
    expect($store->pendingCount() === 0, 'Approval did not remove the post from the queue.');
    expect($store->imageIsAccessible('originals', $pendingUpload->storedName, false), 'Approved image did not become public.');
    $featurePublisher->publishBoard($board);
    $featurePublisher->publishShared();
    $approvedBoardHtml = (string) file_get_contents($live . '/chess/index.html');
    expect(str_contains($approvedBoardHtml, $pendingBody), 'Approved post was not published.');
    $store->softDelete($pendingOp['id'], 'tester');

    $pendingReplyOne = $store->createPost(
        $op['thread_id'],
        'Queued one',
        '',
        'First queued reply',
        null,
        str_repeat('7', 64),
    );
    $pendingReplyTwo = $store->createPost(
        $op['thread_id'],
        'Queued two',
        '',
        'Second queued reply',
        null,
        str_repeat('8', 64),
    );
    try {
        $store->createPost(
            $op['thread_id'],
            'Queue overflow',
            '',
            'This must be refused',
            null,
            str_repeat('9', 64),
        );
        expect(false, 'Full approval queue accepted another post.');
    } catch (HttpException $error) {
        expect($error->status === 503, 'Full approval queue returned the wrong status.');
    }
    $pendingEdit = $store->editPost(
        $pendingReplyOne['id'],
        'Queued one',
        '',
        'Edited while still private',
        'tester',
    );
    expect(!$pendingEdit['public_changed'], 'Editing a pending post marked public pages dirty.');
    $store->rejectPending($pendingReplyOne['id'], 'tester');
    $store->rejectPending($pendingReplyTwo['id'], 'tester');
    expect($store->pendingCount() === 0, 'Rejected posts remained in the approval queue.');
    expect($store->post($pendingReplyOne['id']) === null, 'Rejected pending post was not physically removed.');

    $postingPassword = 'shared-club-password';
    $postingPasswordHash = BoardStore::hashPostingPassword($postingPassword);
    expect(password_get_info($postingPasswordHash)['algoName'] === 'argon2id', 'Posting password is not hashed with Argon2id.');
    $store->updatePostingPolicy('password', $postingPasswordHash);
    expect(
        $store->verifyPostingPassword('wrong-password', str_repeat('a', 64)) === null,
        'Incorrect board password was accepted.',
    );
    $verifiedPasswordHash = $store->verifyPostingPassword($postingPassword, str_repeat('b', 64));
    expect($verifiedPasswordHash === $postingPasswordHash, 'Correct board password was rejected.');
    try {
        $store->createPost(
            $op['thread_id'],
            'No password',
            '',
            'Must not post',
            null,
            str_repeat('c', 64),
        );
        expect(false, 'Password mode accepted a post without verification.');
    } catch (HttpException $error) {
        expect($error->status === 403, 'Missing board password returned the wrong status.');
    }
    $protectedReply = $store->createPost(
        $op['thread_id'],
        'Club member',
        '',
        'Shared-password reply',
        null,
        str_repeat('c', 64),
        $verifiedPasswordHash,
    );
    expect($protectedReply['approved'], 'Password-authorized post was not published immediately.');
    $store->softDelete($protectedReply['id'], 'tester');
    $store->updatePostingPolicy('closed', $postingPasswordHash);
    try {
        $store->createPost(null, 'Closed', 'Closed board', 'Must not post', null, str_repeat('d', 64));
        expect(false, 'Closed mode accepted a post.');
    } catch (HttpException $error) {
        expect($error->status === 409, 'Closed mode returned the wrong status.');
    }
    $store->updatePostingPolicy('open', null);
    $boardConfigService = new BoardConfigService($config);
    $boardConfigService->update(
        $board,
        $board->title,
        $board->description,
        'approval',
        $board->threadsPerPage,
    );
    $approvalBoard = (new BoardRegistry($config))->get('chess');
    expect($approvalBoard !== null && $approvalBoard->postingMode === 'approval', 'Approval mode was not persisted to board.json.');
    expect($approvalBoard->postingEnabled, 'Approval mode must continue accepting submissions.');
    $approvalCompose = $featureRenderer->compose($approvalBoard, null, 'test-csrf', [$approvalBoard]);
    expect(str_contains($approvalCompose, 'remains private until a moderator approves'), 'Approval compose form lacks its privacy notice.');
    $boardConfigService->update(
        $approvalBoard,
        $approvalBoard->title,
        $approvalBoard->description,
        'password',
        $approvalBoard->threadsPerPage,
    );
    $passwordBoard = (new BoardRegistry($config))->get('chess');
    expect($passwordBoard !== null && $passwordBoard->postingMode === 'password', 'Password mode was not persisted to board.json.');
    $passwordCompose = $featureRenderer->compose($passwordBoard, null, 'test-csrf', [$passwordBoard]);
    expect(str_contains($passwordCompose, 'name="board_password"'), 'Password mode compose form lacks the shared-password field.');
    expect(str_contains($passwordCompose, 'autocomplete="off" required'), 'Shared-password field is not required or disables autocomplete.');
    $passwordBoardPage = $featureRenderer->board($passwordBoard, [], [$passwordBoard]);
    expect(str_contains($passwordBoardPage, 'This club board requires its posting password.'), 'Password board lacks its public mode notice.');
    $boardConfigService->update(
        $passwordBoard,
        $passwordBoard->title,
        $passwordBoard->description,
        'open',
        $passwordBoard->threadsPerPage,
    );
    $replacement = new Upload(
        'reply.png',
        str_repeat('3', 40) . '.png',
        str_repeat('4', 40) . '.jpg',
        'image/png',
        5_432,
        320,
        240,
    );
    $editResult = $store->editPost($reply['id'], 'Knight', '', '2. Nf3 Nc6', 'tester', $replacement);
    expect($editResult['image_changed'], 'Moderator image replacement was not recorded.');
    expect($store->post($reply['id'])['image_stored_name'] === $replacement->storedName, 'Replacement image metadata was not stored.');
    $removeResult = $store->editPost($reply['id'], 'Knight', '', '2. Nf3 Nc6', 'tester', null, true);
    expect($removeResult['image_changed'], 'Moderator image removal was not recorded.');
    expect($store->post($reply['id'])['image_stored_name'] === null, 'Removed image metadata remained on the post.');
    $store->editPost(
        $op['id'],
        'Anonymous',
        'First game',
        str_repeat('A long opening-plan paragraph for the board preview. ', 45),
        'tester',
    );
    expect($store->toggleThread($op['thread_id'], 'sticky', 'tester'), 'Thread was not pinned.');
    expect($store->toggleThread($op['thread_id'], 'locked', 'tester'), 'Thread was not locked.');

    $renderer = new Renderer();
    $emptyHome = $renderer->home([], []);
    expect(str_contains($emptyHome, '/mod/boards'), 'Empty home does not direct moderators to board creation.');
    expect(!str_contains($emptyHome, 'Copy <code>board-template</code>'), 'Empty home still teaches manual board-template copying.');
    $noJavaScriptRenderer = new Renderer([]);
    $noJavaScriptBoard = $noJavaScriptRenderer->board($board, $store->threads(), [$board]);
    expect(!str_contains($noJavaScriptBoard, 'data-js-features='), 'No-JavaScript page exposes a feature policy.');
    expect(!str_contains($noJavaScriptBoard, '/static/assets/js/app.js'), 'No-JavaScript page still loads the application script.');
    expect(!str_contains($noJavaScriptBoard, 'id="style-switcher"'), 'No-JavaScript page renders a dead theme control.');
    expect(!str_contains($noJavaScriptBoard, 'data-image-visibility-toggle'), 'No-JavaScript page renders a dead image control.');
    expect(!str_contains($noJavaScriptBoard, 'data-image-expansion-toggle'), 'No-JavaScript page renders a dead expansion control.');
    expect(!str_contains($noJavaScriptBoard, 'enhancements-dialog'), 'No-JavaScript page renders a dead enhancements panel.');
    expect(str_contains($noJavaScriptBoard, '<details class="post-menu">'), 'No-JavaScript page lost its native post menu.');
    expect(str_contains($noJavaScriptBoard, 'href="/report?board='), 'No-JavaScript page lost its native report link.');
    $noJavaScriptCatalog = $noJavaScriptRenderer->catalog($board, $store->catalogThreads(), [$board]);
    expect(str_contains($noJavaScriptCatalog, 'data-catalog-card'), 'No-JavaScript catalog lost its static thread cards.');
    expect(!str_contains($noJavaScriptCatalog, 'data-catalog-tools'), 'No-JavaScript catalog renders dead search controls.');

    $quoteOnlyRenderer = new Renderer(['quote-links']);
    $quoteOnlyHome = $quoteOnlyRenderer->home([$board], []);
    expect(str_contains($quoteOnlyHome, 'data-js-features="quote-links"'), 'Selective JavaScript policy was not rendered.');
    expect(str_contains($quoteOnlyHome, '/static/assets/js/app.js'), 'Selective JavaScript page omitted the feature loader.');
    expect(!str_contains($quoteOnlyHome, 'id="style-switcher"'), 'Selective JavaScript page rendered a disabled preference control.');
    try {
        new Renderer(['unknown-feature']);
        expect(false, 'Renderer accepted an unknown JavaScript feature.');
    } catch (InvalidArgumentException) {
    }

    foreach (['setup.bat', 'setup.sh', 'start-test-server.bat', 'start-test-server.sh', 'README.txt', 'start.html'] as $setupFile) {
        $setupText = (string) file_get_contents($root . '/' . $setupFile);
        expect(str_contains($setupText, 'Boards'), "$setupFile does not mention moderator board management.");
        expect(!str_contains($setupText, 'There is no PHP &quot;create board&quot; endpoint'), "$setupFile still documents the removed board-creation limitation.");
        expect(!str_contains($setupText, 'No boards are configured.'), "$setupFile still treats zero boards as a startup failure.");
    }
    expect(!str_contains((string) file_get_contents($root . '/README.txt'), 'Copy-Item board-template'), 'README still teaches manual Windows board copying.');
    expect(!str_contains((string) file_get_contents($root . '/README.txt'), 'cp -a board-template'), 'README still teaches manual Unix board copying.');
    $readme = (string) file_get_contents($root . '/README.txt');
    expect(preg_match('/Open,\s+Approval,\s+Password,\s+or Closed/', $readme) === 1, 'README does not document all posting modes.');
    expect(str_contains($readme, 'BOARDHUB_MAX_PENDING_POSTS_PER_BOARD'), 'README omits the approval queue limit option.');
    expect(str_contains($readme, 'BOARDHUB_JAVASCRIPT'), 'README omits the global JavaScript switch.');
    expect(str_contains($readme, 'BOARDHUB_JS_FEATURES'), 'README omits the JavaScript feature allowlist.');
    expect(str_contains((string) file_get_contents($root . '/start.html'), 'Approval queue'), 'Start guide omits the Approval queue.');

    $user = ['username' => 'tester', 'csrf_token' => 'test-csrf'];
    $dashboard = $renderer->moderatorDashboard(
        [['board' => $board, 'post' => $store->post($op['id'])]],
        [$board],
        $user,
        [],
        1,
        0,
    );
    expect(str_contains($dashboard, '/chess/uploads/thumbs/' . $openingUpload->thumbnailName), 'Moderator dashboard did not render the post thumbnail.');
    expect(str_contains($dashboard, '/mod/reports'), 'Moderator dashboard did not link the reports queue.');
    expect(str_contains($dashboard, '/static/assets/css/legacy-moderator.css'), 'Moderator dashboard did not load the relocated Rust legacy stylesheet.');
    expect(str_contains($dashboard, '/static/assets/css/board-overrides.css'), 'Moderator dashboard did not load the relocated Rust board overrides.');
    expect(str_contains($dashboard, 'class="8chan vichan is-moderator"'), 'Moderator dashboard lacks the Rust body identity.');
    expect(str_contains($dashboard, 'class="mod-row"'), 'Moderator dashboard lacks Rust-style post rows.');
    expect(str_contains($dashboard, 'class="mod-meta"'), 'Moderator dashboard lacks compact Rust metadata.');
    expect(str_contains($dashboard, 'class="badge badge-op"'), 'Moderator dashboard lacks Rust-style OP badges.');
    expect(str_contains($dashboard, 'class="mod-image"'), 'Moderator dashboard lacks Rust-style image markup.');
    expect(str_contains($dashboard, 'value="Unpin"'), 'Opening-post row lacks its current pin control.');
    expect(str_contains($dashboard, 'value="Unlock"'), 'Opening-post row lacks its current lock control.');
    expect(!str_contains($dashboard, 'class="mod-post-list"'), 'Legacy card-list wrapper remains on the dashboard.');

    $replyForModeration = $store->post($reply['id']);
    expect($replyForModeration !== null, 'Reply disappeared before moderator rendering.');
    expect((int) $replyForModeration['thread_sticky'] === 1, 'Reply query lacks its parent thread pin state.');
    expect((int) $replyForModeration['thread_locked'] === 1, 'Reply query lacks its parent thread lock state.');
    $activityReply = array_values(array_filter(
        $store->latestActivity(10),
        static fn (array $post): bool => (int) $post['id'] === $reply['id'],
    ))[0] ?? null;
    expect(is_array($activityReply) && (int) $activityReply['thread_sticky'] === 1, 'Latest activity lacks parent pin state.');
    expect(is_array($activityReply) && (int) $activityReply['thread_locked'] === 1, 'Latest activity lacks parent lock state.');
    $replyDashboard = $renderer->moderatorDashboard(
        [['board' => $board, 'post' => $activityReply]],
        [$board],
        $user,
        [],
        1,
        0,
    );
    expect(
        preg_match(
            '/<form[^>]+data-thread-control="sticky"[^>]*>.*?name="post" value="' . $op['thread_id']
                . '".*?value="Unpin thread"/s',
            $replyDashboard,
        ) === 1,
        'Reply row does not target its parent thread with the current pin label.',
    );
    expect(
        preg_match(
            '/<form[^>]+data-thread-control="locked"[^>]*>.*?name="post" value="' . $op['thread_id']
                . '".*?value="Unlock thread"/s',
            $replyDashboard,
        ) === 1,
        'Reply row does not target its parent thread with the current lock label.',
    );
    expect(str_contains($replyDashboard, '/mod/edit?board=chess&amp;post=' . $reply['id']), 'Reply Edit still does not target the reply.');
    $formattedBody = Html::body("First line\nSecond line", 'chess', $op['thread_id']);
    expect(str_contains($formattedBody, "\n"), 'Post body newlines were not preserved.');
    expect(!str_contains($formattedBody, '<br>'), 'Post body still doubles preserved newlines with BR tags.');
    $markupBody = Html::body(
        "'''Bold''' ''italic'' **spoiler** __under__ ~~strike~~\n[code]<script>alert(1)</script>[/code]\n>>"
            . $op['thread_id'],
        'chess',
        $op['thread_id'],
    );
    foreach (['<strong>Bold</strong>', '<em>italic</em>', 'class="spoiler"', '<u>under</u>', '<s>strike</s>', 'class="post__code"'] as $markup) {
        expect(str_contains($markupBody, $markup), 'Safe post formatting is missing: ' . $markup);
    }
    expect(!str_contains($markupBody, '<script>'), 'Formatted post body allowed executable HTML.');
    expect(str_contains($markupBody, '&lt;script&gt;alert(1)&lt;/script&gt;'), 'Code formatting did not escape HTML.');
    expect(str_contains($markupBody, '&gt;&gt;' . $op['thread_id'] . ' (OP)'), 'Quotes to the opening post lack the OP indicator.');
    $report = $store->openReports()[0];
    $reportsPage = $renderer->moderatorReports(
        [['board' => $board, 'report' => $report, 'post' => $store->post($reply['id'])]],
        [$board],
        $user,
        [],
        1,
        0,
    );
    expect(str_contains($reportsPage, 'Integration test report'), 'Reports page did not render the report reason.');
    expect(str_contains($reportsPage, 'Reject report'), 'Reports page did not render the Rust-style reject action.');
    expect(str_contains($reportsPage, 'class="mod-row mod-row--report"'), 'Reports page lacks the Rust report-row treatment.');
    expect(str_contains($reportsPage, 'class="mod-body mod-body--reason"'), 'Reports page lacks the compact reason block.');
    $stats = $store->moderationStats();
    $boardsPage = $renderer->moderatorBoards(
        [['board' => $board, 'stats' => $stats]],
        [$board],
        $user,
        [],
        1,
        0,
    );
    expect(str_contains($boardsPage, '/mod/boards/edit?board=chess'), 'Boards page did not render the configure action.');
    expect(str_contains($boardsPage, '<section class="board-create">'), 'Boards page lacks the Rust create-board panel.');
    expect(str_contains($boardsPage, '<form method="post" action="/mod/boards">'), 'Create-board panel does not post to the moderator route.');
    expect(str_contains($boardsPage, 'New boards start Closed.'), 'Create-board panel does not explain its safe default.');
    expect(str_contains($boardsPage, '<table class="mod-boards">'), 'Boards page lacks the Rust moderator table.');
    expect(str_contains($boardsPage, '<th>Description</th>'), 'Boards page lacks the Rust description column.');
    expect(!str_contains($boardsPage, 'class="admin-section"'), 'Modern admin card wrapper remains on the boards page.');
    $invalidBoardsPage = $renderer->moderatorBoards(
        [['board' => $board, 'stats' => $stats]],
        [$board],
        $user,
        [],
        1,
        0,
        'That board address is already in use.',
        'chess',
        'Retained name',
        'Retained description',
    );
    expect(str_contains($invalidBoardsPage, 'role="alert">That board address is already in use.'), 'Board-create error is not rendered inline.');
    expect(str_contains($invalidBoardsPage, 'value="chess"'), 'Board-create slug was not retained after validation.');
    expect(str_contains($invalidBoardsPage, 'value="Retained name"'), 'Board-create name was not retained after validation.');
    expect(str_contains($invalidBoardsPage, 'value="Retained description"'), 'Board-create description was not retained after validation.');

    $creator = new BoardCreationService($config);
    $createdBoard = $creator->create('endgames', 'Endgames', 'Endgame study and discussion');
    expect($createdBoard->slug === 'endgames', 'Moderator board creation returned the wrong slug.');
    expect(!$createdBoard->postingEnabled, 'New boards must start with posting paused.');
    expect($createdBoard->postingMode === 'closed', 'New boards must start in Closed mode.');
    expect($createdBoard->threadsPerPage === 10, 'New boards did not receive the safe default page size.');
    expect(is_file($createdBoard->databasePath()), 'New board SQLite database was not initialized.');
    expect((new BoardStore($config, $createdBoard))->moderationStats()['posts'] === 0, 'New board was not empty.');
    $createdConfigHash = hash_file('sha256', $createdBoard->configPath());
    try {
        $creator->create('endgames', 'Replacement', 'Must not overwrite');
        expect(false, 'Duplicate board creation unexpectedly succeeded.');
    } catch (InvalidArgumentException $error) {
        expect(str_contains($error->getMessage(), 'already in use'), 'Duplicate-board error was not user-facing.');
    }
    expect(hash_file('sha256', $createdBoard->configPath()) === $createdConfigHash, 'Duplicate creation changed the existing board.');
    try {
        $creator->create('mod', 'Reserved', '');
        expect(false, 'Reserved board creation unexpectedly succeeded.');
    } catch (InvalidArgumentException) {
    }
    expect(!is_dir($live . '/mod'), 'Reserved board creation left a directory behind.');
    expect((glob($live . '/_create-*') ?: []) === [], 'Board creation left a staging directory behind.');

    $registry = new BoardRegistry($config);
    expect($registry->get('endgames') !== null, 'New board was not discoverable.');
    $boardEditPage = $renderer->moderatorBoardEdit($board, $stats, $registry->all(), $user, 1, 0, false);
    expect(str_contains($boardEditPage, '<table class="mod-form-table">'), 'Board editor lacks the Rust form-table layout.');
    expect(str_contains($boardEditPage, 'class="mod-board-stats"'), 'Board editor lacks its compact statistics line.');
    expect(str_contains($boardEditPage, 'name="posting_mode"'), 'Board editor lacks the posting-mode selector.');
    expect(str_contains($boardEditPage, 'All posts require approval'), 'Board editor lacks Approval mode.');
    expect(str_contains($boardEditPage, 'Password required to post'), 'Board editor lacks Password mode.');
    expect(str_contains($boardEditPage, 'name="posting_password"'), 'Board editor lacks the posting-password field.');
    $boardEditWithPassword = $renderer->moderatorBoardEdit($board, $stats, $registry->all(), $user, 1, 0, true);
    expect(str_contains($boardEditWithPassword, 'A password is currently set.'), 'Board editor does not show password state.');
    expect(str_contains($boardEditWithPassword, 'name="clear_posting_password"'), 'Board editor lacks the clear-password control.');    $postEditPage = $renderer->moderatorEdit($board, $store->post($op['id']), $user, [$board], '/mod', 1, 0);
    expect(str_contains($postEditPage, 'class="mod-form moderator-edit-form"'), 'Post editor lacks the Rust form shell.');
    expect(str_contains($postEditPage, 'class="mod-section-title">Image</h2>'), 'Post editor lacks the Rust image section.');
    $loginPage = $renderer->moderatorLogin([$board], 'test-csrf');
    expect(str_contains($loginPage, 'class="8chan vichan is-not-moderator"'), 'Moderator login lacks the Rust guest body identity.');
    expect(str_contains($loginPage, '<table class="mod-form-table">'), 'Moderator login lacks the Rust form table.');
    expect(is_file($root . '/static/assets/css/legacy-moderator.css'), 'Relocated Rust legacy moderator stylesheet is missing.');
    expect(is_file($root . '/static/assets/css/themes/images/fade-blue.png'), 'Canonical Rust moderator background asset is missing.');
    expect(is_file($root . '/static/assets/css/board-overrides.css'), 'Relocated Rust moderator board overrides are missing.');

    $publisher = new Publisher($config, $registry, $renderer);
    expect($publisher->publishAll(true) === [], 'Static publishing failed.');
    $boardIndexPath = $live . '/chess/index.html';
    expect(is_file($boardIndexPath), 'Board index was not generated.');
    expect(is_file($live . '/chess/threads/' . $op['thread_id'] . '.html'), 'Thread page was not generated.');
    expect(is_file($live . '/chess/catalog/index.html'), 'Static catalog page was not generated.');
    expect(is_file($live . '/chess/updates.json'), 'Static update manifest was not generated.');
    $publishedManifest = json_decode((string) file_get_contents($live . '/chess/updates.json'), true, flags: JSON_THROW_ON_ERROR);
    expect(is_array($publishedManifest['threads'] ?? null), 'Published update manifest is invalid.');
    expect(is_file($live . '/all/index.html'), 'All page was not generated.');
    $createdBoardIndexPath = $live . '/endgames/index.html';
    expect(is_file($createdBoardIndexPath), 'New moderator-created board page was not generated.');
    $createdBoardIndex = (string) file_get_contents($createdBoardIndexPath);
    expect(str_contains($createdBoardIndex, 'Posting paused'), 'New board page does not show its paused status.');
    expect(!str_contains($createdBoardIndex, 'class="new-post"'), 'Paused new board unexpectedly offers thread creation.');
    $boardIndex = (string) file_get_contents($boardIndexPath);
    expect(str_contains($boardIndex, 'id="theme-stylesheet"'), 'Board lacks the switchable theme stylesheet link.');
    expect(str_contains($boardIndex, 'href="/static/assets/css/themes/checkmate.css"'), 'Board default theme points to the wrong stylesheet.');
    expect(str_contains($boardIndex, 'data-theme-base="/static/assets/css/themes"'), 'Board theme base points to the wrong directory.');
    preg_match_all('/<option value="([a-z0-9-]+)"/', $boardIndex, $themeMatches);
    $themeOptions = array_values(array_unique($themeMatches[1]));
    sort($themeOptions);
    $themeFiles = array_map(
        static fn (string $file): string => pathinfo($file, PATHINFO_FILENAME),
        glob($root . '/static/assets/css/themes/*.css') ?: [],
    );
    sort($themeFiles);
    expect(count($themeOptions) === 36, 'The stylesheet switcher does not contain all 36 themes.');
    expect($themeOptions === $themeFiles, 'Stylesheet switcher options and theme files do not match exactly.');
    foreach ($themeOptions as $theme) {
        expect(
            is_file($root . '/static/assets/css/themes/' . $theme . '.css'),
            'Stylesheet switcher points to a missing theme: ' . $theme,
        );
    }
    $preferencesSource = (string) file_get_contents($root . '/static/assets/js/preferences.js');
    expect(
        str_contains($preferencesSource, "themeStylesheet.dataset.themeBase ?? '/static/assets/css/themes'"),
        'Stylesheet switcher JavaScript fallback points outside the static CSS tree.',
    );
    $applicationJavaScript = (string) file_get_contents($root . '/static/assets/js/app.js');
    expect(str_contains($applicationJavaScript, 'configuredFeatures'), 'JavaScript entry point does not enforce the rendered allowlist.');
    $modernModules = glob($root . '/static/assets/js/*.js') ?: [];
    expect(count($modernModules) >= 25, 'Expected modern enhancement modules are missing.');
    foreach ($modernModules as $modernModulePath) {
        $modernModule = basename($modernModulePath);
        $moduleSource = (string) file_get_contents($modernModulePath);
        expect($moduleSource !== '', "Modern JavaScript module is empty: $modernModule");
        foreach (['$(', '.innerHTML', 'eval(', 'document.write', 'insertAdjacentHTML', 'javascript:'] as $unsafePattern) {
            expect(!str_contains($moduleSource, $unsafePattern), "$modernModule contains a legacy or unsafe pattern: $unsafePattern");
        }
    }
    expect(str_contains($applicationJavaScript, 'visitorFeatureEnabled'), 'JavaScript entry point does not honor visitor feature choices.');
    expect(is_file($root . '/static/assets/js/feature-preferences.js'), 'Validated enhancement preference store is missing.');
    expect(is_file($root . '/static/assets/js/quick-reply.js'), 'Safe quick-reply module is missing.');
    expect(is_file($root . '/static/assets/js/content-hiding.js'), 'Local content-hiding module is missing.');
    expect(str_contains($boardIndex, '<section class="new-post" aria-label="Start a new thread">'), 'Board lacks the Rust-positioned New control.');
    expect(str_contains($boardIndex, '<form method="get" action="/compose">'), 'Rust-positioned New control does not preserve the PHP compose route.');
    expect(preg_match('/<time datetime="[^"]+" title="[^"]+">\d{2}\/\d{2}\/\d{2}<\/time>/', $boardIndex) === 1, 'Public post date does not match the compact Rust display.');
    expect(str_contains($boardIndex, 'class="thread-preview" id="thread-' . $op['thread_id'] . '"'), 'Board preview lacks the Rust thread identity hook.');
    expect(str_contains($boardIndex, 'class="thread-preview__replies"'), 'Recent replies are not grouped like the Rust board.');
    expect(str_contains($boardIndex, 'class="post__reply-count">3 replies</span>'), 'Reply count is absent from the OP header.');
    expect(str_contains($boardIndex, 'data-post-count="4"'), 'Exact per-thread post count is absent from the board preview.');
    expect(str_contains($boardIndex, '1 reply omitted. Open the thread to view all.'), 'Omitted-reply summary is incorrect.');
    expect(str_contains($boardIndex, 'class="post__status-icon post__status-icon--pinned"'), 'Pinned icon is absent.');
    expect(str_contains($boardIndex, 'class="post__status-icon post__status-icon--locked"'), 'Locked icon is absent.');
    expect(str_contains($boardIndex, 'data-board-card') === false, 'Board page unexpectedly contains home-page card hooks.');
    expect(str_contains($boardIndex, 'download="opening.jpg"'), 'Original filename download metadata is absent.');
    expect(str_contains($boardIndex, '640×480') && str_contains($boardIndex, '12.1 KB'), 'Attachment dimensions or size are absent.');
    expect(str_contains($boardIndex, 'class="post__op"'), 'Opening-post label is absent.');
    expect(str_contains($boardIndex, 'id="enhancements-dialog"'), 'Visitor enhancements panel is absent.');
    expect(str_contains($boardIndex, '<details class="post-menu">'), 'Compact post action menu is absent.');
    expect(str_contains($boardIndex, 'Reply to view the full post'), 'Long OP preview was not truncated.');
    $threadPage = (string) file_get_contents($live . '/chess/threads/' . $op['thread_id'] . '.html');
    expect(str_contains($threadPage, 'class="reply-mode reply-mode--locked"'), 'Locked thread bar is absent.');
    expect(str_contains($threadPage, 'This thread is locked'), 'Locked thread message is absent.');
    expect(!str_contains($threadPage, '/compose?board=chess&amp;thread=' . $op['thread_id']), 'Locked thread still offers a reply link.');
    expect(str_contains($threadPage, 'data-image-visibility-toggle'), 'Thread image visibility control is absent.');
    expect(str_contains($threadPage, 'data-image-expansion-toggle'), 'Thread image expansion control is absent.');
    expect(
        str_contains($threadPage, 'data-js-features="' . implode(',', Config::DEFAULT_JAVASCRIPT_FEATURES) . '"'),
        'Default JavaScript policy is absent from the generated thread.',
    );
    expect(str_contains($threadPage, 'class="thread-stats">4 posts · 1 image</span>'), 'Server-rendered thread statistics are absent.');
    $catalogPage = (string) file_get_contents($live . '/chess/catalog/index.html');
    expect(str_contains($catalogPage, 'data-catalog-card'), 'Catalog page lacks thread cards.');
    expect(str_contains($catalogPage, 'data-catalog-tools'), 'Catalog page lacks its optional search/sort controls.');
    expect(!str_contains($threadPage, 'Reply to view the full post'), 'Full thread unexpectedly contains preview-only text.');

    $control = new ControlStore($config);
    $control->recordLoginAttempt($firstRateKey);
    expect($control->loginAllowed($firstRateKey), 'Session-key moderator throttling failed.');
    $controlSchemaCheck = new PDO('sqlite:' . $config->controlDatabasePath);
    expect((string) $controlSchemaCheck->query("SELECT value FROM app_meta WHERE key = 'schema_version'")->fetchColumn() === '2', 'Control schema is not v2.');
    $loginColumns = $controlSchemaCheck->query('PRAGMA table_info(login_events)')->fetchAll(PDO::FETCH_COLUMN, 1);
    expect(in_array('rate_key', $loginColumns, true) && !in_array('client_hash', $loginColumns, true), 'Control login events still use the legacy IP-derived column.');
    $control->createModerator('tester', 'a-very-long-test-password');
    (new BackupService($config))->create($backup);
    expect(is_file($backup . '/manifest.json'), 'Backup manifest was not created.');
    expect(!is_file($backup . '/site.key'), 'Backup still contains the obsolete IP-HMAC site key.');

    $manifest = json_decode((string) file_get_contents($backup . '/manifest.json'), true, 16, JSON_THROW_ON_ERROR);
    expect(($manifest['format'] ?? null) === 2, 'Backup did not use the portable-board format.');
    $portableBoard = $backup . '/boards/chess';
    expect(is_file($portableBoard . '/index.html'), 'Portable backup lacks the board index.');
    expect(is_file($portableBoard . '/threads/' . $op['thread_id'] . '.html'), 'Portable backup lacks the board thread page.');
    expect(is_file($portableBoard . '/.board/board.json'), 'Portable backup lacks private board configuration.');
    expect(is_file($portableBoard . '/.board/.board-id'), 'Portable backup lacks private board identity.');
    expect(is_file($portableBoard . '/.board/.htaccess'), 'Portable backup lacks its Apache private-data denial file.');
    expect(is_file($portableBoard . '/.board/board.sqlite3'), 'Portable backup lacks the online SQLite snapshot.');
    expect(!is_file($portableBoard . '/board.sqlite3'), 'Backup exposed its database at the board root.');
    $restoreConfig = testConfig($root, $restore);
    (new BackupService($restoreConfig))->restore($backup);
    $restoredRegistry = new BoardRegistry($restoreConfig);
    $restored = $restoredRegistry->get('chess');
    expect($restored !== null, 'Restored board was not discovered.');
    expect($restoredRegistry->get('endgames') !== null, 'Moderator-created board was not restored.');
    expect(count((new BoardStore($restoreConfig, $restored))->threadPosts($op['thread_id'])) === 4, 'Restored posts did not match.');
    expect(is_file($restore . '/chess/threads/' . $op['thread_id'] . '.html'), 'Restore did not rebuild static pages.');
    $backupSidecars = [];
    $backupFiles = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($backup, RecursiveDirectoryIterator::SKIP_DOTS));
    foreach ($backupFiles as $backupFile) {
        if ($backupFile->isFile() && preg_match('/-(?:wal|shm)\z/', $backupFile->getFilename())) {
            $backupSidecars[] = $backupFile->getPathname();
        }
    }
    expect($backupSidecars === [], 'Restore mutated its source backup by creating SQLite sidecars.');
    $restoreAgainConfig = testConfig($root, $restoreAgain);
    (new BackupService($restoreAgainConfig))->restore($backup);
    expect((new BoardRegistry($restoreAgainConfig))->get('chess') !== null, 'The same verified backup could not be restored twice.');
    $nginx = (string) file_get_contents($root . '/config/nginx-boardhub.conf');
    $apache = (string) file_get_contents($root . '/.htaccess');
    $router = (string) file_get_contents($root . '/router.php');
    expect(str_contains($nginx, 'root /srv/boardhub;'), 'Nginx still expects an outer public directory.');
    expect(str_contains($nginx, 'index index.html;') && !str_contains($nginx, 'index index.html index.php'), 'Nginx does not use index.html as the sole index.');
    expect(str_contains($nginx, '/$board/threads/$thread.html'), 'Nginx does not serve threads from their board directory.');
    expect(str_contains($nginx, "img-src 'self' blob:"), 'Nginx CSP blocks local upload-preview object URLs.');
    expect(str_contains($nginx, '/\\.board'), 'Nginx does not explicitly deny board-private directories.');
    expect(str_contains($nginx, 'site-data|src|tests|tools'), 'Nginx does not deny shared private directories.');
    expect(!str_contains($nginx, 'location /stylesheets/'), 'Nginx still exposes the obsolete separate stylesheets directory.');
    expect(str_contains($nginx, 'location @boardhub'), 'Nginx lacks its internal dynamic-action target.');
    expect(str_contains($nginx, 'SCRIPT_FILENAME /srv/boardhub/boardhub.php'), 'Nginx does not dispatch dynamic actions through boardhub.php.');
    expect(str_contains($apache, 'sqlite3') && str_contains($apache, '(^|/)\\.'), 'Apache rules do not deny private board data.');
    expect(str_contains($apache, 'site-data|src|tests|tools'), 'Apache does not deny shared private directories.');
    expect(str_contains($apache, 'DirectoryIndex index.html') && !str_contains($apache, 'DirectoryIndex index.html index.php'), 'Apache does not use index.html as the sole index.');
    expect(str_contains($apache, 'boardhub\\.php') && str_contains($apache, '%{THE_REQUEST}'), 'Apache does not keep the dynamic handler internal.');
    expect(str_contains($router, '(?:^|/)\\.'), 'The local router does not deny hidden board data.');
    expect(str_contains($router, "'site-data'") && str_contains($router, "'tools'"), 'The local router does not deny shared private directories.');
    expect(str_contains($router, "'/boardhub.php'") && str_contains($router, "require __DIR__ . '/boardhub.php'"), 'The local router does not keep the dynamic handler internal.');
    $readme = (string) file_get_contents($root . '/README.txt');
    expect(!str_contains($readme, 'BOARDHUB_BOARDS_PATH'), 'README still documents centralized board storage.');
    expect(!str_contains($readme, 'public/<slug>') && !str_contains($readme, 'BOARDHUB_GENERATED_PATH'), 'README still documents the outer-public layout.');
    expect(str_contains($readme, '/home/account/public_html/'), 'README does not document direct shared-hosting deployment.');
    expect(!str_contains($readme, 'index.php') && str_contains($readme, 'exactly one index file: index.html'), 'README still documents two index files.');
    expect(str_starts_with((string) file_get_contents($root . '/setup.sh'), '#!/usr/bin/env sh'), 'Linux setup launcher has an invalid shebang.');
    expect(str_starts_with((string) file_get_contents($root . '/start-test-server.sh'), '#!/usr/bin/env sh'), 'Linux server launcher has an invalid shebang.');
    fwrite(STDOUT, "Integration test passed.\n");
} finally {
    unset($store, $publisher, $control, $registry, $restoredRegistry, $restored, $board, $boardSchemaCheck, $controlSchemaCheck, $privacySecurity);
    gc_collect_cycles();
    removeTree($temporary);
}
