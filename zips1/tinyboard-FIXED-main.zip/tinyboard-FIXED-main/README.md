# Newboard (or any name)

A **from-scratch** imageboard-style discussion app inspired by Tinyboard’s look, written for **PHP 8.5+** and **SQLite3**.

Not a fork. Not compatible with Tinyboard installs. Ai made this FROM SCRATCH in 4 minutes after i had it look at vichan and tinyboard. No lie. 

## Principles

- Strict types, modern PHP only
- **No IP collection** anywhere
- SQLite database under `data/`
- Tinyboard-like UI (classic board / thread / post form)

See **`ai.readme`** for the full product brief.

## Requirements

- PHP **8.5+** with extensions: `pdo_sqlite`, `mbstring`, `gd`, `openssl`
- Web server document root = `public/` (or `php -S` with router)

## Quick start

```bash
cd new
php bin/install.php
php -S 127.0.0.1:8080 -t public public/router.php
```

- Board: http://127.0.0.1:8080/b/
- Mod:   http://127.0.0.1:8080/mod  (default `admin` / `password` — change immediately)

## Layout

```text
ai.readme          Project brief for humans and agents
bin/install.php    Create DB + admin + starter board
config/app.php     Defaults (override via config/local.php)
data/              SQLite file + uploads (not web-reachable if docroot is public/)
public/            Web root
src/               Application code (PSR-4-ish autoload)
templates/         PHP views
schema/schema.sql  SQLite schema
```
