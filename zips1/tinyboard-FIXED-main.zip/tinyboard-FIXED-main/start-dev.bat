@echo off
cd /d "%~dp0"
set PHP=C:\php\php.exe
if not exist "%PHP%" set PHP=php
if not exist "data\board.sqlite" (
  echo Installing...
  "%PHP%" bin\install.php
)
echo Starting http://127.0.0.1:8080/
"%PHP%" -S 127.0.0.1:8080 -t public public\router.php

pause
